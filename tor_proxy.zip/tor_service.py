import os
import re
import sys
import time
import json
import shutil
import socket
import random
import tarfile
import threading
import subprocess
import concurrent.futures
import ssl
import urllib.request
import urllib.error
import urllib.parse
from pathlib import Path

TOR_EXPERT_BUNDLE_URL = "https://dist.torproject.org/torbrowser/15.0.23/tor-expert-bundle-windows-x86_64-15.0.23.tar.gz"
TOR_EXPERT_BUNDLE_BACKUP_URL = "https://archive.torproject.org/tor-package-archive/torbrowser/15.0.23/tor-expert-bundle-windows-x86_64-15.0.23.tar.gz"

DEFAULT_FALLBACK_BRIDGES = [
    "webtunnel [2001:db8:1169:5d59:447d:1feb:3595:b174]:443 9E22636EA817AD4FE43F2EC14DEED5131FED1CB0 url=https://cdn-40.triplebit.dev/aif5ohWa4aWiephu ver=0.0.2",
    "webtunnel [2001:db8:16dd:e87a:be69:57a6:40b3:21da]:443 6D1E413706CFB579D293C2539901D03F31C1DE6C url=https://cyberspace.rest/r5DN8hUb7tq1gPuoLtxDdrBk ver=0.0.7",
    "webtunnel [2001:db8:243b:a5c9:7728:ccef:745a:e1ee]:443 B94C563110B9AFD1727F742EB614B09DA8DC2A74 url=https://encyclical.org/3UhGoU2otI1enSBtW8l4inE0 ver=0.0.4",
    "webtunnel [2001:db8:309:cdb:16f0:62c:28e1:9524]:443 C038344E981F9BA209E420EAC4ECE1D4193BB355 url=https://shoes.tworiverssoftware.com/2GDD1PZDcm4UPkPEfYulA6nZ ver=0.0.6",
    "webtunnel [2001:db8:3532:d0b6:b59e:acfb:f6ed:a40e]:443 81DCDD5A242A10CA419E7CE477DBE3BD00A9DAB0 url=https://wedo.cyou/4fdDGGRIMtLFi2bmq4rxLbti ver=0.0.4",
    "webtunnel [2001:db8:3be7:5113:eddb:210d:291f:b52c]:443 B6CFDBD17618C147903429AB1C0CC759933DB50E url=https://adm.unicoridor.ru/rtASSYlOJgl1nKtH8njdZLbs ver=0.0.6",
    "webtunnel [2001:db8:50a9:c546:36be:96ad:4cd1:cfff]:443 D20CE64A82CF6E6DB6F4F95C1F8FA81B06C10888 url=https://cdn-35.triplebit.dev/iethae6ahvoo1ieV ver=0.0.2",
    "webtunnel [2001:db8:5506:f98f:b625:c162:4821:ba21]:443 90A7AFFBFE51BD4DABE327FD2E1D8DEB31AF7071 url=https://mail.engelseruiter.nl/oZL7sdW588guQ6pLrMpIZ9fs ver=0.0.5",
]


class TorStatus:
    STOPPED = "STOPPED"
    STARTING = "STARTING"
    SCANNING = "SCANNING"
    RUNNING = "RUNNING"
    ERROR = "ERROR"


class TorService:
    def __init__(self, project_root):
        self.project_root = Path(project_root).resolve()
        self.common_dir = self.project_root / "common_files"
        self.tor_base_dir = self.common_dir / "tor"
        self.tor_data_dir = self.tor_base_dir / "data"

        self.status = TorStatus.STOPPED
        self.status_detail = "Tor is stopped"
        self.bootstrap_progress = 0
        self.process = None
        self.socks_port = 9050
        self.custom_tor_path = ""
        self.external_mode = False
        self.auto_route_telegram = True
        self.auto_route_discord = True
        self.use_bridges = True
        self.bridges_text = ""
        self.auto_search_bridges = True
        self.api = None

        self._auto_retry_count = 0
        self._max_auto_retries = 8
        self._on_bridges_updated_cb = None
        self._tg_watchdog_running = False
        self._is_recovering = False

        self.log_lines = []
        self._max_logs = 300
        self._log_lock = threading.Lock()
        self._listeners = []
        self._log_listeners = []
        self._reader_thread = None
        self._monitor_thread = None
        self._is_terminating = False
        self._job_handle = None
        self._last_error_detail = None
        self._scanning_lock = threading.Lock()
        self._lifecycle_lock = threading.RLock()

        self._ensure_bundled_tor()
        self.check_and_update_scanner()

    def _ensure_bundled_tor(self):
        try:
            plugin_dir = Path(__file__).resolve().parent
            bundled_tor = plugin_dir / "tor"
            target_tor = self.tor_base_dir
            if (bundled_tor / "tor" / "tor.exe").is_file():
                target_tor.mkdir(parents=True, exist_ok=True)
                for root, dirs, files in os.walk(bundled_tor):
                    rel = os.path.relpath(root, bundled_tor)
                    dest_dir = target_tor if rel == "." else target_tor / rel
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    for f in files:
                        dest_file = dest_dir / f
                        if not dest_file.exists():
                            shutil.copy2(os.path.join(root, f), str(dest_file))
                self._append_log("Offline Tor bundle initialized from plugin.")
        except Exception as e:
            self._append_log(f"Offline bundle init note: {e}")

    def add_listener(self, callback):
        if callback not in self._listeners:
            self._listeners.append(callback)

    def remove_listener(self, callback):
        if callback in self._listeners:
            self._listeners.remove(callback)

    def add_log_listener(self, callback):
        if callback not in self._log_listeners:
            self._log_listeners.append(callback)

    def remove_log_listener(self, callback):
        if callback in self._log_listeners:
            self._log_listeners.remove(callback)

    def set_bridges_updated_callback(self, callback):
        self._on_bridges_updated_cb = callback

    def _notify_bridges_updated(self, bridges_text):
        if callable(self._on_bridges_updated_cb):
            try:
                self._on_bridges_updated_cb(bridges_text)
            except Exception:
                pass

    def _notify_status(self):
        for cb in list(self._listeners):
            try:
                cb(self.status, self.status_detail, self.bootstrap_progress)
            except Exception:
                pass

    def _append_log(self, line):
        line = str(line or "").strip()
        if not line:
            return
        with self._log_lock:
            self.log_lines.append(line)
            if len(self.log_lines) > self._max_logs:
                self.log_lines.pop(0)
        for cb in list(self._log_listeners):
            try:
                cb(line)
            except Exception:
                pass

    def clear_logs(self):
        with self._log_lock:
            self.log_lines.clear()

    def find_tor_executable(self):
        if self.custom_tor_path:
            try:
                p = Path(self.custom_tor_path)
                if p.is_file() and p.name.lower().endswith(".exe"):
                    return str(p.resolve())
            except Exception:
                pass

        candidates = [
            self.tor_base_dir / "tor" / "tor.exe",
            self.tor_base_dir / "Tor" / "tor.exe",
            self.tor_base_dir / "tor.exe",
        ]
        plugin_dir = Path(__file__).resolve().parent
        candidates.append(plugin_dir / "tor" / "tor" / "tor.exe")
        candidates.append(plugin_dir / "tor" / "tor.exe")

        for c in candidates:
            try:
                if c.is_file():
                    return str(c.resolve())
            except Exception:
                pass

        local_app = os.environ.get("LOCALAPPDATA", "")
        user_prof = os.environ.get("USERPROFILE", "")
        tb_candidates = [
            Path(local_app) / "Programs" / "Tor Browser" / "Browser" / "TorBrowser" / "Tor" / "tor.exe",
            Path(user_prof) / "Desktop" / "Tor Browser" / "Browser" / "TorBrowser" / "Tor" / "tor.exe",
            Path(r"C:\Program Files\Tor\tor.exe"),
            Path(r"C:\Program Files (x86)\Tor\tor.exe"),
        ]
        for c in tb_candidates:
            if c.is_file():
                return str(c.resolve())

        which = shutil.which("tor.exe") or shutil.which("tor")
        if which:
            return which

        return None

    def is_tor_installed(self):
        return self.find_tor_executable() is not None

    def download_tor_bundle(self, progress_callback=None):
        self._kill_stale_tor_processes()
        self.tor_base_dir.mkdir(parents=True, exist_ok=True)

        plugin_dir = Path(__file__).resolve().parent
        bundled_tor = plugin_dir / "tor"
        if (bundled_tor / "tor" / "tor.exe").is_file():
            self._append_log("Installing Tor from bundled offline package...")
            if progress_callback:
                progress_callback(50, 10 * 1024 * 1024, 20 * 1024 * 1024)
            self._ensure_bundled_tor()
            if progress_callback:
                progress_callback(100, 20 * 1024 * 1024, 20 * 1024 * 1024)
            found = self.find_tor_executable()
            if found:
                self._append_log(f"Tor installed from offline bundle: {found}")
                return found

        archive_path = self.tor_base_dir / "tor-expert-bundle.tar.gz"
        urls = [TOR_EXPERT_BUNDLE_URL, TOR_EXPERT_BUNDLE_BACKUP_URL]
        downloaded = False
        last_err = None

        for url in urls:
            try:
                self._append_log(f"Downloading Tor Expert Bundle from {url}...")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    total = int(resp.headers.get("Content-Length", 0) or 0)
                    downloaded_bytes = 0
                    chunk_size = 64 * 1024

                    with open(archive_path, "wb") as f:
                        while True:
                            chunk = resp.read(chunk_size)
                            if not chunk:
                                break
                            f.write(chunk)
                            downloaded_bytes += len(chunk)
                            if progress_callback:
                                pct = int((downloaded_bytes / total) * 100) if total > 0 else 0
                                progress_callback(pct, downloaded_bytes, total)
                downloaded = True
                break
            except Exception as e:
                last_err = e
                self._append_log(f"Download error from {url}: {e}")

        if not downloaded:
            raise RuntimeError(f"Failed to download Tor Expert Bundle: {last_err}")

        self._kill_stale_tor_processes()
        self._append_log("Extracting Tor Expert Bundle...")
        try:
            with tarfile.open(archive_path, "r:gz") as tar:
                tar.extractall(path=self.tor_base_dir)
            self._append_log("Extraction completed successfully.")
        finally:
            if archive_path.is_file():
                try:
                    archive_path.unlink()
                except Exception:
                    pass

        found = self.find_tor_executable()
        if not found:
            raise FileNotFoundError("tor.exe not found in extracted archive.")
        self._append_log(f"Tor installed: {found}")
        return found

    def _is_port_busy(self, port):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.3)
                return s.connect_ex(('127.0.0.1', int(port))) == 0
        except Exception:
            return False

    def _kill_stale_tor_processes(self):
        try:
            import psutil
            current_pid = os.getpid()
            active_pid = self.process.pid if self.process else None
            for p in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    pid = p.info['pid']
                    if pid == current_pid or (active_pid and pid == active_pid):
                        continue
                    name = (p.info['name'] or '').lower()
                    if name in ('tor.exe', 'lyrebird.exe'):
                        exe = (p.info['exe'] or '').lower()
                        our_exe = (self.find_tor_executable() or '').lower()
                        if ('farm_watcher' in exe) or (our_exe and our_exe in exe) or ('common_files' in exe):
                            p.kill()
                            self._append_log(f"Terminated stale {name} process (PID {pid})")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception as e:
            self._append_log(f"Process cleanup note: {e}")

        if not self.external_mode:
            for _ in range(8):
                if not self._is_port_busy(self.socks_port):
                    break
                time.sleep(0.2)

    def _assign_job_object(self, proc):
        if sys.platform != "win32" or not proc:
            return
        try:
            import ctypes
            from ctypes import wintypes

            class IO_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ('ReadOperationCount', ctypes.c_uint64),
                    ('WriteOperationCount', ctypes.c_uint64),
                    ('OtherOperationCount', ctypes.c_uint64),
                    ('ReadTransferCount', ctypes.c_uint64),
                    ('WriteTransferCount', ctypes.c_uint64),
                    ('OtherTransferCount', ctypes.c_uint64),
                ]

            class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ('PerProcessUserTimeLimit', ctypes.c_int64),
                    ('PerJobUserTimeLimit', ctypes.c_int64),
                    ('LimitFlags', wintypes.DWORD),
                    ('MinimumWorkingSetSize', ctypes.c_size_t),
                    ('MaximumWorkingSetSize', ctypes.c_size_t),
                    ('ActiveProcessLimit', wintypes.DWORD),
                    ('Affinity', ctypes.c_size_t),
                    ('PriorityClass', wintypes.DWORD),
                    ('SchedulingClass', wintypes.DWORD),
                ]

            class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ('BasicLimitInformation', JOBOBJECT_BASIC_LIMIT_INFORMATION),
                    ('IoInfo', IO_COUNTERS),
                    ('ProcessMemoryLimit', ctypes.c_size_t),
                    ('JobMemoryLimit', ctypes.c_size_t),
                    ('PeakProcessMemoryLimit', ctypes.c_size_t),
                    ('PeakJobMemoryLimit', ctypes.c_size_t),
                ]

            k32 = ctypes.windll.kernel32
            hJob = k32.CreateJobObjectW(None, None)
            if hJob:
                info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
                info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                k32.SetInformationJobObject(hJob, 9, ctypes.byref(info), ctypes.sizeof(info))
                hProc = k32.OpenProcess(0x1F0FFF, False, proc.pid)
                if hProc:
                    k32.AssignProcessToJobObject(hJob, hProc)
                    k32.CloseHandle(hProc)
                self._job_handle = hJob
        except Exception:
            pass

    # =========================================================================
    # TOR-RELAY-SCANNER AUTO-UPDATER & ENGINE MANAGEMENT
    # =========================================================================

    def get_scanner_info(self) -> dict:
        meta_path = Path(__file__).resolve().parent / "scanner_meta.json"
        if meta_path.is_file():
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return {"version": "1.0.5", "last_check": 0}

    def check_and_update_scanner(self, force=False):
        def _bg():
            meta_path = Path(__file__).resolve().parent / "scanner_meta.json"
            upstream_file = Path(__file__).resolve().parent / "scanner_upstream.py"
            meta = self.get_scanner_info()

            now = time.time()
            last_check = float(meta.get("last_check", 0))
            current_ver = str(meta.get("version", "1.0.5"))

            if not force and upstream_file.is_file() and (now - last_check) < 86400:
                return

            try:
                api_url = "https://api.github.com/repos/ValdikSS/tor-relay-scanner/releases/latest"
                req = urllib.request.Request(api_url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                latest_ver = None
                try:
                    with urllib.request.urlopen(req, timeout=6) as resp:
                        rel_data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                        raw_tag = rel_data.get("tag_name") or rel_data.get("name")
                        if raw_tag:
                            latest_ver = str(raw_tag).strip().lstrip("v")
                except Exception:
                    pass

                if not latest_ver:
                    commit_url = "https://api.github.com/repos/ValdikSS/tor-relay-scanner/commits/main"
                    req_c = urllib.request.Request(commit_url, headers={"User-Agent": "Mozilla/5.0"})
                    try:
                        with urllib.request.urlopen(req_c, timeout=6) as resp:
                            c_data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                            sha = c_data.get("sha", "")
                            if sha:
                                latest_ver = sha[:8]
                    except Exception:
                        pass

                if not latest_ver:
                    return

                if latest_ver != current_ver or not upstream_file.is_file():
                    self._append_log(f"[tor-relay-scanner] New version detected on GitHub: v{latest_ver}. Updating engine...")
                    raw_url = "https://raw.githubusercontent.com/ValdikSS/tor-relay-scanner/main/src/tor_relay_scanner/scanner.py"
                    req_raw = urllib.request.Request(raw_url, headers={"User-Agent": "Mozilla/5.0"})
                    with urllib.request.urlopen(req_raw, timeout=10) as resp_raw:
                        code = resp_raw.read().decode("utf-8", errors="ignore")

                    compile(code, "scanner_upstream.py", "exec")

                    tmp_f = upstream_file.with_suffix(".tmp")
                    with open(tmp_f, "w", encoding="utf-8") as f:
                        f.write(code)
                    os.replace(tmp_f, upstream_file)

                    meta["version"] = latest_ver
                    meta["last_check"] = now
                    with open(meta_path, "w", encoding="utf-8") as f:
                        json.dump(meta, f, indent=2)

                    self._append_log(f"[tor-relay-scanner] Successfully updated scanner engine to v{latest_ver}.")
                else:
                    meta["last_check"] = now
                    with open(meta_path, "w", encoding="utf-8") as f:
                        json.dump(meta, f, indent=2)
            except Exception as e:
                self._append_log(f"[tor-relay-scanner] GitHub update check note: {e}")

        threading.Thread(target=_bg, daemon=True).start()

    # =========================================================================
    # VALDIKSS / TOR-RELAY-SCANNER BRIDGE DISCOVERY & TESTING
    # =========================================================================

    def _test_single_bridge(self, bridge_line, timeout=2.5):
        bridge_str = str(bridge_line or "").strip()
        if not bridge_str:
            return False

        # WebTunnel test (direct TCP + strict SSL validation and forwarder check, bypassing system proxies)
        m_wt = re.search(r"url=(https://[^\s]+)", bridge_str)
        if m_wt:
            test_url = m_wt.group(1)
            try:
                parsed = urllib.parse.urlparse(test_url)
                host = parsed.hostname
                port = parsed.port or 443

                # 1. Require valid TLS certificate (reject invalid certs like a.private.st)
                ctx = ssl.create_default_context()
                with socket.create_connection((host, port), timeout=timeout) as s:
                    with ctx.wrap_socket(s, server_hostname=host) as ss:
                        path = parsed.path or "/"
                        req = f"GET {path} HTTP/1.1\r\nHost: {host}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n"
                        ss.sendall(req.encode("latin1"))
                        resp = ss.recv(512).decode("latin1", errors="ignore")
                        first_line = resp.split("\r\n")[0] if resp else ""
                        is_cf = "cloudflare" in resp.lower()
                        return (not is_cf) and ("403 Forbidden" not in first_line)
            except Exception:
                return False

        # Standard relay test
        m_relay = re.search(r"(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d+)", bridge_str)
        if m_relay:
            ip = m_relay.group(1)
            port = int(m_relay.group(2))
            try:
                with socket.create_connection((ip, port), timeout=timeout):
                    return True
            except Exception:
                return False

        return False

    def scan_working_bridges(self, count=2):
        self._append_log("[tor-relay-scanner] Scanning for reachable WebTunnel bridges...")
        pool = [re.sub(r"^bridge\s+", "", fb, flags=re.IGNORECASE) for fb in DEFAULT_FALLBACK_BRIDGES]

        # Fetch fresh online tested WebTunnel bridges directly from GitHub
        try:
            gh_url = "https://raw.githubusercontent.com/Delta-Kronecker/Tor-Bridges-Collector/main/bridge/webtunnel_tested.txt"
            req = urllib.request.Request(gh_url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=4) as resp:
                remote_lines = [l.strip() for l in resp.read().decode("utf-8", errors="ignore").splitlines() if l.strip()]
                if remote_lines:
                    random.shuffle(remote_lines)
                    pool = remote_lines[:35] + pool
        except Exception:
            pass

        random.shuffle(pool)

        def _test_candidate(line):
            if self._test_single_bridge(line, timeout=2.5):
                return line
            return None

        with concurrent.futures.ThreadPoolExecutor(max_workers=15) as pool_exec:
            results = list(pool_exec.map(_test_candidate, pool[:35]))
            verified_bridges = [r for r in results if r]

        if not verified_bridges:
            verified_bridges = [re.sub(r"^bridge\s+", "", b, flags=re.IGNORECASE) for b in DEFAULT_FALLBACK_BRIDGES[:count]]

        selected = random.sample(verified_bridges, min(count, len(verified_bridges)))
        self._append_log(f"[tor-relay-scanner] Found {len(selected)} verified reachable WebTunnel bridges.")
        return selected

    def fetch_online_bridges(self, count=2):
        return self.scan_working_bridges(count=count)

    def rotate_or_fetch_bridges(self):
        self._auto_retry_count = 0
        self._trigger_auto_recover()

    def _trigger_auto_recover(self):
        if self._is_recovering:
            return
        self._is_recovering = True

        def _bg():
            try:
                if self._auto_retry_count >= self._max_auto_retries:
                    self._append_log(f"[Auto-Heal] Maximum retry limit reached ({self._max_auto_retries}). Pausing auto-heal.")
                    self.stop()
                    self.status = TorStatus.ERROR
                    self.status_detail = "Failed to bootstrap after retries. Click to restart."
                    self._is_recovering = False
                    self._notify_status()
                    return

                self.status = TorStatus.SCANNING
                self.status_detail = "Switching to fresh verified bridge (tor-relay-scanner)..."
                self.bootstrap_progress = 10
                self._notify_status()

                if self.process:
                    old_p = self.process
                    self.process = None
                    try:
                        old_p.terminate()
                        old_p.wait(timeout=2)
                    except Exception:
                        try:
                            old_p.kill()
                        except Exception:
                            pass

                self._kill_stale_tor_processes()

                fresh = self.scan_working_bridges(count=2)
                if fresh:
                    new_text = "\n".join(fresh)
                    self.bridges_text = new_text
                    self.use_bridges = True
                    self._append_log(f"[Auto-Heal] Selected {len(fresh)} fresh working bridges. Re-launching Tor...")
                    self._notify_bridges_updated(new_text)

                self._is_recovering = False
                self.start()
            except Exception as e:
                self._append_log(f"[Auto-Heal] Recovery error: {e}")
                self._is_recovering = False
                time.sleep(3)
                if not self._is_terminating and self.status != TorStatus.RUNNING:
                    self._trigger_auto_recover()

        threading.Thread(target=_bg, daemon=True).start()

    # =========================================================================
    # PROCESS LIFECYCLE
    # =========================================================================

    def start(self):
        with self._lifecycle_lock:
            return self._start_internal()

    def _start_internal(self):
        if self.status == TorStatus.RUNNING:
            return True
        if self.status in (TorStatus.STARTING, TorStatus.SCANNING) and self.process and self.process.poll() is None:
            return True

        self._is_terminating = False
        self._last_error_detail = None
        if not self._is_recovering:
            self._auto_retry_count = 0

        if self.external_mode:
            self._append_log(f"External Tor mode: checking SOCKS port {self.socks_port}...")
            self.status = TorStatus.STARTING
            self.status_detail = f"Connecting to external Tor on port {self.socks_port}..."
            self.bootstrap_progress = 50
            self._notify_status()

            def _test_external():
                res = self.test_connection()
                if res.get("ok"):
                    self.status = TorStatus.RUNNING
                    self.status_detail = f"External Tor active (port {self.socks_port})"
                    self.bootstrap_progress = 100
                    self._append_log(f"External Tor verified successfully. Exit IP: {res.get('ip')}")
                    if self.auto_route_telegram or self.auto_route_discord:
                        self.sync_telegram_proxy(True)
                else:
                    self.status = TorStatus.ERROR
                    self.status_detail = f"External Tor unreachable: {res.get('error')}"
                    self.bootstrap_progress = 0
                    self._append_log(f"External Tor verification failed: {res.get('error')}")
                self._notify_status()

            threading.Thread(target=_test_external, daemon=True).start()
            return True

        self._kill_stale_tor_processes()

        if self._is_port_busy(self.socks_port):
            self._append_log(f"Port {self.socks_port} is busy, checking if existing Tor is responsive...")
            check_res = self.test_connection()
            if check_res.get("ok"):
                self.status = TorStatus.RUNNING
                self.status_detail = f"Tor is running (port {self.socks_port})"
                self.bootstrap_progress = 100
                self._append_log(f"Connected to Tor proxy on port {self.socks_port}. Exit IP: {check_res.get('ip')}")
                if self.auto_route_telegram or self.auto_route_discord:
                    self.sync_telegram_proxy(True)
                self._notify_status()
                return True

        tor_exe_str = self.find_tor_executable()
        if not tor_exe_str:
            self.status = TorStatus.ERROR
            self.status_detail = "tor.exe not found"
            self._append_log("Startup error: tor.exe executable not found.")
            self._notify_status()
            return False

        tor_exe = Path(tor_exe_str)
        tor_cwd = tor_exe.parent
        self.tor_data_dir.mkdir(parents=True, exist_ok=True)

        try:
            rel_data_dir = os.path.relpath(self.tor_data_dir, tor_cwd).replace("\\", "/")
        except Exception:
            rel_data_dir = "./data"

        torrc_lines = [
            f"SocksPort 127.0.0.1:{self.socks_port}",
            f'DataDirectory "{rel_data_dir}"',
            "Log notice stdout"
        ]

        plugin_dir = Path(__file__).resolve().parent

        geoip = self.tor_data_dir / "geoip"
        if not geoip.is_file():
            for cand_g in [tor_cwd.parent / "data" / "geoip", plugin_dir / "tor" / "data" / "geoip"]:
                if cand_g.is_file():
                    geoip = cand_g
                    break

        geoip6 = self.tor_data_dir / "geoip6"
        if not geoip6.is_file():
            for cand_g6 in [tor_cwd.parent / "data" / "geoip6", plugin_dir / "tor" / "data" / "geoip6"]:
                if cand_g6.is_file():
                    geoip6 = cand_g6
                    break

        if geoip.is_file():
            try:
                rel_g = os.path.relpath(geoip, tor_cwd).replace("\\", "/")
                torrc_lines.append(f'GeoIPFile "{rel_g}"')
            except Exception:
                torrc_lines.append(f'GeoIPFile "{geoip}"')
        if geoip6.is_file():
            try:
                rel_g6 = os.path.relpath(geoip6, tor_cwd).replace("\\", "/")
                torrc_lines.append(f'GeoIPv6File "{rel_g6}"')
            except Exception:
                torrc_lines.append(f'GeoIPv6File "{geoip6}"')

        # Configure Pluggable Transports / Bridges
        if self.use_bridges:
            pt_dir = tor_cwd / "pluggable_transports"
            lyrebird_exe = pt_dir / "lyrebird.exe"
            conjure_exe = pt_dir / "conjure-client.exe"
            if not lyrebird_exe.is_file():
                cand_lyre = plugin_dir / "tor" / "tor" / "pluggable_transports" / "lyrebird.exe"
                if cand_lyre.is_file():
                    lyrebird_exe = cand_lyre

            bridges_list = []
            if self.bridges_text.strip():
                raw_bridges = [line.strip() for line in self.bridges_text.splitlines() if line.strip()]
                bad_tokens = ("5e8310cf0a", "mail.ru", "el-hacker.org")
                filtered = [b for b in raw_bridges if not any(t in b.lower() for t in bad_tokens)]

                # Pre-test current bridges before launching Tor
                live_filtered = [b for b in filtered if self._test_single_bridge(b, timeout=2.5)]

                if not live_filtered:
                    self._append_log("Saved bridges are unresponsive. Auto-scanning fresh bridges before start...")
                    self.status = TorStatus.SCANNING
                    self.status_detail = "Scanning working bridges..."
                    self.bootstrap_progress = 10
                    self._notify_status()
                    fresh = self.scan_working_bridges(count=2)
                    if fresh:
                        live_filtered = fresh
                        self.bridges_text = "\n".join(fresh)
                        self._notify_bridges_updated(self.bridges_text)

                for b in live_filtered:
                    clean_b = re.sub(r"^bridge\s+", "", b, flags=re.IGNORECASE)
                    bridges_list.append(clean_b)
            else:
                try:
                    self.status = TorStatus.SCANNING
                    self.status_detail = "Scanning working bridges..."
                    self.bootstrap_progress = 10
                    self._notify_status()
                    fresh = self.scan_working_bridges(count=2)
                    if fresh:
                        bridges_list.extend(fresh)
                        self.bridges_text = "\n".join(fresh)
                        self._notify_bridges_updated(self.bridges_text)
                except Exception as e:
                    self._append_log(f"Bridge scan note: {e}")
                    for fb in DEFAULT_FALLBACK_BRIDGES[:2]:
                        clean_b = re.sub(r"^bridge\s+", "", fb, flags=re.IGNORECASE)
                        bridges_list.append(clean_b)
                    self.bridges_text = "\n".join(bridges_list)
                    self._notify_bridges_updated(self.bridges_text)

            if bridges_list:
                torrc_lines.append("UseBridges 1")
                has_webtunnel_or_obfs = any(
                    b.lower().startswith("webtunnel") or b.lower().startswith("obfs") or b.lower().startswith("snowflake")
                    for b in bridges_list
                )
                if has_webtunnel_or_obfs and lyrebird_exe.is_file():
                    rel_lyrebird = os.path.relpath(lyrebird_exe, tor_cwd).replace("/", "\\")
                    torrc_lines.append(f"ClientTransportPlugin meek_lite,obfs2,obfs3,obfs4,scramblesuit,webtunnel exec {rel_lyrebird}")
                    torrc_lines.append(f"ClientTransportPlugin snowflake exec {rel_lyrebird}")
                if conjure_exe.is_file():
                    rel_conjure = os.path.relpath(conjure_exe, tor_cwd).replace("/", "\\")
                    torrc_lines.append(f"ClientTransportPlugin conjure exec {rel_conjure} -registerURL https://registration.refraction.network/api")

                for b in bridges_list:
                    torrc_lines.append(f"Bridge {b}")
                self._append_log(f"Configured bridges: {len(bridges_list)}")

        torrc_path = tor_cwd / "torrc.fw"
        try:
            with open(torrc_path, "w", encoding="utf-8") as f:
                f.write("\n".join(torrc_lines) + "\n")
        except Exception as e:
            self._append_log(f"Failed to write torrc: {e}")
            self.status = TorStatus.ERROR
            self.status_detail = f"Failed to write torrc: {e}"
            self._notify_status()
            return False

        cmd = [str(tor_exe), "-f", "torrc.fw"]
        self._append_log(f"Starting Tor process (port {self.socks_port})...")
        self.status = TorStatus.STARTING
        self.status_detail = "Starting Tor process..."
        self.bootstrap_progress = 0
        self._notify_status()

        try:
            new_proc = subprocess.Popen(
                cmd,
                cwd=str(tor_cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                encoding="utf-8",
                errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
            self.process = new_proc
            self._assign_job_object(new_proc)
        except Exception as e:
            self.status = TorStatus.ERROR
            self.status_detail = f"Launch error: {e}"
            self._append_log(f"Failed to launch process: {e}")
            self._notify_status()
            return False

        self._reader_thread = threading.Thread(target=self._read_output, args=(new_proc,), daemon=True)
        self._reader_thread.start()

        self._monitor_thread = threading.Thread(target=self._monitor_process, args=(new_proc,), daemon=True)
        self._monitor_thread.start()

        if self.auto_search_bridges:
            self._start_bootstrap_watchdog(new_proc)
        return True

    def _read_output(self, proc):
        if not proc or not proc.stdout:
            return

        re_bootstrap = re.compile(r"Bootstrapped\s+(\d+)%")

        try:
            while not self._is_terminating:
                line = proc.stdout.readline()
                if not line:
                    break
                if self.process is not proc:
                    break
                self._append_log(line)
                lower = line.lower()

                if "wsaeaddrinuse" in lower or "address already in use" in lower:
                    self._last_error_detail = f"Port {self.socks_port} is busy by another app"
                elif "could not bind" in lower and not self._last_error_detail:
                    self._last_error_detail = f"Failed to bind port {self.socks_port}"
                elif "failed to parse/validate config" in lower and not self._last_error_detail:
                    self._last_error_detail = "Invalid torrc configuration"

                m = re_bootstrap.search(line)
                if m:
                    pct = int(m.group(1))
                    self.bootstrap_progress = pct
                    self.status_detail = f"Connecting to Tor: {pct}%"
                    if pct >= 100:
                        self.status = TorStatus.RUNNING
                        self._auto_retry_count = 0
                        self._is_recovering = False
                        self.status_detail = f"Tor is running (127.0.0.1:{self.socks_port})"
                        self._append_log(f"Tor successfully connected! SOCKS5 active on port {self.socks_port}.")
                        if self.auto_route_telegram or self.auto_route_discord:
                            self.sync_telegram_proxy(True)
                        self._start_telegram_watchdog()
                    self._notify_status()
        except Exception:
            pass

    def _start_telegram_watchdog(self):
        if self._tg_watchdog_running:
            return
        self._tg_watchdog_running = True

        def _loop():
            consecutive_failures = 0
            while not self._is_terminating:
                time.sleep(45)
                if self.status != TorStatus.RUNNING or self._is_terminating:
                    continue
                if not self.auto_route_telegram and not self.auto_route_discord:
                    continue
                try:
                    import requests
                    proxies = {
                        "http": f"socks5h://127.0.0.1:{self.socks_port}",
                        "https": f"socks5h://127.0.0.1:{self.socks_port}"
                    }
                    tg_ok = True
                    dc_ok = True
                    if self.auto_route_telegram:
                        try:
                            r = requests.get("https://api.telegram.org", proxies=proxies, timeout=8)
                            tg_ok = (r.status_code in (200, 404))
                        except Exception:
                            tg_ok = False
                    if self.auto_route_discord:
                        try:
                            r_dc = requests.get("https://discord.com/api/v10/gateway", proxies=proxies, timeout=8)
                            dc_ok = (r_dc.status_code in (200, 401, 403, 404))
                        except Exception:
                            dc_ok = False

                    if (self.auto_route_telegram and not tg_ok) or (self.auto_route_discord and not dc_ok):
                        consecutive_failures += 1
                    else:
                        consecutive_failures = 0
                except Exception:
                    consecutive_failures += 1

                if consecutive_failures >= 2 and not self._is_terminating and self.status == TorStatus.RUNNING:
                    failed_name = "Telegram/Discord" if (self.auto_route_telegram and self.auto_route_discord) else ("Discord" if self.auto_route_discord else "Telegram")
                    self._append_log(f"[Notifications Watchdog] {failed_name} connection lost through current bridge. Auto-recovering...")
                    consecutive_failures = 0
                    self._trigger_auto_recover()

            self._tg_watchdog_running = False

        threading.Thread(target=_loop, daemon=True).start()

    def _start_bootstrap_watchdog(self, proc):
        def _watchdog():
            start_time = time.time()
            last_progress = self.bootstrap_progress
            last_progress_time = time.time()

            while not self._is_terminating and self.process is proc and self.status == TorStatus.STARTING:
                time.sleep(1.5)
                now = time.time()

                if self.process is not proc or self.status != TorStatus.STARTING or self.bootstrap_progress >= 100:
                    break

                if self.bootstrap_progress > last_progress:
                    last_progress = self.bootstrap_progress
                    last_progress_time = now

                stuck_duration = now - last_progress_time
                total_duration = now - start_time
                stuck_threshold = 14 if last_progress < 25 else (18 if last_progress < 75 else 24)

                if (stuck_duration >= stuck_threshold or total_duration >= 40) and not self._is_terminating:
                    if self.process is proc and self.status == TorStatus.STARTING and self.bootstrap_progress < 100:
                        self._append_log(f"[Auto-Heal] Connection stuck at {self.bootstrap_progress}% for {int(stuck_duration)}s. Switching to working WebTunnel bridge...")
                        self._is_recovering = False
                        self._auto_retry_count += 1
                        self.use_bridges = True
                        self._trigger_auto_recover()
                    break

        threading.Thread(target=_watchdog, daemon=True).start()

    def _monitor_process(self, proc):
        if not proc:
            return
        code = proc.wait()
        with self._lifecycle_lock:
            if self.process is not proc:
                return
            if self._is_recovering:
                return
            if not self._is_terminating:
                self._append_log(f"Tor process terminated with exit code {code}")
                self.status = TorStatus.STOPPED if code == 0 else TorStatus.ERROR
                if code != 0:
                    self.status_detail = self._last_error_detail or f"Tor stopped (exit code: {code})"
                else:
                    self.status_detail = "Tor is stopped"
                self.bootstrap_progress = 0
                self.process = None
                if self.auto_route_telegram or self.auto_route_discord:
                    self.sync_telegram_proxy(False)
                self._notify_status()

    def stop(self):
        with self._lifecycle_lock:
            return self._stop_internal()

    def _stop_internal(self):
        self._is_terminating = True
        self._is_recovering = False
        self._append_log("Stopping Tor...")
        if self.process:
            proc = self.process
            self.process = None
            try:
                proc.terminate()
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
            except Exception as e:
                self._append_log(f"Error terminating process: {e}")

        if hasattr(self, "_job_handle") and self._job_handle:
            try:
                import ctypes
                ctypes.windll.kernel32.CloseHandle(self._job_handle)
            except Exception:
                pass
            self._job_handle = None

        if not self.external_mode:
            self._kill_stale_tor_processes()

        self.status = TorStatus.STOPPED
        self.status_detail = "Tor is stopped"
        self.bootstrap_progress = 0
        if self.auto_route_telegram or self.auto_route_discord:
            self.sync_telegram_proxy(False)
        self._append_log("Tor stopped successfully.")
        self._notify_status()

    def test_connection(self):
        import requests
        proxies = {
            "http": f"socks5h://127.0.0.1:{self.socks_port}",
            "https": f"socks5h://127.0.0.1:{self.socks_port}"
        }
        result = {
            "ok": False,
            "ip": None,
            "is_tor": False,
            "telegram_ok": False,
            "telegram_ms": 0,
            "discord_ok": False,
            "discord_ms": 0,
            "error": None
        }

        try:
            r = requests.get("https://check.torproject.org/api/ip", proxies=proxies, timeout=10)
            if r.status_code == 200:
                data = r.json()
                result["ip"] = data.get("IP")
                result["is_tor"] = bool(data.get("IsTor", False))
                result["ok"] = True
            else:
                result["error"] = f"check.torproject.org status {r.status_code}"
        except Exception as e:
            try:
                r_fallback = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=10)
                if r_fallback.status_code == 200:
                    result["ip"] = r_fallback.json().get("ip")
                    result["is_tor"] = True
                    result["ok"] = True
            except Exception:
                result["error"] = str(e)
                return result

        try:
            t_start = time.perf_counter()
            r_tg = requests.get("https://api.telegram.org", proxies=proxies, timeout=8)
            latency = int((time.perf_counter() - t_start) * 1000)
            result["telegram_ok"] = (r_tg.status_code in (200, 404))
            result["telegram_ms"] = latency
        except Exception:
            result["telegram_ok"] = False

        try:
            t_start = time.perf_counter()
            r_dc = requests.get("https://discord.com/api/v10/gateway", proxies=proxies, timeout=8)
            latency = int((time.perf_counter() - t_start) * 1000)
            result["discord_ok"] = (r_dc.status_code in (200, 401, 403, 404))
            result["discord_ms"] = latency
        except Exception:
            result["discord_ok"] = False

        return result

    def sync_telegram_proxy(self, enabled=True):
        config_path = self.common_dir / "plugin_configs" / "NotificationsPlugin.json"
        if not config_path.is_file():
            return
        try:
            data = {}
            if self.api:
                try:
                    data = self.api.load_plugin_config("NotificationsPlugin")
                except Exception:
                    data = {}
            if not data:
                with open(config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

            data["proxy_enabled"] = bool(enabled)
            if enabled:
                data["proxy_url"] = f"socks5h://127.0.0.1:{self.socks_port}"

            from app.utils.system import _atomic_write_bytes
            content = json.dumps(data, indent=4, ensure_ascii=False).encode("utf-8")
            _atomic_write_bytes(str(config_path), content)

            if self.api:
                try:
                    self.api.save_plugin_config("NotificationsPlugin", data)
                except Exception:
                    pass
                try:
                    gui = self.api.ctx.get("gui")
                    if gui and hasattr(gui, "plugin_manager") and gui.plugin_manager:
                        for p in gui.plugin_manager.plugins:
                            if p.__class__.__name__ == "NotificationsPlugin" and hasattr(p, "_ui_adapter"):
                                adapter = p._ui_adapter
                                if hasattr(adapter, "vars"):
                                    was_loading = getattr(adapter, "_loading", False)
                                    adapter._loading = True
                                    try:
                                        if "proxy_enabled" in adapter.vars:
                                            adapter.vars["proxy_enabled"].set(bool(enabled))
                                        if enabled and "proxy_url" in adapter.vars:
                                            adapter.vars["proxy_url"].set(f"socks5h://127.0.0.1:{self.socks_port}")
                                    finally:
                                        adapter._loading = was_loading
                except Exception:
                    pass

            self._append_log(f"Notifications proxy settings updated: enabled={enabled}, URL={data.get('proxy_url')}")
        except Exception as e:
            self._append_log(f"Failed to update NotificationsPlugin settings: {e}")

    sync_notifications_proxy = sync_telegram_proxy
