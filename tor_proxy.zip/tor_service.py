import os
import re
import sys
import time
import shutil
import tarfile
import urllib.request
import threading
import subprocess
from pathlib import Path

TOR_EXPERT_BUNDLE_URL = "https://dist.torproject.org/torbrowser/15.0.23/tor-expert-bundle-windows-x86_64-15.0.23.tar.gz"
TOR_EXPERT_BUNDLE_BACKUP_URL = "https://archive.torproject.org/tor-package-archive/torbrowser/15.0.23/tor-expert-bundle-windows-x86_64-15.0.23.tar.gz"

DEFAULT_FALLBACK_BRIDGES = [
    "webtunnel [2001:db8:289b:84cd:4be3:77f1:1cdd:9cb1]:443 D71C8E9C2180D2F35DEBF4A39BFCA6972F076D1C url=https://mail.ru/83c1327ea78e32b5d151e872ca123f7858aec2e1 ver=0.0.4",
    "webtunnel [2001:db8:35c8:629c:c5f9:9167:6272:2e92]:443 9D542D1BCF5994FF21ED379AA68DD691F305E03C url=https://api.mittarovo.cz/776261545e8f4c4c23f03b5161c6b3da78c2e6ba ver=0.0.4",
    "webtunnel [2001:db8:4fcd:461f:cbce:edea:fb74:a1e8]:443 F799A0A458365388600F54BD44A99B5887D54911 url=https://webtunnel.offblast.org/f799a0a458365388600f54bd44a99b5887d54911 ver=0.0.4",
    "webtunnel [2001:db8:628e:4cc:75b8:a286:fd79:4e82]:443 4723A337C3F108B96EF7429EC3DD96F3222B589D url=https://api.mittarovo.cz/f1dd892fa61947b78ab38d82d60320bb2aa800cf ver=0.0.4",
]

class TorStatus:
    STOPPED = "STOPPED"
    STARTING = "STARTING"
    RUNNING = "RUNNING"
    ERROR = "ERROR"

class TorService:
    def __init__(self, project_root):
        self.project_root = Path(project_root).resolve()
        self.common_dir = self.project_root / "common_files"
        self.tor_base_dir = self.common_dir / "tor"
        self.tor_data_dir = self.tor_base_dir / "data"

        self.status = TorStatus.STOPPED
        self.status_detail = "Tor is stopped"
        self.bootstrap_progress = 0
        self.process = None
        self.socks_port = 9050
        self.custom_tor_path = ""
        self.external_mode = False
        self.auto_route_telegram = True
        self.use_bridges = True
        self.bridges_text = ""
        self.auto_search_bridges = True
        self.api = None

        self._auto_retry_count = 0
        self._max_auto_retries = 10
        self._on_bridges_updated_cb = None
        self._tg_watchdog_running = False

        self.log_lines = []
        self._max_logs = 300
        self._log_lock = threading.Lock()
        self._listeners = []
        self._log_listeners = []
        self._reader_thread = None
        self._monitor_thread = None
        self._is_terminating = False
        self._job_handle = None
        self._last_error_detail = None
        self._ensure_bundled_tor()

    def _ensure_bundled_tor(self):
        try:
            plugin_dir = Path(__file__).resolve().parent
            bundled_tor = plugin_dir / "tor"
            target_tor = self.tor_base_dir
            if (bundled_tor / "tor" / "tor.exe").is_file():
                target_tor.mkdir(parents=True, exist_ok=True)
                for root, dirs, files in os.walk(bundled_tor):
                    rel = os.path.relpath(root, bundled_tor)
                    dest_dir = target_tor if rel == "." else target_tor / rel
                    dest_dir.mkdir(parents=True, exist_ok=True)
                    for f in files:
                        dest_file = dest_dir / f
                        if not dest_file.exists():
                            shutil.copy2(os.path.join(root, f), str(dest_file))
                self._append_log("Offline Tor bundle initialized from plugin.")
        except Exception as e:
            self._append_log(f"Offline bundle init note: {e}")

    def add_listener(self, callback):
        if callback not in self._listeners:
            self._listeners.append(callback)

    def remove_listener(self, callback):
        if callback in self._listeners:
            self._listeners.remove(callback)

    def add_log_listener(self, callback):
        if callback not in self._log_listeners:
            self._log_listeners.append(callback)

    def remove_log_listener(self, callback):
        if callback in self._log_listeners:
            self._log_listeners.remove(callback)

    def set_bridges_updated_callback(self, callback):
        self._on_bridges_updated_cb = callback

    def _notify_bridges_updated(self, bridges_text):
        if callable(self._on_bridges_updated_cb):
            try:
                self._on_bridges_updated_cb(bridges_text)
            except Exception:
                pass

    def _notify_status(self):
        for cb in list(self._listeners):
            try:
                cb(self.status, self.status_detail, self.bootstrap_progress)
            except Exception:
                pass

    def _append_log(self, line):
        line = line.strip()
        if not line:
            return
        with self._log_lock:
            self.log_lines.append(line)
            if len(self.log_lines) > self._max_logs:
                self.log_lines.pop(0)
        for cb in list(self._log_listeners):
            try:
                cb(line)
            except Exception:
                pass

    def clear_logs(self):
        with self._log_lock:
            self.log_lines.clear()

    def find_tor_executable(self):
        if self.custom_tor_path:
            try:
                p = Path(self.custom_tor_path)
                if p.is_file() and p.name.lower().endswith(".exe"):
                    return str(p.resolve())
            except Exception:
                pass

        # Check in common_files/tor
        candidates = [
            self.tor_base_dir / "tor" / "tor.exe",
            self.tor_base_dir / "Tor" / "tor.exe",
            self.tor_base_dir / "tor.exe",
        ]
        # Check in plugin directory (bundled)
        plugin_dir = Path(__file__).resolve().parent
        candidates.append(plugin_dir / "tor" / "tor" / "tor.exe")
        candidates.append(plugin_dir / "tor" / "tor.exe")

        for c in candidates:
            try:
                if c.is_file():
                    return str(c.resolve())
            except Exception:
                pass

        # Check typical Tor Browser locations
        local_app = os.environ.get("LOCALAPPDATA", "")
        user_prof = os.environ.get("USERPROFILE", "")
        tb_candidates = [
            Path(local_app) / "Programs" / "Tor Browser" / "Browser" / "TorBrowser" / "Tor" / "tor.exe",
            Path(user_prof) / "Desktop" / "Tor Browser" / "Browser" / "TorBrowser" / "Tor" / "tor.exe",
            Path(r"C:\Program Files\Tor\tor.exe"),
            Path(r"C:\Program Files (x86)\Tor\tor.exe"),
        ]
        for c in tb_candidates:
            if c.is_file():
                return str(c.resolve())

        # Check PATH
        which = shutil.which("tor.exe") or shutil.which("tor")
        if which:
            return which

        return None

    def is_tor_installed(self):
        return self.find_tor_executable() is not None

    def download_tor_bundle(self, progress_callback=None):
        self._kill_stale_tor_processes()
        self.tor_base_dir.mkdir(parents=True, exist_ok=True)

        # 1. First priority: if offline bundle is available in plugin folder, install instantly!
        plugin_dir = Path(__file__).resolve().parent
        bundled_tor = plugin_dir / "tor"
        if (bundled_tor / "tor" / "tor.exe").is_file():
            self._append_log("Installing Tor from bundled offline package...")
            if progress_callback:
                progress_callback(50, 10 * 1024 * 1024, 20 * 1024 * 1024)
            self._ensure_bundled_tor()
            if progress_callback:
                progress_callback(100, 20 * 1024 * 1024, 20 * 1024 * 1024)
            found = self.find_tor_executable()
            if found:
                self._append_log(f"Tor installed from offline bundle: {found}")
                return found

        archive_path = self.tor_base_dir / "tor-expert-bundle.tar.gz"

        urls = [TOR_EXPERT_BUNDLE_URL, TOR_EXPERT_BUNDLE_BACKUP_URL]
        downloaded = False
        last_err = None

        for url in urls:
            try:
                self._append_log(f"Downloading Tor Expert Bundle from {url}...")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                with urllib.request.urlopen(req, timeout=15) as resp:
                    total = int(resp.headers.get("Content-Length", 0) or 0)
                    downloaded_bytes = 0
                    chunk_size = 64 * 1024

                    with open(archive_path, "wb") as f:
                        while True:
                            chunk = resp.read(chunk_size)
                            if not chunk:
                                break
                            f.write(chunk)
                            downloaded_bytes += len(chunk)
                            if progress_callback:
                                pct = int((downloaded_bytes / total) * 100) if total > 0 else 0
                                progress_callback(pct, downloaded_bytes, total)
                downloaded = True
                break
            except Exception as e:
                last_err = e
                self._append_log(f"Download error from {url}: {e}")

        if not downloaded:
            raise RuntimeError(f"Failed to download Tor Expert Bundle: {last_err}")

        self._kill_stale_tor_processes()
        self._append_log("Extracting Tor Expert Bundle...")
        try:
            with tarfile.open(archive_path, "r:gz") as tar:
                tar.extractall(path=self.tor_base_dir)
            self._append_log("Extraction completed successfully.")
        finally:
            if archive_path.is_file():
                try:
                    archive_path.unlink()
                except Exception:
                    pass

        found = self.find_tor_executable()
        if not found:
            raise FileNotFoundError("tor.exe not found in extracted archive.")
        self._append_log(f"Tor installed: {found}")
        return found

    def _is_port_busy(self, port):
        import socket
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(0.3)
                return s.connect_ex(('127.0.0.1', int(port))) == 0
        except Exception:
            return False

    def _kill_stale_tor_processes(self):
        try:
            import psutil
            current_pid = os.getpid()
            for p in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    if p.info['pid'] == current_pid:
                        continue
                    name = (p.info['name'] or '').lower()
                    if name == 'tor.exe':
                        exe = (p.info['exe'] or '').lower()
                        our_exe = (self.find_tor_executable() or '').lower()
                        if ('farm_watcher' in exe) or (our_exe and our_exe in exe) or ('common_files' in exe):
                            p.kill()
                            self._append_log(f"Terminated stale tor.exe process (PID {p.info['pid']})")
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        except Exception as e:
            self._append_log(f"Process check note: {e}")

        # Wait briefly for OS to release the socket
        if not self.external_mode:
            for _ in range(6):
                if not self._is_port_busy(self.socks_port):
                    break
                time.sleep(0.25)

    def _assign_job_object(self, proc):
        if sys.platform != "win32" or not proc:
            return
        try:
            import ctypes
            from ctypes import wintypes

            class IO_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ('ReadOperationCount', ctypes.c_uint64),
                    ('WriteOperationCount', ctypes.c_uint64),
                    ('OtherOperationCount', ctypes.c_uint64),
                    ('ReadTransferCount', ctypes.c_uint64),
                    ('WriteTransferCount', ctypes.c_uint64),
                    ('OtherTransferCount', ctypes.c_uint64),
                ]

            class JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ('PerProcessUserTimeLimit', ctypes.c_int64),
                    ('PerJobUserTimeLimit', ctypes.c_int64),
                    ('LimitFlags', wintypes.DWORD),
                    ('MinimumWorkingSetSize', ctypes.c_size_t),
                    ('MaximumWorkingSetSize', ctypes.c_size_t),
                    ('ActiveProcessLimit', wintypes.DWORD),
                    ('Affinity', ctypes.c_size_t),
                    ('PriorityClass', wintypes.DWORD),
                    ('SchedulingClass', wintypes.DWORD),
                ]

            class JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ('BasicLimitInformation', JOBOBJECT_BASIC_LIMIT_INFORMATION),
                    ('IoInfo', IO_COUNTERS),
                    ('ProcessMemoryLimit', ctypes.c_size_t),
                    ('JobMemoryLimit', ctypes.c_size_t),
                    ('PeakProcessMemoryLimit', ctypes.c_size_t),
                    ('PeakJobMemoryLimit', ctypes.c_size_t),
                ]

            k32 = ctypes.windll.kernel32
            hJob = k32.CreateJobObjectW(None, None)
            if hJob:
                info = JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
                info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                k32.SetInformationJobObject(hJob, 9, ctypes.byref(info), ctypes.sizeof(info))
                hProc = k32.OpenProcess(0x1F0FFF, False, proc.pid)
                if hProc:
                    k32.AssignProcessToJobObject(hJob, hProc)
                    k32.CloseHandle(hProc)
                self._job_handle = hJob
        except Exception:
            pass

    def start(self):
        if self.status == TorStatus.RUNNING:
            return True

        self._is_terminating = False
        self._last_error_detail = None

        if self.external_mode:
            self._append_log(f"External Tor mode: checking SOCKS port {self.socks_port}...")
            self.status = TorStatus.STARTING
            self.status_detail = f"Connecting to external Tor on port {self.socks_port}..."
            self.bootstrap_progress = 50
            self._notify_status()

            def _test_external():
                res = self.test_connection()
                if res.get("ok"):
                    self.status = TorStatus.RUNNING
                    self.status_detail = f"External Tor is active (port {self.socks_port})"
                    self.bootstrap_progress = 100
                    self._append_log(f"External Tor verified successfully. Exit IP: {res.get('ip')}")
                    if self.auto_route_telegram:
                        self.sync_telegram_proxy(True)
                else:
                    self.status = TorStatus.ERROR
                    self.status_detail = f"External Tor unreachable: {res.get('error')}"
                    self.bootstrap_progress = 0
                    self._append_log(f"External Tor verification failed: {res.get('error')}")
                self._notify_status()

            threading.Thread(target=_test_external, daemon=True).start()
            return True

        # Clean up any stale or orphaned tor.exe processes from previous runs
        self._kill_stale_tor_processes()

        # If port is still occupied, check if a healthy Tor proxy is already answering
        if self._is_port_busy(self.socks_port):
            self._append_log(f"Port {self.socks_port} is active, testing if existing Tor instance is responsive...")
            check_res = self.test_connection()
            if check_res.get("ok"):
                self.status = TorStatus.RUNNING
                self.status_detail = f"Tor already active (port {self.socks_port})"
                self.bootstrap_progress = 100
                self._append_log(f"Attached to existing Tor proxy on port {self.socks_port}. Exit IP: {check_res.get('ip')}")
                if self.auto_route_telegram:
                    self.sync_telegram_proxy(True)
                self._notify_status()
                return True

        tor_exe_str = self.find_tor_executable()
        if not tor_exe_str:
            self.status = TorStatus.ERROR
            self.status_detail = "tor.exe not found. Click 'Download Tor'."
            self._append_log("Startup error: tor.exe executable not found.")
            self._notify_status()
            return False

        tor_exe = Path(tor_exe_str)
        tor_cwd = tor_exe.parent
        self.tor_data_dir.mkdir(parents=True, exist_ok=True)

        # Calculate relative path from tor_cwd to avoid Windows non-ASCII / Cyrillic path bugs
        try:
            rel_data_dir = os.path.relpath(self.tor_data_dir, tor_cwd).replace("\\", "/")
        except Exception:
            rel_data_dir = "./data"

        torrc_lines = [
            f"SocksPort 127.0.0.1:{self.socks_port}",
            f'DataDirectory "{rel_data_dir}"',
            "Log notice stdout"
        ]

        plugin_dir = Path(__file__).resolve().parent

        geoip = self.tor_data_dir / "geoip"
        if not geoip.is_file():
            for cand_g in [tor_cwd.parent / "data" / "geoip", plugin_dir / "tor" / "data" / "geoip"]:
                if cand_g.is_file():
                    geoip = cand_g
                    break

        geoip6 = self.tor_data_dir / "geoip6"
        if not geoip6.is_file():
            for cand_g6 in [tor_cwd.parent / "data" / "geoip6", plugin_dir / "tor" / "data" / "geoip6"]:
                if cand_g6.is_file():
                    geoip6 = cand_g6
                    break

        if geoip.is_file():
            try:
                rel_g = os.path.relpath(geoip, tor_cwd).replace("\\", "/")
                torrc_lines.append(f'GeoIPFile "{rel_g}"')
            except Exception:
                torrc_lines.append(f'GeoIPFile "{geoip}"')
        if geoip6.is_file():
            try:
                rel_g6 = os.path.relpath(geoip6, tor_cwd).replace("\\", "/")
                torrc_lines.append(f'GeoIPv6File "{rel_g6}"')
            except Exception:
                torrc_lines.append(f'GeoIPv6File "{geoip6}"')

        # Configure Pluggable Transports / Bridges
        if self.use_bridges:
            pt_dir = tor_cwd / "pluggable_transports"
            lyrebird_exe = pt_dir / "lyrebird.exe"
            conjure_exe = pt_dir / "conjure-client.exe"
            if not lyrebird_exe.is_file():
                cand_lyre = plugin_dir / "tor" / "tor" / "pluggable_transports" / "lyrebird.exe"
                if cand_lyre.is_file():
                    lyrebird_exe = cand_lyre

            bridges_list = []
            if self.bridges_text.strip():
                raw_bridges = [line.strip() for line in self.bridges_text.splitlines() if line.strip()]
                for b in raw_bridges:
                    clean_b = re.sub(r"^bridge\s+", "", b, flags=re.IGNORECASE)
                    bridges_list.append(clean_b)
            else:
                try:
                    fresh = self.fetch_online_bridges(count=3)
                    if fresh:
                        bridges_list.extend(fresh)
                        self.bridges_text = "\n".join(fresh)
                        self._notify_bridges_updated(self.bridges_text)
                except Exception as e:
                    self._append_log(f"Online bridge lookup note: {e}")
                    for fb in DEFAULT_FALLBACK_BRIDGES:
                        clean_b = re.sub(r"^bridge\s+", "", fb, flags=re.IGNORECASE)
                        bridges_list.append(clean_b)
                    self.bridges_text = "\n".join(bridges_list)
                    self._notify_bridges_updated(self.bridges_text)

            if bridges_list:
                torrc_lines.append("UseBridges 1")
                if lyrebird_exe.is_file():
                    rel_lyrebird = os.path.relpath(lyrebird_exe, tor_cwd).replace("/", "\\")
                    torrc_lines.append(f"ClientTransportPlugin meek_lite,obfs2,obfs3,obfs4,scramblesuit,webtunnel exec {rel_lyrebird}")
                    torrc_lines.append(f"ClientTransportPlugin snowflake exec {rel_lyrebird}")
                if conjure_exe.is_file():
                    rel_conjure = os.path.relpath(conjure_exe, tor_cwd).replace("/", "\\")
                    torrc_lines.append(f"ClientTransportPlugin conjure exec {rel_conjure} -registerURL https://registration.refraction.network/api")

                for b in bridges_list:
                    torrc_lines.append(f"Bridge {b}")
                self._append_log(f"Configured bridges: {len(bridges_list)} (Pluggable Transports active)")

        torrc_path = tor_cwd / "torrc.fw"
        try:
            with open(torrc_path, "w", encoding="utf-8") as f:
                f.write("\n".join(torrc_lines) + "\n")
        except Exception as e:
            self._append_log(f"Failed to write torrc: {e}")
            self.status = TorStatus.ERROR
            self.status_detail = f"Failed to write torrc: {e}"
            self._notify_status()
            return False

        cmd = [str(tor_exe), "-f", "torrc.fw"]
        self._append_log(f"Starting Tor process (port {self.socks_port})...")
        self.status = TorStatus.STARTING
        self.status_detail = "Starting Tor process..."
        self.bootstrap_progress = 0
        self._notify_status()

        try:
            self.process = subprocess.Popen(
                cmd,
                cwd=str(tor_cwd),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
            self._assign_job_object(self.process)
        except Exception as e:
            self.status = TorStatus.ERROR
            self.status_detail = f"Launch error: {e}"
            self._append_log(f"Failed to launch process: {e}")
            self._notify_status()
            return False

        self._reader_thread = threading.Thread(target=self._read_output, daemon=True)
        self._reader_thread.start()

        self._monitor_thread = threading.Thread(target=self._monitor_process, daemon=True)
        self._monitor_thread.start()

        if self.auto_search_bridges:
            self._start_bootstrap_watchdog(self.process)
        return True

    def _read_output(self):
        proc = self.process
        if not proc or not proc.stdout:
            return

        re_bootstrap = re.compile(r"Bootstrapped\s+(\d+)%")
        for line in proc.stdout:
            self._append_log(line)
            lower = line.lower()
            if "wsaeaddrinuse" in lower or "address already in use" in lower:
                self._last_error_detail = f"Port {self.socks_port} is busy by another app"
            elif "could not bind" in lower and not self._last_error_detail:
                self._last_error_detail = f"Failed to bind port {self.socks_port}"
            elif "failed to parse/validate config" in lower and not self._last_error_detail:
                self._last_error_detail = "Invalid torrc configuration"

            m = re_bootstrap.search(line)
            if m:
                pct = int(m.group(1))
                self.bootstrap_progress = pct
                self.status_detail = f"Connecting to Tor network: {pct}%"
                if pct >= 100:
                    self.status = TorStatus.RUNNING
                    self._auto_retry_count = 0
                    self.status_detail = f"Tor is running (SOCKS5 127.0.0.1:{self.socks_port})"
                    self._append_log(f"Tor successfully connected! SOCKS5 active on port {self.socks_port}.")
                    if self.auto_route_telegram:
                        self.sync_telegram_proxy(True)
                    self._start_telegram_watchdog()
                self._notify_status()

    def _start_telegram_watchdog(self):
        if self._tg_watchdog_running:
            return
        self._tg_watchdog_running = True

        def _loop():
            consecutive_failures = 0
            while not self._is_terminating:
                time.sleep(40)
                if self.status != TorStatus.RUNNING or self._is_terminating:
                    continue
                try:
                    import requests
                    proxies = {
                        "http": f"socks5h://127.0.0.1:{self.socks_port}",
                        "https": f"socks5h://127.0.0.1:{self.socks_port}"
                    }
                    r = requests.get("https://api.telegram.org", proxies=proxies, timeout=8)
                    if r.status_code in (200, 404):
                        consecutive_failures = 0
                    else:
                        consecutive_failures += 1
                except Exception:
                    consecutive_failures += 1

                if consecutive_failures >= 2 and not self._is_terminating and self.status == TorStatus.RUNNING:
                    self._append_log("[Telegram Watchdog] Telegram connection lost through current Tor bridge. Auto-recovering...")
                    consecutive_failures = 0
                    self._trigger_auto_recover()

            self._tg_watchdog_running = False

        threading.Thread(target=_loop, daemon=True).start()

    def _start_bootstrap_watchdog(self, proc):
        def _watchdog():
            time.sleep(16)
            if self.process is proc and self.status == TorStatus.STARTING and self.bootstrap_progress < 100 and not self._is_terminating:
                self._append_log(f"[Auto-Heal] Connection hung at {self.bootstrap_progress}%. Auto-searching verified working bridges to bypass network restrictions...")
                self._auto_retry_count += 1
                self.use_bridges = True
                self._trigger_auto_recover()
        threading.Thread(target=_watchdog, daemon=True).start()

    def fetch_online_bridges(self, count=3):
        import urllib.request
        import random
        import re
        import concurrent.futures

        urls = [
            "https://raw.githubusercontent.com/scriptzteam/Tor-Bridges-Collector-v2/main/bridges/webtunnel_tested.txt",
            "https://cdn.jsdelivr.net/gh/scriptzteam/Tor-Bridges-Collector-v2@main/bridges/webtunnel_tested.txt",
            "https://raw.githubusercontent.com/scriptzteam/Tor-Bridges-Collector-v2/main/bridges/obfs4_tested.txt",
            "https://cdn.jsdelivr.net/gh/scriptzteam/Tor-Bridges-Collector-v2@main/bridges/obfs4_tested.txt",
        ]

        raw_candidates = []
        for url in urls:
            try:
                self._append_log(f"Querying bridge mirror {url[:45]}...")
                req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
                with urllib.request.urlopen(req, timeout=6) as resp:
                    text = resp.read().decode("utf-8", errors="ignore")
                    lines = [l.strip() for l in text.splitlines() if l.strip()]
                    for line in lines:
                        clean = re.sub(r"^bridge\s+", "", line, flags=re.IGNORECASE)
                        if clean.lower().startswith("webtunnel") and "url=https://" in clean:
                            raw_candidates.append(clean)
                        elif re.match(r"^obfs4\s+\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}:\d+", clean, re.I):
                            raw_candidates.append(clean)
                if raw_candidates:
                    break
            except Exception as e:
                self._append_log(f"Mirror query note: {e}")

        if not raw_candidates:
            raw_candidates = list(DEFAULT_FALLBACK_BRIDGES)

        verified_bridges = []
        webtunnel_items = [b for b in raw_candidates if b.lower().startswith("webtunnel")]
        other_items = [b for b in raw_candidates if not b.lower().startswith("webtunnel")]

        def _test_webtunnel(bridge_str):
            m = re.search(r"url=(https://[^/]+)", bridge_str)
            if not m:
                return None
            host = m.group(1)
            try:
                req = urllib.request.Request(host, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=3.0) as res:
                    return bridge_str
            except urllib.error.HTTPError:
                return bridge_str
            except Exception:
                return None

        if webtunnel_items:
            sample_candidates = random.sample(webtunnel_items, min(len(webtunnel_items), 25))
            with concurrent.futures.ThreadPoolExecutor(max_workers=15) as pool:
                results = list(pool.map(_test_webtunnel, sample_candidates))
                verified_bridges = [r for r in results if r]

        if not verified_bridges:
            verified_bridges = other_items or DEFAULT_FALLBACK_BRIDGES

        selected = random.sample(verified_bridges, min(count, len(verified_bridges)))
        self._append_log(f"Verified {len(selected)} working bridges. Pluggable Transports active.")
        return selected

    def rotate_or_fetch_bridges(self):
        self._auto_retry_count = 0
        self._trigger_auto_recover()

    def _trigger_auto_recover(self):
        def _bg():
            try:
                self._is_terminating = True
                if self.process:
                    try:
                        self.process.terminate()
                        self.process.wait(timeout=2)
                    except Exception:
                        try:
                            self.process.kill()
                        except Exception:
                            pass
                    self.process = None
                self._is_terminating = False

                self.status = TorStatus.STARTING
                self.status_detail = "Auto-searching verified working bridges..."
                self.bootstrap_progress = 10
                self._notify_status()

                fresh = self.fetch_online_bridges(count=3)
                if fresh:
                    new_text = "\n".join(fresh)
                    self.bridges_text = new_text
                    self.use_bridges = True
                    self._append_log(f"[Auto-Heal] Selected {len(fresh)} verified working bridges. Restarting Tor...")
                    self._notify_bridges_updated(new_text)
                    self.start()
            except Exception as e:
                self._append_log(f"[Auto-Heal] Auto-heal error: {e}. Retrying...")
                time.sleep(8)
                if not self._is_terminating and self.status != TorStatus.RUNNING:
                    self._trigger_auto_recover()

        threading.Thread(target=_bg, daemon=True).start()

    def _monitor_process(self):
        proc = self.process
        if not proc:
            return
        code = proc.wait()
        if not self._is_terminating:
            self._append_log(f"Tor process terminated with exit code {code}")
            self.status = TorStatus.STOPPED if code == 0 else TorStatus.ERROR
            if code != 0:
                self.status_detail = self._last_error_detail or f"Tor stopped (exit code: {code})"
            else:
                self.status_detail = "Tor is stopped"
            self.bootstrap_progress = 0
            self.process = None
            if self.auto_route_telegram:
                self.sync_telegram_proxy(False)
            self._notify_status()

    def stop(self):
        self._is_terminating = True
        self._append_log("Stopping Tor...")
        if self.process:
            try:
                self.process.terminate()
                try:
                    self.process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.process.kill()
            except Exception as e:
                self._append_log(f"Error terminating process: {e}")
            self.process = None

        if hasattr(self, "_job_handle") and self._job_handle:
            try:
                import ctypes
                ctypes.windll.kernel32.CloseHandle(self._job_handle)
            except Exception:
                pass
            self._job_handle = None

        if not self.external_mode:
            self._kill_stale_tor_processes()

        self.status = TorStatus.STOPPED
        self.status_detail = "Tor is stopped"
        self.bootstrap_progress = 0
        if self.auto_route_telegram:
            self.sync_telegram_proxy(False)
        self._append_log("Tor stopped successfully.")
        self._notify_status()

    def test_connection(self):
        import requests
        proxies = {
            "http": f"socks5h://127.0.0.1:{self.socks_port}",
            "https": f"socks5h://127.0.0.1:{self.socks_port}"
        }
        result = {
            "ok": False,
            "ip": None,
            "is_tor": False,
            "telegram_ok": False,
            "telegram_ms": 0,
            "error": None
        }

        # 1. Test Tor exit connectivity and get public IP
        try:
            r = requests.get("https://check.torproject.org/api/ip", proxies=proxies, timeout=10)
            if r.status_code == 200:
                data = r.json()
                result["ip"] = data.get("IP")
                result["is_tor"] = bool(data.get("IsTor", False))
                result["ok"] = True
            else:
                result["error"] = f"check.torproject.org status {r.status_code}"
        except Exception as e:
            # Fallback IP check service
            try:
                r_fallback = requests.get("https://api.ipify.org?format=json", proxies=proxies, timeout=10)
                if r_fallback.status_code == 200:
                    result["ip"] = r_fallback.json().get("ip")
                    result["is_tor"] = True
                    result["ok"] = True
            except Exception:
                result["error"] = str(e)
                return result

        # 2. Test Telegram API connectivity
        try:
            t_start = time.perf_counter()
            r_tg = requests.get("https://api.telegram.org", proxies=proxies, timeout=10)
            latency = int((time.perf_counter() - t_start) * 1000)
            if r_tg.status_code in (200, 404):  # 404 root without bot token confirms API is reached
                result["telegram_ok"] = True
                result["telegram_ms"] = latency
            else:
                result["telegram_ok"] = False
        except Exception:
            result["telegram_ok"] = False

        return result

    def sync_telegram_proxy(self, enabled=True):
        import json
        config_path = self.common_dir / "plugin_configs" / "NotificationsPlugin.json"
        if not config_path.is_file():
            return
        try:
            data = {}
            if self.api:
                try:
                    data = self.api.load_plugin_config("NotificationsPlugin")
                except Exception:
                    data = {}
            if not data:
                with open(config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

            data["proxy_enabled"] = bool(enabled)
            if enabled:
                data["proxy_url"] = f"socks5h://127.0.0.1:{self.socks_port}"

            from app.utils.system import _atomic_write_bytes
            content = json.dumps(data, indent=4, ensure_ascii=False).encode("utf-8")
            _atomic_write_bytes(str(config_path), content)

            if self.api:
                try:
                    self.api.save_plugin_config("NotificationsPlugin", data)
                except Exception:
                    pass
                try:
                    gui = self.api.ctx.get("gui")
                    if gui and hasattr(gui, "plugin_manager") and gui.plugin_manager:
                        for p in gui.plugin_manager.plugins:
                            if p.__class__.__name__ == "NotificationsPlugin" and hasattr(p, "_ui_adapter"):
                                adapter = p._ui_adapter
                                if hasattr(adapter, "vars"):
                                    was_loading = getattr(adapter, "_loading", False)
                                    adapter._loading = True
                                    try:
                                        if "proxy_enabled" in adapter.vars:
                                            adapter.vars["proxy_enabled"].set(bool(enabled))
                                        if enabled and "proxy_url" in adapter.vars:
                                            adapter.vars["proxy_url"].set(f"socks5h://127.0.0.1:{self.socks_port}")
                                    finally:
                                        adapter._loading = was_loading
                except Exception:
                    pass

            self._append_log(f"Telegram proxy settings updated: proxy_enabled={enabled}, URL={data.get('proxy_url')}")
        except Exception as e:
            self._append_log(f"Failed to update NotificationsPlugin settings: {e}")
