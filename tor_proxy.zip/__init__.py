import os
import sys
import json
import time
import threading
import tkinter as tk
from pathlib import Path
from typing import Optional

from app.plugin.base import BasePlugin
from app.paths import CONFIG_PATH, PLUGINS_CONFIG_DIR
from .tor_service import TorService, TorStatus
from .mini_console import TorMiniConsoleWindow

PLUGIN_DIR = Path(__file__).resolve().parent
LOCAL_CONFIG_FILE = PLUGIN_DIR / "config.json"
LEGACY_CONFIG_FILE = Path(PLUGINS_CONFIG_DIR) / "TorProxyPlugin.json"


class TorProxyPlugin(BasePlugin):
    version = "2.0.0"
    target_tab = "plugins"

    def __init__(self, api):
        super().__init__(api)
        self.config = self._load_data()
        self.project_root = Path(api.project_root) if hasattr(api, "project_root") else Path(__file__).resolve().parents[2]
        self.tor_service = TorService(self.project_root)
        self.tor_service.api = api
        self.tor_service.socks_port = int(self.config.get("socks_port", 9050))
        self.tor_service.use_bridges = bool(self.config.get("use_bridges", True))
        self.tor_service.auto_search_bridges = bool(self.config.get("auto_search_bridges", True))
        self.tor_service.auto_route_telegram = bool(self.config.get("auto_route_telegram", True))
        self.tor_service.auto_route_discord = bool(self.config.get("auto_route_discord", True))
        self.tor_service.bridges_text = str(self.config.get("bridges_text", ""))

        self.tor_service.set_bridges_updated_callback(self._on_bridges_updated)
        self.tor_service.add_listener(self._on_tor_status_changed)
        self.tor_service.add_log_listener(self._on_log_received)

        self.mini_console: Optional[TorMiniConsoleWindow] = None
        self._descriptions_cache = None
        self._last_tick_check = 0.0
        self._anim_timer = None
        self._anim_step = 0

        # Auto-start Tor if enabled
        if bool(self.config.get("enabled", True)):
            threading.Thread(target=self._safe_start_tor, daemon=True).start()

    # =========================================================================
    # CONFIGURATION
    # =========================================================================

    def get_config(self) -> dict:
        return self._load_data()

    def save_config(self, config_dict: dict):
        self._save_data(config_dict)

    def _load_data(self) -> dict:
        cfg = {}
        if LOCAL_CONFIG_FILE.exists():
            try:
                cfg = json.loads(LOCAL_CONFIG_FILE.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                cfg = {}
        elif LEGACY_CONFIG_FILE.exists():
            try:
                cfg = json.loads(LEGACY_CONFIG_FILE.read_text(encoding="utf-8", errors="ignore"))
            except Exception:
                cfg = {}

        if not isinstance(cfg, dict):
            cfg = {}

        defaults = {
            "enabled": True,
            "socks_port": 9050,
            "use_bridges": True,
            "auto_search_bridges": True,
            "auto_route_telegram": True,
            "auto_route_discord": True,
            "bridges_text": ""
        }
        updated = False
        for k, v in defaults.items():
            if k not in cfg:
                cfg[k] = v
                updated = True

        if updated or not LOCAL_CONFIG_FILE.exists():
            self._save_data(cfg)

        return cfg

    def _save_data(self, data: dict):
        self.config = data
        try:
            LOCAL_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
            tmp_path = LOCAL_CONFIG_FILE.with_suffix(".tmp")
            content = json.dumps(data, indent=2, ensure_ascii=False)
            tmp_path.write_text(content, encoding="utf-8")
            os.replace(tmp_path, LOCAL_CONFIG_FILE)

            try:
                LEGACY_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
                LEGACY_CONFIG_FILE.write_text(content, encoding="utf-8")
            except Exception:
                pass
        except Exception as e:
            if hasattr(self, "api") and self.api:
                self.api.log(f"Failed to save TorProxy config: {e}")

    def _on_bridges_updated(self, bridges_text: str):
        self.config["bridges_text"] = bridges_text
        self._save_data(self.config)

    # =========================================================================
    # MINI CONSOLE MANAGEMENT
    # =========================================================================

    def _ensure_mini_console(self, hint_widget=None):
        if self.mini_console and self.mini_console.window and self.mini_console.window.winfo_exists():
            return self.mini_console

        root = None
        if hint_widget and hasattr(hint_widget, "winfo_toplevel"):
            try:
                root = hint_widget.winfo_toplevel()
            except Exception:
                pass
        if not root and hasattr(self, "active_toggle_btn") and self.active_toggle_btn and self.active_toggle_btn.winfo_exists():
            try:
                root = self.active_toggle_btn.winfo_toplevel()
            except Exception:
                pass
        if not root and hasattr(self.api, "ctx") and self.api.ctx:
            gui = self.api.ctx.get("gui")
            if gui and hasattr(gui, "root"):
                root = gui.root

        if not self.mini_console and root:
            self.mini_console = TorMiniConsoleWindow(root)
            # Transfer all buffered Tor logs
            for l in self.tor_service.log_lines:
                self.mini_console.append_log(l)
            self.mini_console.update_status(self.tor_service.status)

        return self.mini_console

    def _toggle_console(self):
        mc = self._ensure_mini_console()
        if mc:
            mc.toggle()

    def _on_log_received(self, line: str):
        if self.mini_console:
            self.mini_console.append_log(line)

    # =========================================================================
    # TOR LIFECYCLE & TICK
    # =========================================================================

    def _safe_start_tor(self):
        try:
            if not self.tor_service.is_tor_installed():
                self.tor_service.download_tor_bundle()
            self.tor_service.start()
        except Exception as e:
            if hasattr(self, "api") and self.api:
                self.api.log(f"Tor startup error: {e}")

    def on_enable(self, ctx=None):
        self.config["enabled"] = True
        self._save_data(self.config)
        threading.Thread(target=self._safe_start_tor, daemon=True).start()

    def on_disable(self, ctx=None):
        self.config["enabled"] = False
        self._save_data(self.config)
        threading.Thread(target=self.tor_service.stop, daemon=True).start()

    def on_shutdown(self, ctx=None):
        try:
            if self.mini_console:
                self.mini_console.hide()
            self.tor_service.stop()
        except Exception:
            pass

    def on_tick(self, *args, **kwargs):
        now = time.time()
        if now - self._last_tick_check < 30.0:
            return
        self._last_tick_check = now

        if bool(self.config.get("enabled", True)):
            if self.tor_service.status == TorStatus.STOPPED:
                threading.Thread(target=self._safe_start_tor, daemon=True).start()

    # =========================================================================
    # DESCRIPTION BINDING (FARM WATCHER DESCRIPTION PANEL)
    # =========================================================================

    def _bind_desc(self, widget, key: str, parent_frame=None):
        if not widget:
            return

        bound = False
        target = widget
        while target:
            if hasattr(target, "_bind_description"):
                try:
                    target._bind_description(widget, key, plugin=self)
                    bound = True
                    break
                except Exception:
                    pass
            target = getattr(target, "master", None)

        if not bound and parent_frame:
            target = parent_frame
            while target:
                if hasattr(target, "_bind_description"):
                    try:
                        target._bind_description(widget, key, plugin=self)
                        bound = True
                        break
                    except Exception:
                        pass
                target = getattr(target, "master", None)

        def _push(_event=None):
            try:
                gui = getattr(self.api, "ctx", {}).get("gui") if hasattr(self, "api") else None
                lang = "en"
                if gui and hasattr(gui, "get_description_language"):
                    lang = gui.get_description_language()
                if lang not in ("ru", "en"):
                    lang = "en"

                desc_path = PLUGIN_DIR / "descriptions.json"
                if not self._descriptions_cache:
                    if desc_path.is_file():
                        try:
                            with open(desc_path, "r", encoding="utf-8") as f:
                                self._descriptions_cache = json.load(f)
                        except Exception:
                            self._descriptions_cache = {}

                item = (self._descriptions_cache or {}).get(key) or (self._descriptions_cache or {}).get(key.lower()) or {}
                lang_data = item.get(lang) or item.get("en") or {}
                heading = lang_data.get("title") or key.replace("_", " ").title()
                text = lang_data.get("text", "")
                if not text:
                    return

                curr = widget
                while curr:
                    if hasattr(curr, "set_description"):
                        curr.set_description(heading, text)
                        return
                    curr = getattr(curr, "master", None)

                if parent_frame:
                    curr = parent_frame
                    while curr:
                        if hasattr(curr, "set_description"):
                            curr.set_description(heading, text)
                            return
                        curr = getattr(curr, "master", None)
            except Exception:
                pass

        widget.bind("<Enter>", _push, add="+")
        widget.bind("<FocusIn>", _push, add="+")
        if hasattr(widget, "label") and isinstance(widget.label, tk.Widget):
            widget.label.bind("<Enter>", _push, add="+")
            widget.label.bind("<FocusIn>", _push, add="+")

    # =========================================================================
    # USER INTERFACE BUILDER
    # =========================================================================

    def build_settings_ui(self, parent_frame):
        bg = "#181818"
        try:
            if hasattr(parent_frame, "cget"):
                bg = parent_frame.cget("bg") or bg
        except Exception:
            pass

        card_bg = "#121212"
        border_col = "#2a2a2a"

        for child in parent_frame.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass

        main_box = tk.Frame(parent_frame, bg=bg)
        main_box.pack(fill="both", expand=True)

        # Ensure mini console instance is ready
        self._ensure_mini_console(parent_frame)

        # ---------------------------------------------------------------------
        # Top Header Bar: Title, Console Button & Main Action Toggle
        # ---------------------------------------------------------------------
        header_card = tk.Frame(main_box, bg=bg)
        header_card.pack(fill="x", padx=16, pady=(12, 10))

        title_col = tk.Frame(header_card, bg=bg)
        title_col.pack(side="left", fill="y")

        title_lbl = tk.Label(
            title_col,
            text="Tor Proxy",
            bg=bg,
            fg="#ffffff",
            font=("Segoe UI", 12, "bold")
        )
        title_lbl.pack(anchor="w")

        subtitle_lbl = tk.Label(
            title_col,
            text="SOCKS5 Proxy 127.0.0.1:9050 • Automatic Bridge Scanner",
            bg=bg,
            fg="#888888",
            font=("Segoe UI", 8)
        )
        subtitle_lbl.pack(anchor="w", pady=(1, 0))

        # Right Action Buttons
        header_right = tk.Frame(header_card, bg=bg)
        header_right.pack(side="right")

        # Console Button
        btn_console = tk.Button(
            header_right,
            text="Console",
            bg="#222733",
            fg="#cccccc",
            activebackground="#2f3747",
            activeforeground="#ffffff",
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            bd=0,
            padx=14,
            pady=6,
            cursor="hand2",
            command=self._toggle_console
        )
        btn_console.pack(side="left", padx=(0, 8))
        self._bind_desc(btn_console, "open_console", parent_frame)

        # Main Toggle Button: ENABLED / DISABLED
        self.active_toggle_btn = tk.Button(
            header_right,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
            relief="flat",
            bd=0,
            padx=18,
            pady=6
        )
        self.active_toggle_btn.pack(side="left")

        def _update_toggle_visual():
            if not hasattr(self, "active_toggle_btn") or not self.active_toggle_btn.winfo_exists():
                return
            is_active = bool(self.config.get("enabled", True))
            if is_active:
                self.active_toggle_btn.configure(
                    text="ENABLED",
                    bg="#0b5519",
                    fg="#00ff66",
                    activebackground="#147225",
                    activeforeground="#ffffff"
                )
            else:
                self.active_toggle_btn.configure(
                    text="DISABLED",
                    bg="#3a2525",
                    fg="#ff8888",
                    activebackground="#5a3535",
                    activeforeground="#ffffff"
                )

        self._sync_toggle_visual = _update_toggle_visual

        self._toggle_lock = threading.Lock()

        def _on_toggle(event=None):
            if not self._toggle_lock.acquire(blocking=False):
                return "break"

            def _bg_toggle():
                try:
                    new_val = not bool(self.config.get("enabled", True))
                    self.config["enabled"] = new_val
                    self._save_data(self.config)
                    if hasattr(self, "_sync_toggle_visual") and hasattr(self, "active_toggle_btn") and self.active_toggle_btn.winfo_exists():
                        self.active_toggle_btn.after(0, self._sync_toggle_visual)

                    if new_val:
                        self._safe_start_tor()
                    else:
                        self.tor_service.stop()

                    if hasattr(self, "active_toggle_btn") and self.active_toggle_btn.winfo_exists():
                        self.active_toggle_btn.after(0, self._update_status_ui)
                finally:
                    self._toggle_lock.release()

            threading.Thread(target=_bg_toggle, daemon=True).start()
            return "break"

        self.active_toggle_btn.configure(command=_on_toggle)
        _update_toggle_visual()

        # Bind descriptions to header elements
        self._bind_desc(self.active_toggle_btn, "enabled", parent_frame)
        self._bind_desc(title_lbl, "tor_proxy", parent_frame)
        self._bind_desc(subtitle_lbl, "tor_proxy", parent_frame)

        # ---------------------------------------------------------------------
        # Status Card (Real-time connection & bridge state)
        # ---------------------------------------------------------------------
        status_card = tk.Frame(
            main_box,
            bg=card_bg,
            bd=0,
            highlightthickness=1,
            highlightbackground=border_col,
            padx=16,
            pady=14
        )
        status_card.pack(fill="x", padx=16, pady=(0, 12))

        # Status Badge Row
        status_top = tk.Frame(status_card, bg=card_bg)
        status_top.pack(fill="x")

        status_header_lbl = tk.Label(
            status_top,
            text="Proxy Status:",
            bg=card_bg,
            fg="#aaaaaa",
            font=("Segoe UI", 9, "bold")
        )
        status_header_lbl.pack(side="left")

        self.status_badge_lbl = tk.Label(
            status_top,
            text="[STOPPED]",
            bg=card_bg,
            fg="#888888",
            font=("Segoe UI", 9, "bold")
        )
        self.status_badge_lbl.pack(side="left", padx=8)

        # Bootstrap percentage / details
        self.status_detail_lbl = tk.Label(
            status_card,
            text="Tor is stopped",
            bg=card_bg,
            fg="#ffffff",
            font=("Segoe UI", 9),
            anchor="w"
        )
        self.status_detail_lbl.pack(fill="x", pady=(6, 8))

        # Bootstrap Progress Visual Bar
        self.progress_bg_frame = tk.Frame(status_card, bg="#222222", height=6)
        self.progress_bg_frame.pack(fill="x", pady=(0, 10))
        self.progress_bg_frame.pack_propagate(False)

        self.progress_bar = tk.Frame(self.progress_bg_frame, bg="#00ff66", height=6, width=0)
        self.progress_bar.place(x=0, y=0, relheight=1.0, relwidth=0.0)

        # Details Grid: SOCKS Port & Bridges
        details_grid = tk.Frame(status_card, bg=card_bg)
        details_grid.pack(fill="x", pady=(4, 0))

        # Port Info
        lbl_p_title = tk.Label(details_grid, text="Local Endpoint:", bg=card_bg, fg="#888888", font=("Segoe UI", 8))
        lbl_p_title.grid(row=0, column=0, sticky="w", pady=2)
        self.lbl_endpoint = tk.Label(
            details_grid,
            text=f"127.0.0.1:{self.tor_service.socks_port}",
            bg=card_bg,
            fg="#00b0ff",
            font=("Consolas", 9, "bold")
        )
        self.lbl_endpoint.grid(row=0, column=1, sticky="w", padx=(10, 0), pady=2)

        # Bridge Scanner Info
        lbl_b_title = tk.Label(details_grid, text="Bridge Scanner:", bg=card_bg, fg="#888888", font=("Segoe UI", 8))
        lbl_b_title.grid(row=1, column=0, sticky="w", pady=2)
        meta = self.tor_service.get_scanner_info()
        ver_str = meta.get("version", "1.0.5")
        self.lbl_bridge_info = tk.Label(
            details_grid,
            text=f"tor-relay-scanner v{ver_str} (Auto-updating)",
            bg=card_bg,
            fg="#00ff66",
            font=("Segoe UI", 8, "bold")
        )
        self.lbl_bridge_info.grid(row=1, column=1, sticky="w", padx=(10, 0), pady=2)

        # Bind descriptions to status widgets
        self._bind_desc(status_card, "proxy_status", parent_frame)
        self._bind_desc(status_header_lbl, "proxy_status", parent_frame)
        self._bind_desc(self.status_badge_lbl, "proxy_status", parent_frame)
        self._bind_desc(self.lbl_bridge_info, "bridges_info", parent_frame)

        self._update_status_ui()
        self._start_animation_loop()

    def _start_animation_loop(self):
        if not hasattr(self, "progress_bar") or not self.progress_bar.winfo_exists():
            return

        def _tick():
            try:
                if not hasattr(self, "progress_bar") or not self.progress_bar.winfo_exists():
                    return
                st = self.tor_service.status
                pct = self.tor_service.bootstrap_progress

                if st in (TorStatus.STARTING, TorStatus.SCANNING):
                    self._anim_step = (self._anim_step + 1) % 10
                    if pct < 15:
                        pulse_w = 0.12 + 0.08 * (self._anim_step / 10.0)
                        self.progress_bar.place(x=0, y=0, relheight=1.0, relwidth=pulse_w)
                elif st == TorStatus.RUNNING:
                    self.progress_bar.place(x=0, y=0, relheight=1.0, relwidth=1.0)
                elif st == TorStatus.STOPPED:
                    self.progress_bar.place(x=0, y=0, relheight=1.0, relwidth=0.0)

                self.progress_bar.after(350, _tick)
            except Exception:
                pass

        self.progress_bar.after(350, _tick)

    def _on_tor_status_changed(self, status, detail, progress):
        try:
            if hasattr(self, "status_badge_lbl") and self.status_badge_lbl.winfo_exists():
                self.status_badge_lbl.after(0, self._update_status_ui)
            if self.mini_console:
                self.mini_console.update_status(status)
        except Exception:
            pass

    def _update_status_ui(self):
        if not hasattr(self, "status_badge_lbl") or not self.status_badge_lbl.winfo_exists():
            return

        st = self.tor_service.status
        detail = self.tor_service.status_detail
        pct = self.tor_service.bootstrap_progress

        colors = {
            TorStatus.RUNNING: ("#00ff66", "[RUNNING]"),
            TorStatus.STARTING: ("#ffaa00", f"[STARTING {pct}%]"),
            TorStatus.SCANNING: ("#00b0ff", "[SCANNING BRIDGES]"),
            TorStatus.ERROR: ("#ff6666", "[ERROR]"),
            TorStatus.STOPPED: ("#888888", "[STOPPED]"),
        }
        col, badge_text = colors.get(st, ("#888888", f"[{st}]"))

        self.status_badge_lbl.configure(text=badge_text, fg=col)
        self.status_detail_lbl.configure(text=detail)

        if hasattr(self, "lbl_bridge_info") and self.lbl_bridge_info.winfo_exists():
            meta = self.tor_service.get_scanner_info()
            ver_str = meta.get("version", "1.0.5")
            self.lbl_bridge_info.configure(text=f"tor-relay-scanner v{ver_str} (Auto-updating)")

        # Update progress bar width
        try:
            fraction = max(0.0, min(1.0, float(pct) / 100.0))
            if st == TorStatus.RUNNING:
                fraction = 1.0
                self.progress_bar.configure(bg="#00ff66")
            elif st in (TorStatus.STARTING, TorStatus.SCANNING):
                bar_color = "#00b0ff" if st == TorStatus.SCANNING else "#ffaa00"
                self.progress_bar.configure(bg=bar_color)
                if fraction < 0.15:
                    fraction = 0.15
            elif st == TorStatus.ERROR:
                self.progress_bar.configure(bg="#ff6666")
                fraction = 1.0
            else:
                fraction = 0.0

            self.progress_bar.place(x=0, y=0, relheight=1.0, relwidth=fraction)
        except Exception:
            pass

    def reload_settings_ui(self, settings_tab):
        self.config = self._load_data()
        if hasattr(self, "_sync_toggle_visual"):
            self._sync_toggle_visual()
        self._update_status_ui()
