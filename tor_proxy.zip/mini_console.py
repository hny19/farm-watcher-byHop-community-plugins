import tkinter as tk
from typing import List, Optional


class TorMiniConsoleWindow:
    def __init__(self, master):
        self.master = master
        self.window: Optional[tk.Toplevel] = None
        self.text_widget: Optional[tk.Text] = None
        self.status_badge: Optional[tk.Label] = None
        self.is_visible = False
        self.log_history: List[str] = []

    def show(self):
        def _do_show():
            try:
                if self.window and self.window.winfo_exists():
                    self.window.deiconify()
                    self.window.lift()
                    self.window.focus_force()
                    try:
                        self.window.attributes("-topmost", True)
                        self.window.after(150, lambda: self.window.attributes("-topmost", False) if self.window and self.window.winfo_exists() else None)
                    except Exception:
                        pass
                    self.is_visible = True
                    return

                self.window = tk.Toplevel(self.master)
                self.window.title("Tor Proxy Console")
                self.window.configure(bg="#0c0e12")
                win_w, win_h = 460, 520
                self.window.geometry(f"{win_w}x{win_h}")
                self.window.minsize(340, 280)

                # Dock beside Farm Watcher main window
                try:
                    self.master.update_idletasks()
                    root_x = self.master.winfo_rootx()
                    root_y = self.master.winfo_rooty()
                    root_w = self.master.winfo_width()
                    root_h = self.master.winfo_height()
                    screen_w = self.master.winfo_screenwidth()
                    screen_h = self.master.winfo_screenheight()

                    if root_w > 100:
                        target_x = root_x + root_w + 10
                        if target_x + win_w > screen_w:
                            target_x = max(10, root_x - win_w - 10)
                        target_y = max(10, min(root_y, screen_h - win_h - 40))
                        self.window.geometry(f"{win_w}x{win_h}+{target_x}+{target_y}")
                except Exception:
                    pass

                self.window.protocol("WM_DELETE_WINDOW", self.hide)
                self._build_ui()

                # Render buffered logs
                for prev_log in self.log_history:
                    self._render_log_line(prev_log)

                self.window.deiconify()
                self.window.lift()
                self.window.focus_force()
                try:
                    self.window.attributes("-topmost", True)
                    self.window.after(150, lambda: self.window.attributes("-topmost", False) if self.window and self.window.winfo_exists() else None)
                except Exception:
                    pass
                self.is_visible = True
            except Exception as e:
                print(f"[TorProxy MiniConsole] Error showing window: {e}")

        try:
            import threading
            if threading.current_thread() is threading.main_thread():
                _do_show()
            elif self.master and hasattr(self.master, "after"):
                self.master.after(0, _do_show)
            else:
                _do_show()
        except Exception:
            _do_show()

    def hide(self):
        def _do_hide():
            if self.window and self.window.winfo_exists():
                self.window.withdraw()
            self.is_visible = False

        try:
            if self.master and hasattr(self.master, "after"):
                self.master.after(0, _do_hide)
            else:
                _do_hide()
        except Exception:
            pass

    def toggle(self):
        if self.is_visible and self.window and self.window.winfo_exists():
            self.hide()
        else:
            self.show()

    def _build_ui(self):
        header = tk.Frame(self.window, bg="#161920", height=32, padx=10, pady=5)
        header.pack(fill="x", side="top")

        lbl_title = tk.Label(header, text="Tor Proxy", bg="#161920", fg="#00ff66", font=("Segoe UI", 9, "bold"))
        lbl_title.pack(side="left")

        self.status_badge = tk.Label(
            header,
            text="● STOPPED",
            bg="#161920",
            fg="#7a8290",
            font=("Consolas", 8, "bold"),
            padx=6
        )
        self.status_badge.pack(side="left", padx=6)

        btn_clear = tk.Button(
            header,
            text="Clear",
            command=self.clear,
            bg="#222733",
            fg="#cccccc",
            activebackground="#2f3747",
            activeforeground="#ffffff",
            font=("Segoe UI", 8),
            relief="flat",
            bd=0,
            padx=8,
            cursor="hand2"
        )
        btn_clear.pack(side="right")

        text_frame = tk.Frame(self.window, bg="#0c0e12", padx=2, pady=2)
        text_frame.pack(fill="both", expand=True)

        scrollbar = tk.Scrollbar(text_frame, bg="#161920", troughcolor="#0c0e12", bd=0, width=8)
        scrollbar.pack(side="right", fill="y")

        self.text_widget = tk.Text(
            text_frame,
            bg="#0c0e12",
            fg="#e0e4eb",
            insertbackground="#ffffff",
            font=("Consolas", 9),
            wrap=tk.WORD,
            state="disabled",
            bd=0,
            relief="flat",
            highlightthickness=0,
            yscrollcommand=scrollbar.set,
            padx=6,
            pady=4
        )
        self.text_widget.pack(fill="both", expand=True)
        scrollbar.config(command=self.text_widget.yview)

        # Color tags
        self.text_widget.tag_config("SUCCESS", foreground="#00ff66")
        self.text_widget.tag_config("ERROR", foreground="#ff5555")
        self.text_widget.tag_config("WARN", foreground="#ffbb33")
        self.text_widget.tag_config("INFO", foreground="#00b0ff")
        self.text_widget.tag_config("MUTED", foreground="#7a8290")

    def append_log(self, text: str):
        line = str(text or "").strip()
        if not line:
            return
        self.log_history.append(line)
        if len(self.log_history) > 400:
            self.log_history.pop(0)

        def _update():
            if not self.window or not self.window.winfo_exists() or not self.text_widget:
                return
            self._render_log_line(line)

        try:
            if self.master and hasattr(self.master, "after"):
                self.master.after(0, _update)
            else:
                _update()
        except Exception:
            pass

    def _render_log_line(self, text: str):
        if not self.text_widget or not self.text_widget.winfo_exists():
            return

        tag = None
        u_text = text.upper()
        if "100%" in u_text or "SUCCESS" in u_text or "RUNNING" in u_text or "VERIFIED" in u_text or "CONNECTED" in u_text:
            tag = "SUCCESS"
        elif "ERR" in u_text or "FAIL" in u_text or "EXCEPTION" in u_text or "BUSY" in u_text or "TERMINATED" in u_text:
            tag = "ERROR"
        elif "WARN" in u_text or "STUCK" in u_text or "RETRY" in u_text or "PAUSING" in u_text:
            tag = "WARN"
        elif "TOR-RELAY-SCANNER" in u_text or "AUTO-HEAL" in u_text or "SCANNING" in u_text or "SWITCHING" in u_text or "BRIDGE" in u_text:
            tag = "INFO"
        elif "NOTICE" in u_text or "BOOTSTRAPPED" in u_text:
            tag = "MUTED"

        self.text_widget.config(state="normal")
        if tag:
            self.text_widget.insert("end", text + "\n", tag)
        else:
            self.text_widget.insert("end", text + "\n")

        try:
            line_count = int(self.text_widget.index("end-1c").split(".")[0])
            if line_count > 600:
                self.text_widget.delete("1.0", f"{line_count - 600}.0")
        except Exception:
            pass

        self.text_widget.see("end")
        self.text_widget.config(state="disabled")

    def update_status(self, status: str):
        if not self.status_badge or not self.status_badge.winfo_exists():
            return
        colors = {
            "RUNNING": ("● RUNNING", "#00ff66"),
            "STARTING": ("● STARTING", "#ffaa00"),
            "SCANNING": ("● SCANNING", "#00b0ff"),
            "ERROR": ("● ERROR", "#ff5555"),
            "STOPPED": ("● STOPPED", "#7a8290"),
        }
        text, fg = colors.get(status, (f"● {status}", "#7a8290"))
        self.status_badge.config(text=text, fg=fg)

    def clear(self):
        self.log_history.clear()
        if self.text_widget and self.text_widget.winfo_exists():
            self.text_widget.config(state="normal")
            self.text_widget.delete("1.0", "end")
            self.text_widget.config(state="disabled")

