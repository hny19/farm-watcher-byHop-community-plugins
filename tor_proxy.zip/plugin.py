import os
import json
from app.plugin.base import BasePlugin
from app.paths import PROJECT_ROOT
from .tor_service import TorService, TorStatus
from .gui import TorProxyUIAdapter

class TorProxyPlugin(BasePlugin):
    version = "1.0.0"
    dependencies = [
        ("socks", "PySocks"),
        ("requests", "requests[socks]"),
    ]
    target_tab = "plugins"

    def __init__(self, api):
        super().__init__(api)
        self.tor_service = TorService(PROJECT_ROOT)
        self.tor_service.api = self.api
        self.descriptions = {}
        self._load_descriptions()

        cfg = self.get_config()
        cfg_changed = False

        if "enabled" not in cfg:
            cfg["enabled"] = True
            cfg_changed = True
        if "use_bridges" not in cfg:
            cfg["use_bridges"] = False
            cfg_changed = True
        if "auto_search_bridges" not in cfg:
            cfg["auto_search_bridges"] = False
            cfg_changed = True
        if "auto_route_telegram" not in cfg:
            cfg["auto_route_telegram"] = False
            cfg_changed = True
        if "auto_route_discord" not in cfg:
            cfg["auto_route_discord"] = False
            cfg_changed = True
        if "auto_start" not in cfg:
            cfg["auto_start"] = False
            cfg_changed = True

        found_tor = self.tor_service.find_tor_executable()
        cfg_tor = str(cfg.get("tor_path", "")).strip()
        if (not cfg_tor or not os.path.isfile(cfg_tor)) and found_tor:
            cfg["tor_path"] = found_tor
            cfg_changed = True
            cfg_tor = found_tor

        if cfg_changed:
            self.save_config(cfg)

        self.tor_service.socks_port = int(cfg.get("socks_port", 9050) or 9050)
        self.tor_service.custom_tor_path = cfg_tor
        self.tor_service.external_mode = bool(cfg.get("external_mode", False))
        self.tor_service.auto_route_telegram = bool(cfg.get("auto_route_telegram", False))
        self.tor_service.auto_route_discord = bool(cfg.get("auto_route_discord", False))
        self.tor_service.use_bridges = bool(cfg.get("use_bridges", False))
        self.tor_service.bridges_text = str(cfg.get("bridges_text", ""))
        self.tor_service.auto_search_bridges = bool(cfg.get("auto_search_bridges", False))

        # Register REST API routes
        self.api.register_api_route("GET", "/api/tor/status", self.api_status)
        self.api.register_api_route("POST", "/api/tor/start", self.api_start)
        self.api.register_api_route("POST", "/api/tor/stop", self.api_stop)
        self.api.register_api_route("POST", "/api/tor/test", self.api_test)
        self.api.register_api_route("POST", "/api/tor/fetch-bridges", self.api_fetch_bridges)

        self._protect_notifications()

    def _protect_notifications(self, ctx=None):
        try:
            from app.builtin.notifications.plugin import NotificationsPlugin
            if getattr(NotificationsPlugin, "_persistence_guaranteed", False):
                return
            NotificationsPlugin._persistence_guaranteed = True

            orig_save = NotificationsPlugin.save_config
            def _direct_save_config(np_self, config_dict):
                orig_save(np_self, config_dict)
                try:
                    import os, json, time
                    from app.paths import PLUGINS_CONFIG_DIR
                    from app.utils.system import _atomic_write_bytes
                    cfg_path = os.path.join(PLUGINS_CONFIG_DIR, "NotificationsPlugin.json")
                    cached = np_self.api._config_cache.get("NotificationsPlugin", {})
                    data = cached.get("data")
                    if data:
                        content = json.dumps(data, indent=4, ensure_ascii=False).encode("utf-8")
                        if _atomic_write_bytes(cfg_path, content):
                            now = time.time()
                            try:
                                mtime = os.path.getmtime(cfg_path)
                            except Exception:
                                mtime = now
                            np_self.api._config_cache["NotificationsPlugin"]["mtime"] = mtime
                            if hasattr(np_self.api, "_save_timers") and hasattr(np_self.api, "_timer_lock"):
                                with np_self.api._timer_lock:
                                    t = np_self.api._save_timers.pop("NotificationsPlugin", None)
                                    if t:
                                        t.cancel()
                except Exception:
                    pass
            NotificationsPlugin.save_config = _direct_save_config

            orig_shutdown = NotificationsPlugin.on_shutdown
            def _safe_shutdown(np_self, ctx_in):
                try:
                    if hasattr(np_self, "_ui_adapter") and np_self._ui_adapter:
                        adapter = np_self._ui_adapter
                        if hasattr(adapter, "_schedule_save"):
                            adapter._schedule_save()
                except Exception:
                    pass
                orig_shutdown(np_self, ctx_in)
            NotificationsPlugin.on_shutdown = _safe_shutdown

            try:
                from app.builtin.notifications import security
                if not getattr(security, "_dpapi_enhanced", False):
                    security._dpapi_enhanced = True
                    orig_decrypt = security.decrypt_string
                    def _safe_decrypt(text: str) -> str:
                        res = orig_decrypt(text)
                        if res:
                            return res
                        if text and text.startswith("enc_b64:") and os.name == "nt":
                            try:
                                import base64, ctypes
                                from app.builtin.notifications.security import DATA_BLOB
                                raw_b64 = text[len("enc_b64:"):]
                                data = base64.b64decode(raw_b64.encode("utf-8"))
                                data_in = DATA_BLOB(len(data), ctypes.cast(ctypes.c_char_p(data), ctypes.POINTER(ctypes.c_byte)))
                                data_out = DATA_BLOB()
                                crypt32 = ctypes.windll.crypt32
                                if crypt32.CryptUnprotectData(ctypes.byref(data_in), None, None, None, None, 1, ctypes.byref(data_out)):
                                    out = ctypes.string_at(data_out.pbData, data_out.cbData).decode("utf-8", errors="replace")
                                    ctypes.windll.kernel32.LocalFree(data_out.pbData)
                                    return out
                            except Exception:
                                pass
                        return ""
                    security.decrypt_string = _safe_decrypt
            except Exception:
                pass
        except Exception:
            pass

    def _load_descriptions(self):
        desc_path = os.path.join(os.path.dirname(__file__), "descriptions.json")
        if os.path.isfile(desc_path):
            try:
                with open(desc_path, "r", encoding="utf-8") as f:
                    self.descriptions = json.load(f)
            except Exception:
                self.descriptions = {}

    def on_startup(self, ctx):
        self._protect_notifications(ctx)
        cfg = self.get_config()
        if bool(cfg.get("enabled", True)) and bool(cfg.get("auto_start", False)):
            self.log("Auto-starting Tor proxy (auto_start is enabled)...")
            import threading
            threading.Thread(target=self._ensure_tor_ready, daemon=True).start()

    def _ensure_tor_ready(self):
        if not self.tor_service.is_tor_installed():
            self.log("Tor is not installed. Auto-downloading Tor Expert Bundle...")
            try:
                exe = self.tor_service.download_tor_bundle()
                cfg = self.get_config()
                cfg["tor_path"] = exe
                self.save_config(cfg)
                self.tor_service.custom_tor_path = exe
            except Exception as e:
                self.log(f"Auto-download error: {e}")
                return
        self.tor_service.start()

    def on_shutdown(self, ctx):
        self.log("Stopping Tor proxy...")
        self.tor_service.stop()
        try:
            gui = ctx.get("gui") if isinstance(ctx, dict) else None
            if gui and hasattr(gui, "plugin_manager") and gui.plugin_manager:
                for p in gui.plugin_manager.plugins:
                    if p.__class__.__name__ == "NotificationsPlugin":
                        cached = p.api._config_cache.get("NotificationsPlugin", {})
                        data = cached.get("data")
                        if data:
                            import json, os
                            from app.paths import PLUGINS_CONFIG_DIR
                            from app.utils.system import _atomic_write_bytes
                            cfg_path = os.path.join(PLUGINS_CONFIG_DIR, "NotificationsPlugin.json")
                            content = json.dumps(data, indent=4, ensure_ascii=False).encode("utf-8")
                            _atomic_write_bytes(cfg_path, content)
        except Exception:
            pass

    def save_config(self, config_dict):
        super().save_config(config_dict)
        try:
            import json
            import os
            from app.paths import PLUGINS_CONFIG_DIR
            from app.utils.system import _atomic_write_bytes
            config_path = os.path.join(PLUGINS_CONFIG_DIR, f"{self.__class__.__name__}.json")
            content = json.dumps(config_dict, indent=4, ensure_ascii=False).encode("utf-8")
            _atomic_write_bytes(config_path, content)
        except Exception:
            pass

    def build_settings_ui(self, parent_frame):
        adapter = TorProxyUIAdapter(self, parent_frame)
        adapter.build_ui()
        self._ui_adapter = adapter

    def api_status(self, data, query):
        return 200, {
            "status": self.tor_service.status,
            "status_detail": self.tor_service.status_detail,
            "socks_port": self.tor_service.socks_port,
            "bootstrap_progress": self.tor_service.bootstrap_progress,
            "is_installed": self.tor_service.is_tor_installed(),
            "external_mode": self.tor_service.external_mode,
            "auto_route_telegram": self.tor_service.auto_route_telegram,
            "auto_route_discord": self.tor_service.auto_route_discord,
            "use_bridges": self.tor_service.use_bridges,
            "auto_search_bridges": self.tor_service.auto_search_bridges,
        }

    def api_start(self, data, query):
        success = self.tor_service.start()
        return 200 if success else 500, {
            "success": success,
            "status": self.tor_service.status,
            "detail": self.tor_service.status_detail
        }

    def api_stop(self, data, query):
        self.tor_service.stop()
        return 200, {"success": True, "status": self.tor_service.status}

    def api_test(self, data, query):
        res = self.tor_service.test_connection()
        return 200, res

    def api_fetch_bridges(self, data, query):
        try:
            fresh = self.tor_service.fetch_online_bridges(count=3)
            return 200, {"success": True, "bridges": fresh}
        except Exception as e:
            return 500, {"success": False, "error": str(e)}
