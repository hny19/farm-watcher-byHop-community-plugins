# Tor Proxy Plugin for Farm Watcher

Tor proxy management plugin designed to route Telegram notification traffic through an encrypted SOCKS5 proxy and bypass strict network restrictions or ISP censorship.

---

## Features

- **Autonomous Tor Management**:
  - One-click download and extraction of the official portable **Tor Expert Bundle** for Windows.
  - Full lifecycle control of the background `tor.exe` process directly inside Farm Watcher.
  - Local SOCKS5 proxy server (default port `9050`).
  - External Tor mode: connect to an existing Tor Browser instance (port `9150`) or a system service without spawning a separate binary.

- **Seamless Telegram Routing**:
  - Automatically updates the **Notifications** plugin configuration with the active Tor SOCKS5 proxy upon successful connection.
  - Ensures reliable delivery of Telegram notifications even when `api.telegram.org` is blocked by your ISP or firewall.

- **Anti-Censorship & Intelligent Bridge Discovery**:
  - Pluggable transports support: `obfs4`, `webtunnel`, `snowflake`.
  - **Automated Watchdog**: if the Tor bootstrap handshake hangs at 5–10% (blocked by ISP DPI), the plugin automatically queries online mirrors, collects fresh verified bridges, updates configuration, and reconnects without user intervention.
  - Dedicated **Find Bridges** button for on-demand bridge collection.

- **Diagnostics & Connection Testing**:
  - Live **Tor Exit IP** lookup confirming that public traffic is encrypted and routed through Tor.
  - Telegram API latency test measuring ping in milliseconds.
  - Real-time scrollable Tor event log console with color-coded bootstrap steps, warnings, and errors.

- **Responsive Interface & Multi-Language Support**:
  - Sleek dark theme matching Farm Watcher's native design system.
  - Adaptive 2x2 action button layout preventing text truncation on any screen resolution.
  - Contextual hover tooltips (Descriptions) dynamically displayed in Russian or English based on the app's language preference (**Settings -> Description Language**).

---

## Installation

1. Copy the `tor_proxy` folder into the `plugins/` directory of your Farm Watcher installation:
   ```text
   farm_watcher/
   └── plugins/
       └── tor_proxy/
           ├── __init__.py
           ├── plugin.py
           ├── tor_service.py
           ├── gui.py
           ├── descriptions.json
           ├── README_RU.md
           └── README_EN.md
   ```
2. Restart Farm Watcher.
3. Open the **Plugins** tab and select the **TorProxy** sub-tab.

---

## Quick Start Guide

1. Navigate to **Plugins -> TorProxy**.
2. If Tor is not installed yet, click **Download Tor** to automatically download and unpack the Tor Expert Bundle.
3. Click **Start Tor** to launch the proxy.
4. Once the status shows `Running (port 9050)`, click **Test Connection** to verify routing and Telegram API connectivity.
5. If connection is blocked by your ISP (hangs at 5–10%):
   - Check **Use bridges (obfs4 / webtunnel / snowflake)**.
   - Click **Find Bridges** to fetch working bridges online, or paste your bridge lines obtained from `@GetBridgesBot`.
   - Enable **Auto-fetch and rotate bridges on failure** for automatic recovery.

---

## REST API Endpoints

The plugin exposes custom endpoints on Farm Watcher's built-in REST API (port `8081`):

| Method | Endpoint | Description |
| :--- | :--- | :--- |
| `GET` | `/api/tor/status` | Get current status, bootstrap progress percentage, and active port |
| `POST` | `/api/tor/start` | Start local Tor background process |
| `POST` | `/api/tor/stop` | Stop Tor process |
| `POST` | `/api/tor/test` | Test SOCKS5 connectivity, exit IP, and Telegram API ping |
| `POST` | `/api/tor/fetch-bridges` | Query online mirrors and fetch fresh verified bridges |

### cURL Examples:

- **Check status**:
  ```cmd
  curl http://localhost:8081/api/tor/status
  ```
- **Start Tor**:
  ```cmd
  curl -X POST http://localhost:8081/api/tor/start
  ```
- **Test connection**:
  ```cmd
  curl -X POST http://localhost:8081/api/tor/test
  ```

---

## Dependencies

The plugin declares its dependencies in `dependencies`:
- `PySocks` — SOCKS proxy support for Python sockets.
- `requests[socks]` — HTTP/HTTPS client support over SOCKS5.

Farm Watcher automatically verifies and installs missing dependencies on first launch.
