import os
import threading
import tkinter as tk
from tkinter import messagebox

from app.gui.tabs.settings_controls import SettingsControlsMixin, FlatActionButton, FlatCheckbox
from app.gui.config.theme import (
    SETTINGS_CARD_BG, SECTION_TITLE_FG, FONT_MAIN, FONT_BOLD, TAB_FG, 
    TAB_HOVER_BG, TAB_BG, DISABLED_FIELD_BG, LIST_BG, BORDER, 
    BTN_MARK_BG, BTN_DANGER_BG, BTN_AUTOFARM_BG, BTN_AUTOFARM_HOVER_BG
)
from app.gui.config import settings_layout
from app.gui.widgets.widgets_utils import bind_smart_shortcuts, create_context_menu
from .tor_service import TorStatus

class TorProxyUIAdapter(SettingsControlsMixin):
    def __init__(self, plugin, parent_frame):
        self.plugin = plugin
        self.service = plugin.tor_service
        self.parent_frame = parent_frame
        self.vars = {}
        self.entries = {}
        self.controls = {}
        self._path_containers = {}
        self._loading = True

        cfg = self.plugin.get_config()
        self.vars["auto_start"] = tk.BooleanVar(value=bool(cfg.get("auto_start", False)))
        self.vars["auto_route_telegram"] = tk.BooleanVar(value=bool(cfg.get("auto_route_telegram", False)))
        self.vars["external_mode"] = tk.BooleanVar(value=bool(cfg.get("external_mode", False)))
        self.vars["use_bridges"] = tk.BooleanVar(value=bool(cfg.get("use_bridges", False)))
        self.vars["auto_search_bridges"] = tk.BooleanVar(value=bool(cfg.get("auto_search_bridges", False)))
        self.vars["socks_port"] = tk.StringVar(value=str(cfg.get("socks_port", 9050)))
        path_val = str(cfg.get("tor_path", "")).strip()
        if not path_val or not os.path.isfile(path_val):
            detected = self.service.find_tor_executable()
            if detected:
                path_val = detected
        self.vars["tor_path"] = tk.StringVar(value=path_val)
        self._bridges_text_val = str(cfg.get("bridges_text", ""))
        self._is_downloading = False

        for var in self.vars.values():
            var.trace_add("write", self._schedule_save)

        self.service.set_bridges_updated_callback(self._on_service_bridges_updated)

        self._loading = False
        self.log_text = None
        self.txt_bridges = None

    def __getattr__(self, name):
        return getattr(self.parent_frame, name)

    def _on_service_bridges_updated(self, new_text):
        def _apply():
            if self.txt_bridges and self.txt_bridges.winfo_exists():
                self.txt_bridges.delete("1.0", "end")
                self.txt_bridges.insert("1.0", new_text)
            self._bridges_text_val = new_text
            self._schedule_save()
        self.parent_frame.after(0, _apply)

    def _schedule_save(self, *_):
        if self._loading:
            return
        try:
            port = int(self.vars["socks_port"].get().strip())
        except ValueError:
            port = 9050

        bridges = ""
        if hasattr(self, "txt_bridges") and self.txt_bridges and self.txt_bridges.winfo_exists():
            bridges = self.txt_bridges.get("1.0", "end-1c").strip()
        else:
            bridges = self._bridges_text_val

        config = {
            "enabled": True,
            "auto_start": bool(self.vars["auto_start"].get()),
            "auto_route_telegram": bool(self.vars["auto_route_telegram"].get()),
            "external_mode": bool(self.vars["external_mode"].get()),
            "use_bridges": bool(self.vars["use_bridges"].get()),
            "auto_search_bridges": bool(self.vars["auto_search_bridges"].get()),
            "socks_port": port,
            "tor_path": str(self.vars["tor_path"].get()).strip(),
            "bridges_text": bridges,
        }
        self.plugin.save_config(config)

        # Sync service settings
        self.service.socks_port = port
        self.service.custom_tor_path = config["tor_path"]
        self.service.external_mode = config["external_mode"]
        self.service.auto_route_telegram = config["auto_route_telegram"]
        self.service.use_bridges = config["use_bridges"]
        self.service.auto_search_bridges = config["auto_search_bridges"]
        self.service.bridges_text = config["bridges_text"]

    def _add_checkbox(self, parent, key, label_text, row=None, default=False):
        if key in self.vars:
            var = self.vars[key]
        else:
            var = tk.BooleanVar(value=default)
            self.vars[key] = var
            var.trace_add("write", self._schedule_save)

        chk = FlatCheckbox(parent, label_text, var, self._schedule_save)
        self.controls[key] = chk
        if row is None:
            chk.pack(anchor="w", pady=settings_layout.CHK_PAD_Y)
        else:
            chk.grid(row=row, column=0, sticky="w", pady=settings_layout.STARTUP_ROW_CHECKBOX_PAD_Y)
        self._bind_description(chk, key, label_text)
        return chk

    def _get_description_language(self):
        target = self.parent_frame
        while target:
            if hasattr(target, "gui_app") and target.gui_app:
                if hasattr(target.gui_app, "get_description_language"):
                    return str(target.gui_app.get_description_language()).strip().lower()
                app = target.gui_app
                if hasattr(app, "settings_tab") and app.settings_tab:
                    vars_dict = getattr(app.settings_tab, "vars", {})
                    if "description_language" in vars_dict:
                        return str(vars_dict["description_language"].get()).strip().lower()
            if hasattr(target, "_description_language"):
                try:
                    return str(target._description_language()).strip().lower()
                except Exception:
                    pass
            target = getattr(target, "master", None)
        return "en"

    def _display_description(self, heading, text):
        if not heading or not text:
            return
        target = self.parent_frame
        while target:
            if hasattr(target, "set_description") and callable(target.set_description):
                target.set_description(heading, text)
                return
            if hasattr(target, "gui_app") and target.gui_app:
                app = target.gui_app
                if hasattr(app, "plugins_tab") and app.plugins_tab and hasattr(app.plugins_tab, "set_description"):
                    app.plugins_tab.set_description(heading, text)
                    return
                if hasattr(app, "settings_tab") and app.settings_tab and hasattr(app.settings_tab, "set_description"):
                    app.settings_tab.set_description(heading, text)
                    return
            target = getattr(target, "master", None)

    def _bind_description(self, widget, key, title=None, section=None):
        if not widget:
            return

        def _push(_event=None):
            lang = self._get_description_language()
            if lang not in ("ru", "en"):
                lang = "en"
            desc = self.plugin.descriptions.get(key, {}) or self.plugin.descriptions.get(key.lower(), {})
            lang_data = desc.get(lang) or desc.get("en") or {}
            heading = lang_data.get("title", title or key)
            text = lang_data.get("text", "")
            if heading and text:
                self._display_description(heading, text)

        candidates = [widget]
        for attr in ("label", "box"):
            child = getattr(widget, attr, None)
            if child and isinstance(child, tk.Widget):
                candidates.append(child)

        for target_w in candidates:
            target_w.bind("<Enter>", _push, add="+")
            target_w.bind("<FocusIn>", _push, add="+")

    def build_ui(self):
        def _create_section_card(parent, pady=(0, 10)):
            card = tk.Frame(parent, bg=SETTINGS_CARD_BG, bd=0, highlightthickness=0)
            card.pack(fill="x", pady=pady)
            content = tk.Frame(card, bg=SETTINGS_CARD_BG)
            content.pack(fill="both", expand=True, padx=settings_layout.SECTION_CARD_PAD_X, pady=settings_layout.SECTION_CARD_PAD_Y)
            return card, content

        def _create_section_title(parent, text):
            return tk.Label(parent, text=text, bg=SETTINGS_CARD_BG, fg=SECTION_TITLE_FG, font=(FONT_MAIN[0], 10, "bold"))

        # --- CARD 1: STATUS & CONTROLS ---
        _, ctrl_content = _create_section_card(self.parent_frame, pady=0)
        ctrl_header = tk.Frame(ctrl_content, bg=SETTINGS_CARD_BG)
        ctrl_header.pack(fill="x", pady=(0, 6))
        _create_section_title(ctrl_header, "Tor Proxy Status & Controls").pack(side="left", anchor="w")

        # Status badge row
        status_row = tk.Frame(ctrl_content, bg=SETTINGS_CARD_BG)
        status_row.pack(fill="x", pady=(0, 8))

        self.lbl_status_badge = tk.Label(
            status_row,
            text="Stopped",
            bg="#2a2a2a",
            fg="#888888",
            font=FONT_BOLD,
            padx=12,
            pady=4,
            relief="flat"
        )
        self.lbl_status_badge.pack(side="left")

        self.lbl_status_detail = tk.Label(
            status_row,
            text="Tor is not running",
            bg=SETTINGS_CARD_BG,
            fg=TAB_FG,
            font=FONT_MAIN,
            padx=10
        )
        self.lbl_status_detail.pack(side="left")

        # Control buttons grid (2x2 layout for clean responsive fit)
        btn_grid = tk.Frame(ctrl_content, bg=SETTINGS_CARD_BG)
        btn_grid.pack(fill="x", pady=(4, 4))
        btn_grid.columnconfigure(0, weight=1)
        btn_grid.columnconfigure(1, weight=1)

        self.btn_start = FlatActionButton(
            btn_grid, text="Start Tor", bg=BTN_MARK_BG, fg="#ffffff",
            hover_bg="#0f7a24", active_bg=TAB_BG, active_fg="#ffffff",
            pady=5, command=self._on_start_clicked
        )
        self.btn_start.grid(row=0, column=0, sticky="ew", padx=(0, 3), pady=(0, 4))
        self._bind_description(self.btn_start, "btn_start_tor")

        self.btn_stop = FlatActionButton(
            btn_grid, text="Stop", bg=BTN_DANGER_BG, fg="#ffffff",
            hover_bg="#a82828", active_bg=TAB_BG, active_fg="#ffffff",
            disabled_bg=DISABLED_FIELD_BG, pady=5, command=self._on_stop_clicked
        )
        self.btn_stop.grid(row=0, column=1, sticky="ew", padx=(3, 0), pady=(0, 4))
        self._bind_description(self.btn_stop, "btn_stop_tor")

        self.btn_test = FlatActionButton(
            btn_grid, text="Test Connection", bg=BTN_AUTOFARM_BG, fg="#ffffff",
            hover_bg=BTN_AUTOFARM_HOVER_BG, active_bg=TAB_BG, active_fg="#ffffff",
            pady=5, command=self._on_test_clicked
        )
        self.btn_test.grid(row=1, column=0, sticky="ew", padx=(0, 3), pady=(0, 0))
        self._bind_description(self.btn_test, "btn_test_tor")

        dl_text = "Download Tor" if not self.service.is_tor_installed() else "Reinstall Tor"
        self.btn_download = FlatActionButton(
            btn_grid, text=dl_text, bg=LIST_BG, fg=TAB_FG,
            hover_bg=TAB_HOVER_BG, active_bg=TAB_BG, active_fg=TAB_FG,
            pady=5, command=self._on_download_clicked
        )
        self.btn_download.grid(row=1, column=1, sticky="ew", padx=(3, 0), pady=(0, 0))
        self._bind_description(self.btn_download, "btn_download_tor")

        # --- CARD 2: CONNECTION DETAILS ---
        _, info_content = _create_section_card(self.parent_frame, pady=(settings_layout.SECTION_CARD_GAP_Y, 0))
        info_header = tk.Frame(info_content, bg=SETTINGS_CARD_BG)
        info_header.pack(fill="x", pady=(0, 6))
        _create_section_title(info_header, "Connection Details").pack(side="left", anchor="w")

        info_grid = tk.Frame(info_content, bg=SETTINGS_CARD_BG)
        info_grid.pack(fill="x", padx=settings_layout.PAD_X)

        lbl_exit_title = tk.Label(info_grid, text="Tor Exit IP:", bg=SETTINGS_CARD_BG, fg=TAB_FG, font=FONT_MAIN, width=18, anchor="w")
        lbl_exit_title.grid(row=0, column=0, sticky="w", pady=2)
        self._bind_description(lbl_exit_title, "exit_ip")

        self.lbl_exit_ip = tk.Label(info_grid, text="— (click 'Test Connection')", bg=SETTINGS_CARD_BG, fg="#89b4fa", font=FONT_BOLD, anchor="w")
        self.lbl_exit_ip.grid(row=0, column=1, sticky="w", pady=2)
        self._bind_description(self.lbl_exit_ip, "exit_ip")

        lbl_tg_title = tk.Label(info_grid, text="Telegram API:", bg=SETTINGS_CARD_BG, fg=TAB_FG, font=FONT_MAIN, width=18, anchor="w")
        lbl_tg_title.grid(row=1, column=0, sticky="w", pady=2)
        self._bind_description(lbl_tg_title, "telegram_status")

        self.lbl_telegram_status = tk.Label(info_grid, text="—", bg=SETTINGS_CARD_BG, fg=TAB_FG, font=FONT_MAIN, anchor="w")
        self.lbl_telegram_status.grid(row=1, column=1, sticky="w", pady=2)
        self._bind_description(self.lbl_telegram_status, "telegram_status")

        # --- CARD 3: CONFIGURATION ---
        _, cfg_content = _create_section_card(self.parent_frame, pady=(settings_layout.SECTION_CARD_GAP_Y, 0))
        cfg_header = tk.Frame(cfg_content, bg=SETTINGS_CARD_BG)
        cfg_header.pack(fill="x", pady=(0, 4))
        _create_section_title(cfg_header, "Configuration").pack(side="left", anchor="w")

        cfg_grid = self._create_tab_grid(cfg_content)
        self._add_checkbox(cfg_grid, "auto_route_telegram", "Route Telegram traffic through Tor proxy", row=0)
        self._add_checkbox(cfg_grid, "auto_start", "Auto-start Tor on Farm Watcher launch", row=1)
        self._add_checkbox(cfg_grid, "external_mode", "External Tor (use existing SOCKS on 9050/9150)", row=2)

        cfg_fields = tk.Frame(cfg_content, bg=SETTINGS_CARD_BG)
        cfg_fields.pack(fill="x", padx=settings_layout.PAD_X, pady=(6, 0))

        # SOCKS Port row
        p_row = tk.Frame(cfg_fields, bg=SETTINGS_CARD_BG)
        p_row.pack(anchor="w", fill="x", pady=settings_layout.ROW_PAD_Y)
        p_lbl = self._create_label_with_tooltip(p_row, "SOCKS5 Port", "socks_port", 14)
        p_lbl.grid(row=0, column=0, sticky="w")
        self._bind_description(p_lbl, "socks_port")

        p_cont, p_entry = self._create_entry(p_row, self.vars["socks_port"], width=12, justify="center")
        p_cont.grid(row=0, column=1, sticky="w", padx=(6, 0), ipady=settings_layout.ENTRY_WRAPPER_IPAD_Y)
        self._bind_description(p_cont, "socks_port")
        self._bind_description(p_entry, "socks_port")

        # tor.exe path row
        exe_row = tk.Frame(cfg_fields, bg=SETTINGS_CARD_BG)
        exe_row.pack(anchor="w", fill="x", pady=settings_layout.ROW_PAD_Y)
        exe_row.columnconfigure(1, weight=1)
        exe_lbl = self._create_label_with_tooltip(exe_row, "Path to tor.exe", "tor_path", 14)
        exe_lbl.grid(row=0, column=0, sticky="w")
        self._bind_description(exe_lbl, "tor_path")

        exe_cont, exe_entry = self._create_entry(exe_row, self.vars["tor_path"])
        exe_cont.grid(row=0, column=1, sticky="ew", padx=(6, 0), ipady=settings_layout.ENTRY_WRAPPER_IPAD_Y)
        self._bind_description(exe_cont, "tor_path")
        self._bind_description(exe_entry, "tor_path")

        exe_btn = FlatActionButton(
            exe_row, text=settings_layout.BTN_FILE_TEXT, bg=LIST_BG, fg=TAB_FG,
            hover_bg=TAB_HOVER_BG, active_bg=TAB_BG, active_fg=TAB_FG,
            disabled_bg=DISABLED_FIELD_BG, width=settings_layout.BTN_FILE_WIDTH,
            takefocus=False, command=lambda: self._browse_file("tor_path", [("Executable", "*.exe"), ("All files", "*.*")])
        )
        exe_btn.grid(row=0, column=2, sticky="nsew", padx=(settings_layout.BTN_FILE_PAD_X, 0))
        self._bind_description(exe_btn, "tor_path")

        # --- CARD 4: TOR BRIDGES ---
        _, bridge_content = _create_section_card(self.parent_frame, pady=(settings_layout.SECTION_CARD_GAP_Y, 0))
        bridge_header = tk.Frame(bridge_content, bg=SETTINGS_CARD_BG)
        bridge_header.pack(fill="x", pady=(0, 4))
        _create_section_title(bridge_header, "Tor Bridges").pack(side="left", anchor="w")

        btn_find = FlatActionButton(
            bridge_header, text="Find Bridges", bg=LIST_BG, fg=TAB_FG,
            hover_bg=TAB_HOVER_BG, active_bg=TAB_BG, active_fg=TAB_FG,
            padx=10, pady=2, command=self._on_find_bridges_clicked
        )
        btn_find.pack(side="right")
        self._bind_description(btn_find, "btn_find_bridges")

        bridge_grid = self._create_tab_grid(bridge_content)
        self._add_checkbox(bridge_grid, "use_bridges", "Use bridges (obfs4 / webtunnel / snowflake)", row=0)
        self._add_checkbox(bridge_grid, "auto_search_bridges", "Auto-fetch and rotate bridges on failure", row=1)

        hint_lbl = tk.Label(
            bridge_content,
            text="If Tor hangs at 5-10% (ISP blocks), enable bridges below.\nGet bridges via @GetBridgesBot or bridges.torproject.org:",
            bg=SETTINGS_CARD_BG,
            fg="#888888",
            font=("Consolas", 8),
            justify="left",
            anchor="w"
        )
        hint_lbl.pack(fill="x", padx=settings_layout.PAD_X, pady=(4, 4))
        self._bind_description(hint_lbl, "bridges_text")

        bridge_box_container = tk.Frame(bridge_content, bg=LIST_BG, bd=0, highlightthickness=1, highlightbackground=BORDER)
        bridge_box_container.pack(fill="x", padx=settings_layout.PAD_X, pady=(0, 4))

        self.txt_bridges = tk.Text(
            bridge_box_container,
            bg=LIST_BG,
            fg=TAB_FG,
            font=("Consolas", 9),
            width=1,
            height=3,
            wrap="none",
            bd=0,
            relief="flat",
            padx=8,
            pady=6
        )
        self.txt_bridges.pack(fill="both", expand=True)
        if self._bridges_text_val:
            self.txt_bridges.insert("1.0", self._bridges_text_val)

        bind_smart_shortcuts(self.txt_bridges, readonly=False)
        create_context_menu(self.txt_bridges, readonly=False)
        self._bind_description(self.txt_bridges, "bridges_text")
        self._bind_description(bridge_box_container, "bridges_text")
        self.txt_bridges.bind("<KeyRelease>", lambda _: self._schedule_save())
        self.txt_bridges.bind("<FocusOut>", lambda _: self._schedule_save())

        # --- CARD 5: TOR EVENT LOG ---
        _, log_content = _create_section_card(self.parent_frame, pady=(settings_layout.SECTION_CARD_GAP_Y, 0))
        log_header = tk.Frame(log_content, bg=SETTINGS_CARD_BG)
        log_header.pack(fill="x", pady=(0, 4))
        _create_section_title(log_header, "Tor Event Log").pack(side="left", anchor="w")

        btn_clear = FlatActionButton(
            log_header, text="Clear Log", bg=LIST_BG, fg=TAB_FG,
            hover_bg=TAB_HOVER_BG, active_bg=TAB_BG, active_fg=TAB_FG,
            padx=10, pady=2, command=self._on_clear_log_clicked
        )
        btn_clear.pack(side="right")
        self._bind_description(btn_clear, "btn_clear_log")

        log_container = tk.Frame(log_content, bg="#121212", bd=0, highlightthickness=1, highlightbackground=BORDER)
        log_container.pack(fill="both", expand=True, padx=settings_layout.PAD_X, pady=(4, 0))
        self._bind_description(log_container, "log_console")

        self.log_text = tk.Text(
            log_container,
            bg="#121212",
            fg="#cdd6f4",
            font=("Consolas", 9),
            width=1,
            height=7,
            wrap="word",
            bd=0,
            relief="flat",
            padx=8,
            pady=8,
            state="disabled"
        )
        self.log_text.pack(fill="both", expand=True)
        self._bind_description(self.log_text, "log_console")

        bind_smart_shortcuts(self.log_text, readonly=True)
        create_context_menu(self.log_text, readonly=True)

        self.log_text.tag_configure("notice", foreground="#89b4fa")
        self.log_text.tag_configure("warn", foreground="#f9e2af")
        self.log_text.tag_configure("err", foreground="#f38ba8")
        self.log_text.tag_configure("ok", foreground="#a6e3a1")

        self.service.add_listener(self._on_service_status_changed)
        self.service.add_log_listener(self._on_service_log_line)

        for line in self.service.log_lines:
            self._append_log_line_ui(line)

        self._refresh_ui_state()

    def _append_log_line_ui(self, line):
        if not self.log_text or not self.log_text.winfo_exists():
            return
        tag = None
        lower = line.lower()
        if "bootstrapped 100%" in lower or "successfully" in lower or "connected!" in lower:
            tag = "ok"
        elif "[warn]" in lower or "warning" in lower:
            tag = "warn"
        elif "[err]" in lower or "error" in lower or "failed" in lower:
            tag = "err"
        elif "[notice]" in lower:
            tag = "notice"

        self.log_text.configure(state="normal")
        if tag:
            self.log_text.insert("end", line + "\n", tag)
        else:
            self.log_text.insert("end", line + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _on_service_log_line(self, line):
        self.parent_frame.after(0, lambda: self._append_log_line_ui(line))

    def _on_service_status_changed(self, status, detail, progress):
        self.parent_frame.after(0, self._refresh_ui_state)

    def _refresh_ui_state(self):
        st = self.service.status
        detail = self.service.status_detail

        if st == TorStatus.RUNNING:
            self.lbl_status_badge.configure(text=f"Running (port {self.service.socks_port})", bg="#1b4d24", fg="#a6e3a1")
            self.lbl_status_detail.configure(text=detail, fg="#a6e3a1")
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        elif st == TorStatus.STARTING:
            self.lbl_status_badge.configure(text=f"Connecting ({self.service.bootstrap_progress}%)", bg="#4a3b1a", fg="#f9e2af")
            self.lbl_status_detail.configure(text=detail, fg="#f9e2af")
            self.btn_start.configure(state="disabled")
            self.btn_stop.configure(state="normal")
        elif st == TorStatus.ERROR:
            self.lbl_status_badge.configure(text="Error", bg="#4d1b1b", fg="#f38ba8")
            self.lbl_status_detail.configure(text=detail, fg="#f38ba8")
            self.btn_start.configure(state="normal")
            self.btn_stop.configure(state="disabled")
        else: # STOPPED
            self.lbl_status_badge.configure(text="Stopped", bg="#2a2a2a", fg="#888888")
            self.lbl_status_detail.configure(text=detail, fg=TAB_FG)
            self.btn_start.configure(state="normal")
            self.btn_stop.configure(state="disabled")

    def _on_start_clicked(self):
        self._schedule_save()
        threading.Thread(target=self.service.start, daemon=True).start()

    def _on_stop_clicked(self):
        threading.Thread(target=self.service.stop, daemon=True).start()

    def _on_test_clicked(self):
        self.lbl_exit_ip.configure(text="Checking connection...", fg="#f9e2af")
        self.lbl_telegram_status.configure(text="Ping...", fg="#f9e2af")

        def _bg_test():
            res = self.service.test_connection()
            def _apply():
                if res.get("ok"):
                    ip_str = res.get("ip") or "Unknown"
                    if res.get("is_tor"):
                        self.lbl_exit_ip.configure(text=f"{ip_str} (Tor Network OK)", fg="#a6e3a1")
                    else:
                        self.lbl_exit_ip.configure(text=f"{ip_str} (Warning: not Tor)", fg="#f9e2af")

                    if res.get("telegram_ok"):
                        ms = res.get("telegram_ms", 0)
                        self.lbl_telegram_status.configure(text=f"Available (latency: {ms} ms)", fg="#a6e3a1")
                    else:
                        self.lbl_telegram_status.configure(text="Unreachable (connection error)", fg="#f38ba8")
                else:
                    self.lbl_exit_ip.configure(text=f"Failed: {res.get('error')}", fg="#f38ba8")
                    self.lbl_telegram_status.configure(text="Unreachable", fg="#f38ba8")
            self.parent_frame.after(0, _apply)

        threading.Thread(target=_bg_test, daemon=True).start()

    def _on_download_clicked(self):
        if getattr(self, "_is_downloading", False):
            return
        self._is_downloading = True
        self.btn_download.configure(state="disabled", text="Downloading...")
        self.lbl_status_detail.configure(text="Connecting to Tor download server...", fg="#f9e2af")

        def _progress(pct, downloaded, total):
            mb_dl = round(downloaded / (1024 * 1024), 1)
            mb_tot = round(total / (1024 * 1024), 1) if total > 0 else 0
            if total > 0:
                msg = f"Downloading Tor: {pct}% ({mb_dl}/{mb_tot} MB)"
            else:
                msg = f"Downloading Tor: {mb_dl} MB"
            self.parent_frame.after(0, lambda: self.lbl_status_detail.configure(text=msg))

        def _bg_download():
            try:
                exe = self.service.download_tor_bundle(progress_callback=_progress)
                def _done():
                    self._is_downloading = False
                    self.vars["tor_path"].set(exe)
                    self._schedule_save()
                    self.lbl_status_detail.configure(text="Tor downloaded successfully!", fg="#a6e3a1")
                    self.btn_download.configure(state="normal", text="Reinstall Tor")
                    messagebox.showinfo("Tor Proxy", "Tor Expert Bundle downloaded successfully and is ready to use!")
                self.parent_frame.after(0, _done)
            except Exception as e:
                def _err():
                    self._is_downloading = False
                    btn_label = "Download Tor" if not self.service.is_tor_installed() else "Reinstall Tor"
                    self.btn_download.configure(state="normal", text=btn_label)
                    self.lbl_status_detail.configure(text=f"Download error: {e}", fg="#f38ba8")
                    messagebox.showerror("Tor Proxy", f"Failed to download Tor: {e}")
                self.parent_frame.after(0, _err)

        threading.Thread(target=_bg_download, daemon=True).start()

    def _on_clear_log_clicked(self):
        self.service.clear_logs()
        if self.log_text and self.log_text.winfo_exists():
            self.log_text.configure(state="normal")
            self.log_text.delete("1.0", "end")
            self.log_text.configure(state="disabled")

    def _on_find_bridges_clicked(self):
        self.lbl_status_detail.configure(text="Searching for fresh bridges online...", fg="#f9e2af")

        def _bg():
            try:
                fresh = self.service.fetch_online_bridges(count=3)
                new_text = "\n".join(fresh)
                self.service.bridges_text = new_text
                self.service.use_bridges = True
                self.vars["use_bridges"].set(True)

                def _apply():
                    if self.txt_bridges and self.txt_bridges.winfo_exists():
                        self.txt_bridges.delete("1.0", "end")
                        self.txt_bridges.insert("1.0", new_text)
                    self._schedule_save()
                    self.lbl_status_detail.configure(text=f"Found {len(fresh)} bridges!", fg="#a6e3a1")
                    messagebox.showinfo("Tor Proxy", f"Successfully loaded {len(fresh)} verified bridges from online mirrors!")

                self.parent_frame.after(0, _apply)
            except Exception as e:
                def _err():
                    self.lbl_status_detail.configure(text=f"Search error: {e}", fg="#f38ba8")
                    messagebox.showerror("Tor Proxy", f"Bridge search failed: {e}")

                self.parent_frame.after(0, _err)

        threading.Thread(target=_bg_download if False else _bg, daemon=True).start()
