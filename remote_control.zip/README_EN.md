# Farm Watcher - Remote Control Plugin

Full two-way remote monitoring and management plugin for Farm Watcher via Telegram and Discord bots.

## Features

- **Direct UI Panel Mirroring:** Interactive bot controls directly duplicate the main Farm Watcher panel buttons: `Autofarm`, `STOP`, `KILL`, `KILL ALL`, and `Refresh Accounts`.
- **Dual Bot Support:** Telegram and Discord bots run in parallel background threads without conflicts.
- **Multi-PC Support:** Manage multiple computers in one shared Discord channel using PC tags or separate channels.
- **Steam Guard 2FA Integration:** Generate two-factor authentication codes directly from linked maFiles on demand.
- **Visual Screen Inspection:** Capture and receive desktop or CS2 window screenshots on demand.
- **Security Access Control:** Strict admin whitelist verification by user IDs.
- **Automatic Proxy Routing:** Automatically uses active Farm Watcher Tor proxy when available, or custom proxy from settings.

---

## Telegram Setup

1. Open Farm Watcher and navigate to the **Plugins** tab.
2. Select **Remote Control**.
3. Check **Telegram remote control**.
4. Enter your Telegram Bot Token from BotFather.
5. Enter your Telegram User ID in the **Admin IDs** field.
6. Click **Test Bot** to verify connectivity, then settings save automatically.

In chat, the bot provides a persistent reply keyboard with direct action buttons:
- `Autofarm`
- `STOP`
- `KILL`
- `KILL ALL`
- `Refresh Accounts`
- `Screenshot`
- `Status`
- `Accounts`

---

## Discord Setup

1. Open Discord Developer Portal, create an application, add a Bot, and copy the Bot Token.
2. Under the **Bot** tab, scroll to **Privileged Gateway Intents** and enable **Message Content Intent**, then save changes. This is required for the bot to read commands without mentions.
3. Invite the bot to your Discord server with permissions to View Channel and Send Messages.
4. Right-click the dedicated channel in Discord and copy the Channel ID.
5. In Farm Watcher **Plugins - Remote Control**, check **Discord remote control**.
6. Enter the Discord Bot Token, Channel ID, and set your unique **PC Tag**, for example `PC1` or `PC2`.
7. Enter your Discord User ID in the **Admin IDs** field.
8. Click **Test Bot** to verify connectivity, then settings save automatically.

If Message Content Intent is not enabled in Discord Developer Portal, commands require mentioning the bot directly, for example `@Farm Watcher !status`.

---

## Multi-PC Setup with Shared Discord Channel

When controlling multiple computers from a single Discord channel:
- Give each machine a unique **PC Tag** in plugin settings, for example `PC1` on the first computer and `PC2` on the second computer.
- Both computers connect to the same Discord channel using either the same bot token or separate bot tokens.

### Targeting Commands
- **Target specific computer:**
  - `!status pc1` or `!pc1 status` - Status only from PC1
  - `!stop pc2` or `!pc2 stop` - Stop farm only on PC2
  - `!autofarm pc1` - Start autofarm only on PC1
  - `!launch pc1 account_name` - Launch account only on PC1
  - `!2fa pc2 account_name` - Generate 2FA code only on PC2
- **Target all computers at once:**
  - `!status all` or `!all status` or plain `!status` - All connected computers reply with their status
  - `!stop all` or `!all stop` - Stop farm on all computers

All bot responses include the computer tag in the header, for example `[PC1] Farm Watcher Status`.

---

## Network and Proxy Setup

The plugin automatically detects and routes traffic through the built-in Farm Watcher Tor proxy when active.

If you prefer using your own proxy:
1. In **Plugins - Remote Control**, scroll to **Network and Proxy Setup**.
2. Check **Custom proxy server**.
3. Enter your proxy URL, for example `socks5h://127.0.0.1:9050` or `http://127.0.0.1:8080`.

---

## Available Commands

Commands can be executed using `/` in Telegram and `!` or `/` in Discord.

### Farm Watcher Controls
- `/autofarm [mode]` or `!autofarm [tag or all]` - Start autofarm in normal or checkbox mode.
- `/stop` or `!stop [tag or all]` - Stop autofarm.
- `/kill` or `!kill [tag or all]` - Terminate CS2 and Steam processes.
- `/killall` or `!killall [tag or all]` - Terminate all farm related processes.
- `/refresh` or `!refresh [tag or all]` - Reload accounts and maFiles from disk.

### Monitoring
- `/status` or `!status [tag or all]` - Detailed farm status, active account, and progress.
- `/screen` or `!screen [tag or all]` - Capture desktop screenshot.
- `/game` or `!game [tag or all]` - Capture CS2 window screenshot.
- `/accounts` or `!accounts [tag or all]` - List all accounts with status markers.
- `/vac` or `!vac [tag or all]` - List accounts flagged with VAC Live.
- `/banned` or `!banned [tag or all]` - List banned accounts.
- `/ping` or `!ping [tag or all]` - Check bot response latency.

### Account Management
- `/launch <login>` or `!launch <login> [tag]` - Launch specific account.
- `/stop_acc` or `!stop_acc [tag]` - Stop currently running account.
- `/2fa <login>` or `!2fa <login> [tag]` - Generate Steam Guard 2FA code from maFile.
- `/skip` or `!skip [tag]` - Skip current account and proceed to next.
- `/restart` or `!restart [tag]` - Restart current account.
- `/pause` or `!pause [tag]` - Pause autofarm.
- `/resume` or `!resume [tag]` - Resume autofarm.
- `/mark_done <login>` or `!mark_done <login> [tag]` - Mark account as completed.
- `/clear_done <login>` or `!clear_done <login> [tag]` - Return account to queue.
- `/clear_all_done` or `!clear_all_done [tag]` - Reset completion status for all accounts.

### Terminal and System Control
- `/cmd <command line>` or `!cmd <command line> [tag]` - Execute system terminal command on host computer.
- `/reboot_pc [minutes]` or `!reboot_pc [minutes] [tag]` - Reboot host computer with optional delay in minutes.
- `/shutdown_pc [minutes]` or `!shutdown_pc [minutes] [tag]` - Shutdown host computer with optional delay in minutes.
- `/cancel_shutdown` or `!cancel_shutdown [tag]` - Cancel scheduled reboot or shutdown.
- `/menu` or `!menu` - Open interactive keyboard in Telegram.
- `/close_menu` or `!close_menu` - Close and hide interactive keyboard in Telegram.
- `/check_bans` or `!check_bans [tag]` - Run bans check on all accounts.
- `/stop_bans` or `!stop_bans [tag]` - Stop ongoing bans check.
