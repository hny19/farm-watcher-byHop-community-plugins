from .plugin import RemoteControlPlugin

__all__ = ["RemoteControlPlugin"]

