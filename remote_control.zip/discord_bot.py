import time
import threading
import json
import datetime
import requests
from curl_cffi import requests as cffi_requests

COLOR_BLUE = 0x3498DB
COLOR_GREEN = 0x2ECC71
COLOR_RED = 0xE74C3C
COLOR_ORANGE = 0xF39C12
COLOR_PURPLE = 0x9B59B6

class DiscordRemoteBot:
    def __init__(self, plugin, logger=None):
        self.plugin = plugin
        self.logger = logger or print
        self._session = requests.Session()
        self._thread = None
        self._stop_event = threading.Event()
        self.bot_user_id = None
        self.pc_tag = "PC1"
        self._current_ws = None
        self._ws_lock = threading.Lock()

    def _log(self, text):
        try:
            self.logger(f"[DiscordRemote] {text}")
        except Exception:
            pass

    def start(self, token, channel_id, admin_ids, proxy_url=None, pc_tag="PC1"):
        self.stop()
        if not token or not token.strip() or not channel_id or not str(channel_id).strip():
            return
        self.pc_tag = str(pc_tag).strip() or "PC1"
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._gateway_loop,
            args=(token.strip(), str(channel_id).strip(), admin_ids, proxy_url, self.pc_tag),
            daemon=True,
            name="FW_Discord_Gateway"
        )
        self._thread.start()
        self._log(f"Discord Remote Control started for {self.pc_tag}")

    def stop(self):
        self._stop_event.set()
        with self._ws_lock:
            if self._current_ws:
                try:
                    self._current_ws.close()
                except Exception:
                    pass
                self._current_ws = None
        try:
            self._session.close()
        except Exception:
            pass
        self._session = requests.Session()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=0.6)
            self._thread = None
        self._log("Discord Remote Control stopped")

    def _parse_admin_ids(self, admin_ids_str):
        if not admin_ids_str:
            return set()
        if isinstance(admin_ids_str, (list, set)):
            return {str(x).strip() for x in admin_ids_str if str(x).strip()}
        return {x.strip() for x in str(admin_ids_str).replace(";", ",").split(",") if x.strip()}

    def _gateway_loop(self, token, channel_id, admin_ids_raw, proxy_url=None, pc_tag="PC1"):
        self.pc_tag = str(pc_tag).strip() or "PC1"
        admin_ids = self._parse_admin_ids(admin_ids_raw)
        headers = {
            "Authorization": f"Bot {token}",
            "User-Agent": "FarmWatcherRemote"
        }
        api_base = f"https://discord.com/api/v10/channels/{channel_id}"

        if proxy_url:
            self._session.proxies = {"http": proxy_url, "https": proxy_url}
        else:
            self._session.proxies = {}

        use_privileged_intents = True

        while not self._stop_event.is_set():
            ws = None
            hb_stop = threading.Event()
            try:
                current_proxy = proxy_url or (self.plugin.get_proxy_url() if hasattr(self.plugin, "get_proxy_url") else "")
                if current_proxy:
                    self._session.proxies = {"http": current_proxy, "https": current_proxy}
                else:
                    self._session.proxies = {}

                s = cffi_requests.Session(proxy=current_proxy) if current_proxy else cffi_requests.Session()
                ws = s.ws_connect("wss://gateway.discord.gg/?v=10&encoding=json")
                with self._ws_lock:
                    self._current_ws = ws

                raw_hello, _ = ws.recv(timeout=25.0)
                hello_text = raw_hello.decode("utf-8", errors="ignore") if isinstance(raw_hello, bytes) else str(raw_hello)
                hello_data = json.loads(hello_text)
                if hello_data.get("op") != 10:
                    time.sleep(3)
                    continue

                heartbeat_interval = hello_data["d"]["heartbeat_interval"] / 1000.0

                last_seq = [None]

                def _heartbeat_worker():
                    while not hb_stop.is_set() and not self._stop_event.is_set():
                        if hb_stop.wait(heartbeat_interval):
                            break
                        try:
                            ws.send(json.dumps({"op": 1, "d": last_seq[0]}))
                        except Exception:
                            try:
                                ws.close()
                            except Exception:
                                pass
                            break

                hb_thread = threading.Thread(target=_heartbeat_worker, daemon=True)
                hb_thread.start()

                intents_val = 37377 if use_privileged_intents else 4609
                identify = {
                    "op": 2,
                    "d": {
                        "token": token,
                        "intents": intents_val,
                        "properties": {
                            "os": "windows",
                            "browser": "farm_watcher",
                            "device": "farm_watcher"
                        }
                    }
                }
                ws.send(json.dumps(identify))

                recv_timeout = max(60.0, heartbeat_interval * 2)
                while not self._stop_event.is_set():
                    raw_msg, _ = ws.recv(timeout=recv_timeout)
                    if not raw_msg:
                        break

                    if isinstance(raw_msg, bytes):
                        if b"Authentication failed" in raw_msg:
                            self._log("Authentication failed: Invalid Discord bot token. Waiting before retry.")
                            time.sleep(10)
                            break
                        if b"Disallowed intent" in raw_msg:
                            self._log("Message Content Intent disabled in Discord Developer Portal. Falling back to standard intents.")
                            use_privileged_intents = False
                            break

                    msg_text = raw_msg.decode("utf-8", errors="ignore") if isinstance(raw_msg, bytes) else str(raw_msg)
                    try:
                        event = json.loads(msg_text)
                    except Exception:
                        continue

                    op = event.get("op")
                    seq = event.get("s")
                    if seq is not None:
                        last_seq[0] = seq

                    if op == 7:
                        self._log("Discord Gateway requested reconnect Opcode 7")
                        break

                    if op == 9:
                        self._log("Discord Gateway session invalid Opcode 9")
                        time.sleep(2)
                        break

                    if op == 0:
                        t = event.get("t")
                        d = event.get("d") or {}

                        if t == "READY":
                            user_data = d.get("user") or {}
                            self.bot_user_id = str(user_data.get("id", ""))
                            bot_username = user_data.get("username", "Farm Watcher")
                            self._log(f"Bot connected to Gateway and is now ONLINE: {bot_username} ID: {self.bot_user_id}")

                        elif t == "MESSAGE_CREATE":
                            msg_channel = str(d.get("channel_id", ""))
                            if msg_channel == str(channel_id):
                                self._handle_message(api_base, headers, d, admin_ids)

            except Exception as e:
                err_text = str(e)
                if "Disallowed intent" in err_text or "4014" in err_text:
                    self._log("Message Content Intent is disabled in Discord Developer Portal. Reconnecting with standard intents.")
                    use_privileged_intents = False
                elif not self._stop_event.is_set():
                    self._log(f"Gateway connection error: {e}")
            finally:
                with self._ws_lock:
                    self._current_ws = None
                try:
                    hb_stop.set()
                    if ws:
                        ws.close()
                except Exception:
                    pass

            if not self._stop_event.is_set():
                for _ in range(30):
                    if self._stop_event.is_set():
                        break
                    time.sleep(0.1)

    def _match_target(self, parts):
        if not parts:
            return False, "", []

        def _norm(t):
            import re
            return re.sub(r"[^a-z0-9]", "", str(t).lower())

        norm_my = _norm(self.pc_tag)

        def _is_pc_target(token):
            n = _norm(token)
            if n in ("all", "*"):
                return True, True
            if n == norm_my:
                return True, True
            for prefix in ["pc", "rig", "worker", "node", "farm", "server"]:
                if n.startswith(prefix):
                    rest = n[len(prefix):]
                    if not rest or rest.isdigit():
                        return True, False
            return False, False

        # Case 1: First token is PC tag, for example !pc1 status or !all status
        is_tag, is_for_me = _is_pc_target(parts[0])
        if is_tag:
            if not is_for_me:
                return False, "", []
            if len(parts) > 1:
                return True, parts[1].lower(), parts[2:]
            return True, "status", []

        # Case 2: PC tag in arguments, for example !status pc1 or !autofarm pc2
        cmd = parts[0].lower()
        args = parts[1:]
        clean_args = []
        for a in args:
            t_is_tag, t_is_for_me = _is_pc_target(a)
            if t_is_tag:
                if not t_is_for_me:
                    return False, "", []
            else:
                clean_args.append(a)

        return True, cmd, clean_args

    def _handle_message(self, api_base, headers, msg, admin_ids):
        author = msg.get("author", {})
        if author.get("bot", False):
            return

        author_id = str(author.get("id", ""))
        content = (msg.get("content") or "").strip()

        # Security check
        if admin_ids and author_id not in admin_ids:
            warning = (
                f"Access denied.\n\n"
                f"Your Discord User ID: `{author_id}`\n"
                f"Add this ID to plugin settings: Plugins - Remote Control."
            )
            self._send_embed(api_base, headers, "Access Denied", warning, color=COLOR_RED)
            self._log(f"Unauthorized Discord command from user {author_id}")
            return

        # If content is empty because Message Content Intent is not enabled in portal:
        if not content:
            warning_text = (
                "Bot received your message but message text was concealed by Discord.\n\n"
                "Enable Message Content Intent in Discord Developer Portal:\n"
                "1. Go to Discord Developer Portal Applications\n"
                "2. Select Farm Watcher bot and click Bot tab\n"
                "3. Scroll to Privileged Gateway Intents\n"
                "4. Enable Message Content Intent and click Save Changes\n\n"
                "Alternative: mention the bot in your command:\n"
                "@Farm Watcher !status"
            )
            self._send_embed(api_base, headers, "Message Content Intent Required", warning_text, color=COLOR_ORANGE)
            return

        # Remove bot mention prefix if present
        if self.bot_user_id:
            content = content.replace(f"<@{self.bot_user_id}>", "").replace(f"<@!{self.bot_user_id}>", "").strip()

        clean_text = content
        if clean_text.startswith("!") or clean_text.startswith("/"):
            clean_text = clean_text[1:]

        parts = clean_text.split()
        if not parts:
            return

        matched, cmd, args = self._match_target(parts)
        if not matched:
            return

        start_time = time.time()

        if cmd in ("help", "start"):
            self._cmd_help(api_base, headers)
        elif cmd in ("status", "s"):
            self._cmd_status(api_base, headers)
        elif cmd in ("screen", "sc", "screenshot", "ss"):
            self._cmd_screen(api_base, headers, full_desktop=True)
        elif cmd in ("game", "cs2"):
            self._cmd_screen(api_base, headers, full_desktop=False)
        elif cmd in ("accounts", "accs"):
            self._cmd_accounts(api_base, headers)
        elif cmd in ("vac",):
            self._cmd_vac(api_base, headers)
        elif cmd in ("banned",):
            self._cmd_banned(api_base, headers)
        # Main Farm Watcher controls
        elif cmd in ("autofarm", "start_farm", "farm_start"):
            mode = args[0].lower() if args else "normal"
            ok, res = self.plugin.action_start_farm(mode)
            color = COLOR_GREEN if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "Autofarm", res, color=color)
        elif cmd in ("stop", "stop_farm", "farm_stop"):
            ok, res = self.plugin.action_stop_farm()
            color = COLOR_BLUE if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "STOP", res, color=color)
        elif cmd in ("kill",):
            ok, res = self.plugin.action_kill()
            color = COLOR_RED if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "KILL", res, color=color)
        elif cmd in ("killall", "kill_all"):
            ok, res = self.plugin.action_kill_all()
            color = COLOR_RED if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "KILL ALL", res, color=color)
        elif cmd in ("refresh", "refresh_accounts"):
            ok, res = self.plugin.action_refresh_accounts()
            color = COLOR_BLUE if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "Refresh Accounts", res, color=color)
        # Secondary controls
        elif cmd in ("skip", "next"):
            ok, res = self.plugin.action_skip_current()
            color = COLOR_GREEN if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "Skip Account", res, color=color)
        elif cmd in ("restart",):
            if args and args[0].isdigit():
                ok, res = self.plugin.action_reboot_pc(delay_minutes=int(args[0]))
                self._send_embed(api_base, headers, "Reboot PC", res, color=COLOR_RED)
            else:
                ok, res = self.plugin.action_restart_current()
                color = COLOR_GREEN if ok else COLOR_ORANGE
                self._send_embed(api_base, headers, "Restart Account", res, color=color)
        elif cmd in ("pause",):
            ok, res = self.plugin.action_pause()
            color = COLOR_ORANGE if ok else COLOR_RED
            self._send_embed(api_base, headers, "Pause Autofarm", res, color=color)
        elif cmd in ("resume",):
            ok, res = self.plugin.action_resume()
            color = COLOR_GREEN if ok else COLOR_RED
            self._send_embed(api_base, headers, "Resume Autofarm", res, color=color)
        elif cmd in ("launch", "run"):
            if not args:
                self._send_embed(api_base, headers, "Usage", "!launch <login>", color=COLOR_BLUE)
            else:
                ok, res = self.plugin.action_launch_account(args[0])
                color = COLOR_GREEN if ok else COLOR_ORANGE
                self._send_embed(api_base, headers, "Launch Account", res, color=color)
        elif cmd in ("stop_acc", "stop_account"):
            ok, res = self.plugin.action_stop_account()
            color = COLOR_BLUE if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "Stop Account", res, color=color)
        elif cmd in ("2fa", "guard"):
            if not args:
                self._send_embed(api_base, headers, "Usage", "!2fa <login>", color=COLOR_BLUE)
            else:
                ok, res = self.plugin.action_get_2fa(args[0])
                if ok:
                    fields = [{"name": "Steam Guard Code", "value": f"```\n{res['code']}\n```", "inline": False}]
                    self._send_embed(api_base, headers, f"2FA Code for {res['login']}", "", color=COLOR_GREEN, fields=fields)
                else:
                    self._send_embed(api_base, headers, "2FA Error", str(res), color=COLOR_RED)
        elif cmd in ("mark_done", "done"):
            if not args:
                self._send_embed(api_base, headers, "Usage", "!mark_done <login>", color=COLOR_BLUE)
            else:
                ok, res = self.plugin.action_mark_done(args[0])
                color = COLOR_GREEN if ok else COLOR_ORANGE
                self._send_embed(api_base, headers, "Mark Done", res, color=color)
        elif cmd in ("clear_done", "undone"):
            if not args:
                self._send_embed(api_base, headers, "Usage", "!clear_done <login>", color=COLOR_BLUE)
            else:
                ok, res = self.plugin.action_clear_done(args[0])
                color = COLOR_BLUE if ok else COLOR_ORANGE
                self._send_embed(api_base, headers, "Clear Done", res, color=color)
        elif cmd in ("clear_all_done", "reset_circle"):
            ok, res = self.plugin.action_clear_all_done()
            self._send_embed(api_base, headers, "Reset Circle", res, color=COLOR_PURPLE)
        elif cmd in ("mark_all_done",):
            ok, res = self.plugin.action_mark_all_done()
            self._send_embed(api_base, headers, "Mark All Done", res, color=COLOR_PURPLE)
        elif cmd in ("check_bans",):
            ok, res = self.plugin.action_check_bans()
            self._send_embed(api_base, headers, "Check Bans", res, color=COLOR_BLUE)
        elif cmd in ("stop_bans",):
            ok, res = self.plugin.action_stop_bans()
            self._send_embed(api_base, headers, "Stop Bans", res, color=COLOR_ORANGE)
        elif cmd in ("reboot_pc", "reboot", "restart_pc"):
            mins = int(args[0]) if (args and args[0].isdigit()) else 0
            ok, res = self.plugin.action_reboot_pc(delay_minutes=mins)
            self._send_embed(api_base, headers, "Reboot PC", res, color=COLOR_RED)
        elif cmd in ("shutdown_pc", "shutdown", "kapat"):
            mins = int(args[0]) if (args and args[0].isdigit()) else 0
            ok, res = self.plugin.action_shutdown_pc(delay_minutes=mins)
            self._send_embed(api_base, headers, "Shutdown PC", res, color=COLOR_RED)
        elif cmd in ("cancel_shutdown", "cancel_reboot"):
            ok, res = self.plugin.action_cancel_shutdown()
            color = COLOR_GREEN if ok else COLOR_ORANGE
            self._send_embed(api_base, headers, "Cancel Shutdown", res, color=color)
        elif cmd in ("cmd", "exec", "terminal", "shell"):
            if not args:
                self._send_embed(api_base, headers, "Usage", "!cmd <command line>", color=COLOR_BLUE)
            else:
                full_cmd = " ".join(args)
                ok, res = self.plugin.action_execute_cmd(full_cmd)
                color = COLOR_GREEN if ok else COLOR_RED
                code_block = f"```\n{res}\n```"
                self._send_embed(api_base, headers, f"CMD: {full_cmd[:40]}", code_block, color=color)
        elif cmd in ("ping",):
            latency = int((time.time() - start_time) * 1000)
            self._send_embed(api_base, headers, "Pong!", f"Farm Watcher active. Latency: {latency} ms.", color=COLOR_GREEN)

    def _cmd_help(self, api_base, headers):
        fields = [
            {
                "name": "Farm Watcher Controls",
                "value": (
                    "• `!autofarm [tag or all]` - Start autofarm\n"
                    "• `!stop [tag or all]` - Stop autofarm\n"
                    "• `!kill [tag or all]` - Close CS2 and Steam\n"
                    "• `!killall [tag or all]` - Terminate all farm processes\n"
                    "• `!refresh [tag or all]` - Reload accounts from disk"
                ),
                "inline": False
            },
            {
                "name": "Monitoring",
                "value": (
                    "• `!status [tag or all]` - Farm status and progress\n"
                    "• `!screen [tag or all]` - Capture desktop screenshot\n"
                    "• `!game [tag or all]` - Capture CS2 window screenshot\n"
                    "• `!accounts [tag or all]` - List all accounts\n"
                    "• `!vac [tag or all]` - List VAC Live accounts\n"
                    "• `!banned [tag or all]` - List banned accounts"
                ),
                "inline": False
            },
            {
                "name": "Account Management",
                "value": (
                    "• `!skip [tag]` - Skip current account\n"
                    "• `!2fa <login> [tag]` - Get Steam Guard code from maFile\n"
                    "• `!launch <login> [tag]` - Launch specific account\n"
                    "• `!mark_done <login> [tag]` - Mark account as done\n"
                    "• `!clear_all_done [tag]` - Reset circle"
                ),
                "inline": False
            },
            {
                "name": "System and Terminal",
                "value": (
                    "• `!cmd <command line> [tag]` - Execute system terminal command\n"
                    "• `!reboot_pc [minutes] [tag]` - Reboot host computer\n"
                    "• `!shutdown_pc [minutes] [tag]` - Shutdown host computer\n"
                    "• `!cancel_shutdown [tag]` - Cancel scheduled reboot or shutdown\n"
                    "• `!check_bans [tag]` - Check all accounts for bans\n"
                    "• `!stop_bans [tag]` - Stop ongoing bans check"
                ),
                "inline": False
            },
            {
                "name": "Multi PC Targeting",
                "value": (
                    "• Target single PC: `!status pc1` or `!pc1 status`\n"
                    "• Target all PCs: `!status all` or `!all status`\n"
                    f"• Current computer tag: `{self.pc_tag}`"
                ),
                "inline": False
            }
        ]
        self._send_embed(api_base, headers, "Farm Watcher - Remote Control", 
                         "Send commands using ! or / prefix in this channel:", 
                         color=COLOR_BLUE, fields=fields)

    def _cmd_status(self, api_base, headers):
        info = self.plugin.get_detailed_status()
        fields = [
            {"name": "Autofarm Status", "value": f"**{info['autofarm_text']}**", "inline": True},
            {"name": "Active Account", "value": f"`{info['active_account']}`", "inline": True},
            {"name": "Progress", "value": f"**{info['farmed_count']} / {info['total_count']}** - {info['progress_pct']}%", "inline": True},
            {"name": "CS2", "value": "Running" if info['cs2_running'] else "Stopped", "inline": True},
            {"name": "Steam", "value": "Running" if info['steam_running'] else "Stopped", "inline": True},
            {"name": "In Match", "value": "Yes" if info['in_match'] else "No", "inline": True}
        ]
        color = COLOR_GREEN if info["autofarm_running"] else COLOR_BLUE
        self._send_embed(api_base, headers, "Farm Watcher Status", "", color=color, fields=fields)

    def _cmd_screen(self, api_base, headers, full_desktop=True):
        self._send_embed(api_base, headers, "Screen Capture", "Capturing screenshot...", color=COLOR_BLUE)
        image_bytes = self.plugin.api.capture_desktop() if full_desktop else self.plugin.api.capture_game()
        
        if not image_bytes:
            target = "desktop" if full_desktop else "CS2 window"
            self._send_embed(api_base, headers, "Capture Error", f"Failed to capture {target}.", color=COLOR_RED)
            return

        title = "Desktop Screenshot" if full_desktop else "CS2 Game Screenshot"
        self._send_file_embed(api_base, headers, title, image_bytes)

    def _cmd_accounts(self, api_base, headers):
        accounts_data = self.plugin.get_accounts_list_status()
        if not accounts_data:
            self._send_embed(api_base, headers, "Accounts", "Account list is empty.", color=COLOR_BLUE)
            return

        lines = []
        for acc in accounts_data:
            idx = acc.get("idx", 0)
            login = acc.get("login", "unknown")
            status = acc.get("status", "pending")
            
            if status == "farmed":
                marker = "[DONE]"
            elif status == "active":
                marker = "[FARM]"
            elif status == "vac":
                marker = "[VAC]"
            elif status == "banned":
                marker = "[BAN]"
            else:
                marker = "[WAIT]"

            lines.append(f"`{idx:>2}.` {marker} `{login}`")

        text = "\n".join(lines[:60])
        if len(lines) > 60:
            text += f"\n... and {len(lines) - 60} more accounts"

        self._send_embed(api_base, headers, f"Accounts List - Total: {len(accounts_data)}", text, color=COLOR_BLUE)

    def _cmd_vac(self, api_base, headers):
        vac_list = self.plugin.get_vac_live_accounts()
        if not vac_list:
            self._send_embed(api_base, headers, "VAC Live", "No VAC Live accounts found.", color=COLOR_GREEN)
            return
        text = "\n".join([f"• `{l}`" for l in vac_list])
        self._send_embed(api_base, headers, f"VAC Live Accounts - Total: {len(vac_list)}", text, color=COLOR_RED)

    def _cmd_banned(self, api_base, headers):
        banned_list = self.plugin.get_profile_banned_accounts()
        if not banned_list:
            self._send_embed(api_base, headers, "Banned Accounts", "No banned accounts found.", color=COLOR_GREEN)
            return
        text = "\n".join([f"• `{l}`" for l in banned_list])
        self._send_embed(api_base, headers, f"Banned Accounts - Total: {len(banned_list)}", text, color=COLOR_RED)

    def _send_embed(self, api_base, headers, title, description, color=COLOR_BLUE, fields=None):
        try:
            tagged_title = f"[{self.pc_tag}] {title}"
            embed = {
                "title": tagged_title[:256],
                "description": description[:4096] if description else "",
                "color": color,
                "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "footer": {"text": f"Farm Watcher Remote Control - {self.pc_tag}"}
            }
            if fields:
                embed["fields"] = fields[:25]

            payload = {"embeds": [embed]}
            self._session.post(f"{api_base}/messages", headers=headers, json=payload, timeout=10)
        except Exception as e:
            self._log(f"Failed to send Discord embed: {e}")

    def _send_file_embed(self, api_base, headers, title, image_bytes):
        try:
            tagged_title = f"[{self.pc_tag}] {title}"
            embed = {
                "title": tagged_title[:256],
                "color": COLOR_BLUE,
                "image": {"url": "attachment://screenshot.png"},
                "timestamp": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                "footer": {"text": f"Farm Watcher Remote Control - {self.pc_tag}"}
            }
            payload = {"embeds": [embed]}
            files = {"file": ("screenshot.png", image_bytes, "image/png")}
            data = {"payload_json": json.dumps(payload)}
            self._session.post(f"{api_base}/messages", headers=headers, data=data, files=files, timeout=20)
        except Exception as e:
            self._log(f"Failed to send Discord file embed: {e}")
