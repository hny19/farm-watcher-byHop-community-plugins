import threading
from app.plugin.base import BasePlugin
from .bot import TelegramRemoteBot
from .discord_bot import DiscordRemoteBot
from .gui import RemoteControlSettingsUIAdapter

class RemoteControlPlugin(BasePlugin):
    version = "1.2.0"
    dependencies = [
        ("requests", "requests"),
    ]
    target_tab = "plugins"

    def __init__(self, api):
        super().__init__(api)
        self._config_lock = threading.Lock()
        self.bot = TelegramRemoteBot(self, logger=self.log)
        self.discord_bot = DiscordRemoteBot(self, logger=self.log)

        cfg = self.get_config()
        updated = False
        if "enabled" not in cfg:
            cfg["enabled"] = False
            updated = True
        if "telegram_enabled" not in cfg:
            cfg["telegram_enabled"] = bool(cfg.get("enabled", False))
            updated = True
        if "telegram_bot_token" not in cfg:
            cfg["telegram_bot_token"] = ""
            updated = True
        if "telegram_admin_ids" not in cfg:
            cfg["telegram_admin_ids"] = ""
            updated = True
        if "discord_enabled" not in cfg:
            cfg["discord_enabled"] = False
            updated = True
        if "discord_bot_token" not in cfg:
            cfg["discord_bot_token"] = ""
            updated = True
        if "discord_channel_id" not in cfg:
            cfg["discord_channel_id"] = ""
            updated = True
        if "discord_admin_ids" not in cfg:
            cfg["discord_admin_ids"] = ""
            updated = True
        if "pc_tag" not in cfg:
            default_tag = "PC1"
            try:
                import os
                import json
                from app.paths import PROJECT_ROOT
                notif_path = os.path.join(PROJECT_ROOT, "common_files", "plugin_configs", "NotificationsPlugin.json")
                if os.path.exists(notif_path):
                    with open(notif_path, "r", encoding="utf-8") as f:
                        ndata = json.load(f)
                        if ndata.get("discord_tag"):
                            default_tag = str(ndata.get("discord_tag")).strip()
            except Exception:
                pass
            cfg["pc_tag"] = default_tag
            updated = True
        if "proxy_enabled" not in cfg:
            cfg["proxy_enabled"] = False
            updated = True
        if "proxy_url" not in cfg:
            cfg["proxy_url"] = ""
            updated = True

        if updated:
            self.save_config(cfg)

    def log(self, text):
        self.api.log(f"[RemoteControl] {text}")

    def get_proxy_url(self):
        cfg = self.get_config()
        candidate = ""

        if cfg.get("proxy_enabled") and cfg.get("proxy_url"):
            candidate = str(cfg.get("proxy_url")).strip()

        if not candidate:
            try:
                import os
                import json
                from app.paths import PROJECT_ROOT
                notif_path = os.path.join(PROJECT_ROOT, "common_files", "plugin_configs", "NotificationsPlugin.json")
                if os.path.exists(notif_path):
                    with open(notif_path, "r", encoding="utf-8") as f:
                        ndata = json.load(f)
                        if ndata.get("proxy_enabled") and ndata.get("proxy_url"):
                            candidate = str(ndata.get("proxy_url")).strip()
            except Exception:
                pass

        if not candidate:
            try:
                import os
                import json
                from app.paths import PROJECT_ROOT
                tor_path = os.path.join(PROJECT_ROOT, "plugins", "tor_proxy", "config.json")
                if os.path.exists(tor_path):
                    with open(tor_path, "r", encoding="utf-8") as f:
                        tdata = json.load(f)
                        if tdata.get("enabled", True):
                            port = tdata.get("socks_port", 9050)
                            candidate = f"socks5h://127.0.0.1:{port}"
            except Exception:
                pass

        if candidate and self._is_proxy_available(candidate):
            return candidate

        return ""

    def _is_proxy_available(self, proxy_url):
        if not proxy_url:
            return False
        try:
            from urllib.parse import urlparse
            import socket
            u = urlparse(proxy_url)
            host = u.hostname or "127.0.0.1"
            port = u.port or (9050 if "socks" in str(u.scheme or "") else 8080)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.6)
            res = sock.connect_ex((host, port))
            sock.close()
            return res == 0
        except Exception:
            return False

    def on_startup(self, ctx):
        threading.Thread(target=self._apply_config, daemon=True, name="FW_Remote_Startup").start()

    def on_shutdown(self, ctx):
        self.bot.stop()
        self.discord_bot.stop()
        self.log("Remote control stopped")

    def on_config_updated(self):
        threading.Thread(target=self._apply_config, daemon=True, name="FW_Remote_ConfigReload").start()

    def _apply_config(self):
        with self._config_lock:
            cfg = self.get_config()
            proxy_url = self.get_proxy_url()
            pc_tag = str(cfg.get("pc_tag", "PC1")).strip() or "PC1"

            # 1. Telegram
            if cfg.get("telegram_enabled", False) or cfg.get("enabled", False):
                token = cfg.get("telegram_bot_token", "")
                admins = cfg.get("telegram_admin_ids", "")
                self.bot.start(token, admins, proxy_url=proxy_url, pc_tag=pc_tag)
            else:
                self.bot.stop()

            # 2. Discord
            if cfg.get("discord_enabled", False):
                d_token = cfg.get("discord_bot_token", "")
                d_channel = cfg.get("discord_channel_id", "")
                d_admins = cfg.get("discord_admin_ids", "")
                self.discord_bot.start(d_token, d_channel, d_admins, proxy_url=proxy_url, pc_tag=pc_tag)
            else:
                self.discord_bot.stop()

    def build_settings_ui(self, parent_frame):
        adapter = RemoteControlSettingsUIAdapter(self, parent_frame)
        adapter.build_ui()
        self._ui_adapter = adapter

    def reload_settings_ui(self, settings_tab):
        if hasattr(self, "_ui_adapter") and self._ui_adapter:
            try:
                self._ui_adapter._update_toggle_visuals()
                self._ui_adapter._update_status()
            except Exception:
                pass

    def _resolve_account_idx(self, target):
        gui = self.api.ctx.get("gui")
        if not gui or not hasattr(gui, "logic"):
            return None, None
        records = getattr(gui.logic, "records", [])
        
        target_str = str(target).strip()
        if target_str.isdigit():
            idx = int(target_str)
            if 1 <= idx <= len(records):
                return idx, records[idx - 1]
            return None, None

        for idx, rec in enumerate(records, 1):
            if rec.get("login", "").lower() == target_str.lower():
                return idx, rec
        return None, None

    # --- 1. Status & Information ---

    def get_detailed_status(self) -> dict:
        gui = self.api.ctx.get("gui")
        active_account = "None"
        autofarm_running = False
        is_paused = False
        cs2_running = False
        steam_running = False
        in_match = False
        total_accounts = 0
        farmed_accounts = 0

        if gui and hasattr(gui, "logic"):
            logic = gui.logic
            try:
                autofarm_running, _, _ = logic.check_active_processes()
                steam_running = getattr(logic, "steam_active", False)
                cs2_running = getattr(logic, "game_active", False)
            except Exception:
                pass

            if hasattr(gui, "state"):
                farmed_accounts = len(getattr(gui.state, "exclude_indexes", []))

            records = getattr(logic, "records", [])
            total_accounts = len(records)

            pm = getattr(gui, "plugin_manager", None) or getattr(logic, "plugin_manager", None)
            if pm and hasattr(pm, "get_active_plugins"):
                for p in pm.get_active_plugins():
                    if hasattr(p, "is_in_match"):
                        try:
                            if p.is_in_match():
                                in_match = True
                        except Exception:
                            pass
                    if hasattr(p, "is_paused"):
                        is_paused = getattr(p, "is_paused", False)

        from app.utils.config import load_restore_config
        from app.paths import CONFIG_PATH
        try:
            cfg = load_restore_config(CONFIG_PATH)
            active_account = cfg.get("last_login", "") or "None"
        except Exception:
            pass

        pct = round((farmed_accounts / total_accounts * 100), 1) if total_accounts > 0 else 0

        autofarm_text = "Stopped"
        if autofarm_running:
            autofarm_text = "Paused" if is_paused else "Running"

        return {
            "autofarm_running": autofarm_running,
            "autofarm_text": autofarm_text,
            "is_paused": is_paused,
            "active_account": active_account,
            "cs2_running": cs2_running,
            "steam_running": steam_running,
            "in_match": in_match,
            "total_count": total_accounts,
            "farmed_count": farmed_accounts,
            "progress_pct": pct
        }

    def get_accounts_list_status(self) -> list:
        gui = self.api.ctx.get("gui")
        if not gui or not hasattr(gui, "logic"):
            return []

        records = getattr(gui.logic, "records", [])
        exclude_indexes = set(getattr(gui.state, "exclude_indexes", []))
        vac_indexes = set(getattr(gui.state, "vac_live_indexes", []))
        banned_indexes = set(getattr(gui.state, "profile_banned_indexes", []))

        active_login = self.get_detailed_status().get("active_account", "")

        result = []
        for idx, rec in enumerate(records, 1):
            login = rec.get("login", "")
            if not login:
                continue

            status = "waiting"
            if idx in vac_indexes:
                status = "vac"
            elif idx in banned_indexes:
                status = "banned"
            elif idx in exclude_indexes:
                status = "farmed"
            elif login == active_login:
                status = "active"

            result.append({"login": login, "status": status, "idx": idx})

        return result

    def get_vac_live_accounts(self) -> list:
        gui = self.api.ctx.get("gui")
        if not gui or not hasattr(gui, "state"):
            return []
        vac_indexes = sorted(getattr(gui.state, "vac_live_indexes", []))
        records = getattr(gui.logic, "records", [])
        return [records[i - 1].get("login", "") for i in vac_indexes if 1 <= i <= len(records)]

    def get_profile_banned_accounts(self) -> list:
        gui = self.api.ctx.get("gui")
        if not gui or not hasattr(gui, "state"):
            return []
        banned_indexes = sorted(getattr(gui.state, "profile_banned_indexes", []))
        records = getattr(gui.logic, "records", [])
        return [records[i - 1].get("login", "") for i in banned_indexes if 1 <= i <= len(records)]

    # --- 2. Autofarm Control ---

    def _get_autofarm_plugin(self):
        gui = self.api.ctx.get("gui")
        if not gui:
            return None
        pm = getattr(gui, "plugin_manager", None) or getattr(getattr(gui, "logic", None), "plugin_manager", None)
        if pm and hasattr(pm, "plugins"):
            for p in pm.plugins:
                if hasattr(p, "send_worker_command") and getattr(p, "has_farming_logic", False):
                    return p
        return None

    def action_start_farm(self, mode="normal"):
        gui = self.api.ctx.get("gui")
        if not gui:
            return False, "GUI not available"
        if gui.logic.check_active_processes()[0]:
            return False, "Autofarm is already running"
        
        ap = self._get_autofarm_plugin()
        if ap and hasattr(ap, "get_config"):
            cfg = ap.get_config()
            cfg["mode"] = mode
            ap.save_config(cfg)

        gui.root.after(0, lambda: gui.actions.run_auto_farm_gui())
        return True, f"Autofarm started in mode: {mode}"

    def action_stop_farm(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "stop_auto_farm_gui"):
            gui.root.after(0, gui.actions.stop_auto_farm_gui)
            return True, "Autofarm stop initiated"
        return False, "GUI not available"

    def action_skip_current(self):
        ap = self._get_autofarm_plugin()
        if ap and hasattr(ap, "send_worker_command"):
            if ap.send_worker_command("SKIP"):
                return True, "SKIP command sent to worker"
        return False, "Autofarm is not running or worker unavailable"

    def action_restart_current(self):
        ap = self._get_autofarm_plugin()
        if ap and hasattr(ap, "send_worker_command"):
            if ap.send_worker_command("RESTART"):
                return True, "RESTART command sent to worker"
        return False, "Autofarm is not running or worker unavailable"

    def action_pause(self):
        ap = self._get_autofarm_plugin()
        if ap and hasattr(ap, "send_worker_command"):
            if ap.send_worker_command("PAUSE"):
                ap.is_paused = True
                return True, "Autofarm paused"
        return False, "Autofarm is not running"

    def action_resume(self):
        ap = self._get_autofarm_plugin()
        if ap and hasattr(ap, "send_worker_command"):
            if ap.send_worker_command("RESUME"):
                ap.is_paused = False
                return True, "Autofarm resumed"
        return False, "Autofarm is not running"

    def action_kill(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "kill_game_steam_gui"):
            gui.root.after(0, gui.actions.kill_game_steam_gui)
            return True, "CS2 and Steam processes terminated"
        return False, "GUI not available"

    def action_kill_all(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "kill_all_processes_gui"):
            gui.root.after(0, gui.actions.kill_all_processes_gui)
            return True, "All farm processes terminated"
        return False, "GUI not available"

    # --- 3. Individual Account Actions ---

    def action_launch_account(self, target):
        gui = self.api.ctx.get("gui")
        if not gui:
            return False, "GUI not available"
        idx, rec = self._resolve_account_idx(target)
        if not idx:
            return False, f"Account {target} not found"
        gui.root.after(0, lambda: gui.actions.run_selected_account_gui(idx))
        return True, f"Launching account {rec.get('login')}"

    def action_stop_account(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "stop_selected_account_gui"):
            gui.root.after(0, gui.actions.stop_selected_account_gui)
            return True, "Stopping selected account"
        return False, "GUI not available"

    def action_get_2fa(self, target):
        idx, rec = self._resolve_account_idx(target)
        if not idx or not rec:
            return False, f"Account {target} not found"
        shared_secret = rec.get("shared_secret")
        if not shared_secret:
            return False, f"Missing shared_secret in maFile for {rec.get('login')}"
        try:
            from app.auth.steam_qr_login import generate_steam_guard_code, query_server_time
            code = generate_steam_guard_code(shared_secret, query_server_time())
            return True, {"login": rec.get("login"), "code": code}
        except Exception as e:
            return False, f"Failed to generate 2FA code: {e}"

    def action_mark_done(self, target):
        gui = self.api.ctx.get("gui")
        if not gui:
            return False, "GUI not available"
        idx, rec = self._resolve_account_idx(target)
        if not idx:
            return False, f"Account {target} not found"
        gui.root.after(0, lambda: gui.actions.mark_exclude_by_index(idx))
        return True, f"Account {rec.get('login')} marked as completed"

    def action_clear_done(self, target):
        gui = self.api.ctx.get("gui")
        if not gui:
            return False, "GUI not available"
        idx, rec = self._resolve_account_idx(target)
        if not idx:
            return False, f"Account {target} not found"
        gui.root.after(0, lambda: gui.actions.clear_exclude_by_index(idx))
        return True, f"Account {rec.get('login')} returned to farm queue"

    def action_mark_all_done(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "mark_all_excludes"):
            gui.root.after(0, gui.actions.mark_all_excludes)
            return True, "All accounts marked as completed"
        return False, "GUI not available"

    def action_clear_all_done(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "clear_all_excludes"):
            gui.root.after(0, gui.actions.clear_all_excludes)
            return True, "All account completion statuses cleared"
        return False, "GUI not available"

    def action_refresh_accounts(self):
        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "actions") and hasattr(gui.actions, "refresh_accounts_state_gui"):
            gui.root.after(0, gui.actions.refresh_accounts_state_gui)
            return True, "Account list reloaded from disk"
        return False, "GUI not available"

    # --- 4. Bans Checking ---

    def action_check_bans(self):
        gui = self.api.ctx.get("gui")
        if not gui or not hasattr(gui, "actions") or not hasattr(gui.actions, "check_bans_batch"):
            return False, "GUI not available"
        records = getattr(gui.logic, "records", [])
        if not records:
            return False, "Account list is empty"
        idxs = list(range(1, len(records) + 1))
        gui.root.after(0, lambda: gui.actions.check_bans_batch(idxs, send_report=True))
        return True, f"Bans check started for {len(idxs)} accounts"

    def action_stop_bans(self):
        try:
            from app.paths import BANS_STOP_FILE
            with open(BANS_STOP_FILE, "w", encoding="utf-8") as f:
                f.write("STOP\n")
            return True, "Bans check stop requested"
        except Exception as e:
            return False, f"Failed to stop bans check: {e}"

    # --- 5. System PC Control ---

    def action_execute_cmd(self, command_line):
        if not command_line or not str(command_line).strip():
            return False, "Command line is empty"
        cmd_str = str(command_line).strip()
        try:
            import subprocess
            proc = subprocess.run(
                cmd_str,
                shell=True,
                capture_output=True,
                text=True,
                timeout=15,
                encoding="cp866",
                errors="replace"
            )
            out = proc.stdout or ""
            err = proc.stderr or ""
            res = (out + "\n" + err).strip() if err else out.strip()
            if not res:
                res = "Command executed with no output."
            if len(res) > 3800:
                res = res[:3800] + "\n... output truncated"
            return True, res
        except subprocess.TimeoutExpired:
            return False, "Command execution timed out after 15 seconds"
        except Exception as e:
            return False, f"Execution error: {e}"

    def action_reboot_pc(self, delay_minutes=0):
        try:
            mins = int(delay_minutes)
        except Exception:
            mins = 0

        import subprocess
        if mins > 0:
            sec = mins * 60
            subprocess.Popen(["shutdown", "/r", "/t", str(sec)])
            return True, f"Computer reboot scheduled in {mins} minutes"

        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "logic") and hasattr(gui.logic, "reboot_pc_logic"):
            gui.root.after(1000, gui.logic.reboot_pc_logic)
            return True, "Computer reboot initiated"

        subprocess.Popen(["shutdown", "/r", "/t", "5"])
        return True, "Computer reboot initiated in 5 seconds"

    def action_shutdown_pc(self, delay_minutes=0):
        try:
            mins = int(delay_minutes)
        except Exception:
            mins = 0

        import subprocess
        if mins > 0:
            sec = mins * 60
            subprocess.Popen(["shutdown", "/s", "/t", str(sec)])
            return True, f"Computer shutdown scheduled in {mins} minutes"

        gui = self.api.ctx.get("gui")
        if gui and hasattr(gui, "logic") and hasattr(gui.logic, "shutdown_pc_logic"):
            gui.root.after(1000, gui.logic.shutdown_pc_logic)
            return True, "Computer shutdown initiated"

        subprocess.Popen(["shutdown", "/s", "/t", "5"])
        return True, "Computer shutdown initiated in 5 seconds"

    def action_cancel_shutdown(self):
        try:
            import subprocess
            subprocess.Popen(["shutdown", "/a"])
            return True, "Scheduled reboot or shutdown cancelled"
        except Exception as e:
            return False, f"Failed to cancel shutdown: {e}"
