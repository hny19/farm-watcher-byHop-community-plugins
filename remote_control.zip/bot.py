import time
import threading
import requests
from html import escape

class TelegramRemoteBot:
    def __init__(self, plugin, logger=None):
        self.plugin = plugin
        self.logger = logger or print
        self._session = requests.Session()
        self._thread = None
        self._stop_event = threading.Event()
        self.last_update_id = 0
        self.pc_tag = "PC1"
        self._closed_keyboard_chats = set()

    def _log(self, text):
        try:
            self.logger(f"[RemoteBot] {text}")
        except Exception:
            pass

    def start(self, token, admin_ids, proxy_url=None, pc_tag="PC1"):
        self.stop()
        if not token or not token.strip():
            return
        self.pc_tag = str(pc_tag).strip() or "PC1"
        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._poll_loop,
            args=(token.strip(), admin_ids, proxy_url, self.pc_tag),
            daemon=True,
            name="FW_RemoteControl_Bot"
        )
        self._thread.start()
        self._log(f"Telegram Remote Control bot started for {self.pc_tag}")

    def stop(self):
        self._stop_event.set()
        try:
            self._session.close()
        except Exception:
            pass
        self._session = requests.Session()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=0.6)
            self._thread = None
        self._log("Telegram Remote Control bot stopped")

    def _parse_admin_ids(self, admin_ids_str):
        if not admin_ids_str:
            return set()
        if isinstance(admin_ids_str, (list, set)):
            return {str(x).strip() for x in admin_ids_str if str(x).strip()}
        return {x.strip() for x in str(admin_ids_str).replace(";", ",").split(",") if x.strip()}

    def _get_keyboard(self):
        return {
            "keyboard": [
                [{"text": "Autofarm"}, {"text": "STOP"}],
                [{"text": "KILL"}, {"text": "KILL ALL"}],
                [{"text": "Refresh Accounts"}, {"text": "Screenshot"}],
                [{"text": "Status"}, {"text": "Accounts"}],
                [{"text": "Reboot PC"}, {"text": "CMD"}],
                [{"text": "Close Menu"}]
            ],
            "resize_keyboard": True,
            "is_persistent": False
        }

    def _register_commands(self, base_url):
        try:
            cmds = [
                {"command": "status", "description": "Farm status and uptime"},
                {"command": "screen", "description": "Take desktop screenshot"},
                {"command": "accounts", "description": "Account drop and ban status"},
                {"command": "autofarm", "description": "Start autofarm loop"},
                {"command": "stop", "description": "Stop autofarm loop"},
                {"command": "kill", "description": "Terminate active CS2 instance"},
                {"command": "kill_all", "description": "Terminate all CS2 and Steam"},
                {"command": "refresh", "description": "Reload accounts list"},
                {"command": "cmd", "description": "Execute terminal command on host"},
                {"command": "reboot_pc", "description": "Reboot host with delay in minutes"},
                {"command": "shutdown_pc", "description": "Shutdown host with delay in minutes"},
                {"command": "cancel_shutdown", "description": "Cancel scheduled reboot or shutdown"},
                {"command": "menu", "description": "Open interactive keyboard"},
                {"command": "close_menu", "description": "Close interactive keyboard"},
                {"command": "help", "description": "Show full help instructions"}
            ]
            self._session.post(f"{base_url}/setMyCommands", json={"commands": cmds}, timeout=10)
        except Exception:
            pass

    def _poll_loop(self, token, admin_ids_raw, proxy_url=None, pc_tag="PC1"):
        self.pc_tag = str(pc_tag).strip() or "PC1"
        admin_ids = self._parse_admin_ids(admin_ids_raw)
        base_url = f"https://api.telegram.org/bot{token}"
        offset = self.last_update_id + 1 if self.last_update_id else None

        if proxy_url:
            self._session.proxies = {"http": proxy_url, "https": proxy_url}
        else:
            self._session.proxies = {}

        self._register_commands(base_url)

        while not self._stop_event.is_set():
            try:
                current_proxy = proxy_url or (self.plugin.get_proxy_url() if hasattr(self.plugin, "get_proxy_url") else "")
                if current_proxy:
                    self._session.proxies = {"http": current_proxy, "https": current_proxy}
                else:
                    self._session.proxies = {}

                params = {"timeout": 5, "limit": 10}
                if offset is not None:
                    params["offset"] = offset

                resp = self._session.get(f"{base_url}/getUpdates", params=params, timeout=8)
                if self._stop_event.is_set():
                    return
                if resp.status_code == 200:
                    data = resp.json()
                    for update in data.get("result", []):
                        if self._stop_event.is_set():
                            return
                        offset = update["update_id"] + 1
                        self.last_update_id = update["update_id"]
                        self._handle_update(base_url, update, admin_ids)
                elif resp.status_code in (401, 404):
                    self._log(f"Invalid bot token. Status: {resp.status_code}. Waiting.")
                    for _ in range(50):
                        if self._stop_event.is_set():
                            return
                        time.sleep(0.1)
                elif resp.status_code == 409:
                    self._log("Conflict 409: Another bot instance active. Retrying in 5s.")
                    for _ in range(50):
                        if self._stop_event.is_set():
                            return
                        time.sleep(0.1)
                else:
                    for _ in range(30):
                        if self._stop_event.is_set():
                            return
                        time.sleep(0.1)
            except requests.exceptions.Timeout:
                continue
            except requests.exceptions.ConnectionError:
                for _ in range(30):
                    if self._stop_event.is_set():
                        return
                    time.sleep(0.1)
            except Exception as e:
                if not self._stop_event.is_set():
                    self._log(f"Poll loop error: {e}")
                for _ in range(30):
                    if self._stop_event.is_set():
                        return
                    time.sleep(0.1)

    def _match_target(self, parts):
        if not parts:
            return False, "", []

        def _norm(t):
            import re
            return re.sub(r"[^a-z0-9]", "", str(t).lower())

        norm_my = _norm(self.pc_tag)

        def _is_pc_target(token):
            n = _norm(token)
            if n in ("all", "*"):
                return True, True
            if n == norm_my:
                return True, True
            for prefix in ["pc", "rig", "worker", "node", "farm", "server"]:
                if n.startswith(prefix):
                    rest = n[len(prefix):]
                    if not rest or rest.isdigit():
                        return True, False
            return False, False

        # Case 1: First token is PC tag, for example /pc1 status or !pc1 status
        raw_first = parts[0]
        if raw_first.startswith("/") or raw_first.startswith("!"):
            raw_first = raw_first[1:]
        is_tag, is_for_me = _is_pc_target(raw_first)
        if is_tag:
            if not is_for_me:
                return False, "", []
            if len(parts) > 1:
                sub_cmd = parts[1].lower()
                if sub_cmd.startswith("/") or sub_cmd.startswith("!"):
                    sub_cmd = sub_cmd[1:]
                return True, "/" + sub_cmd, parts[2:]
            return True, "/status", []

        # Case 2: PC tag in arguments, for example /status pc1 or !cmd dir pc2
        raw_cmd = parts[0].lower()
        if "@" in raw_cmd:
            raw_cmd = raw_cmd.split("@")[0]
        if raw_cmd.startswith("!"):
            cmd = "/" + raw_cmd[1:]
        elif not raw_cmd.startswith("/"):
            cmd = "/" + raw_cmd
        else:
            cmd = raw_cmd

        args = parts[1:]
        clean_args = []
        for a in args:
            t_is_tag, t_is_for_me = _is_pc_target(a)
            if t_is_tag:
                if not t_is_for_me:
                    return False, "", []
            else:
                clean_args.append(a)

        return True, cmd, clean_args

    def _handle_update(self, base_url, update, admin_ids):
        message = update.get("message")
        if not message:
            return

        chat_id = message.get("chat", {}).get("id")
        user = message.get("from", {})
        user_id = str(user.get("id", ""))
        text = (message.get("text") or "").strip()

        if not text or not chat_id:
            return

        # Security check
        if admin_ids and user_id not in admin_ids:
            warning = (
                f"Access denied.\n\n"
                f"Your Telegram ID: <code>{user_id}</code>\n"
                f"Add this ID to plugin settings: Plugins - Remote Control."
            )
            self._send_text(base_url, chat_id, warning, with_keyboard=False)
            self._log(f"Unauthorized command from user {user_id}")
            return

        # Normalize keyboard commands
        clean_text = text.strip()
        cmd = ""
        args = []

        if clean_text in ("Autofarm", "autofarm"):
            cmd = "/start_farm"
        elif clean_text in ("STOP", "stop"):
            cmd = "/stop_farm"
        elif clean_text in ("KILL", "kill"):
            cmd = "/kill"
        elif clean_text in ("KILL ALL", "kill all", "kill_all"):
            cmd = "/kill_all"
        elif clean_text in ("Refresh Accounts", "Refresh", "refresh"):
            cmd = "/refresh"
        elif clean_text in ("Screenshot", "screen"):
            cmd = "/screen"
        elif clean_text in ("Status", "status"):
            cmd = "/status"
        elif clean_text in ("Accounts", "accounts"):
            cmd = "/accounts"
        elif clean_text in ("Reboot PC", "reboot pc", "reboot_pc"):
            cmd = "/reboot_prompt"
        elif clean_text in ("CMD", "cmd"):
            cmd = "/cmd_prompt"
        elif clean_text in ("Close Menu", "close menu", "Hide Keyboard", "hide keyboard", "Close", "close"):
            cmd = "/close_menu"
        elif clean_text in ("Menu", "menu", "Keyboard", "keyboard"):
            cmd = "/menu"
        else:
            parts = text.split()
            if not parts:
                return
            matched, cmd, args = self._match_target(parts)
            if not matched:
                return

        start_time = time.time()

        # Command routing
        if cmd in ("/start", "/help"):
            self._closed_keyboard_chats.discard(chat_id)
            self._cmd_help(base_url, chat_id)
        elif cmd in ("/menu", "/keyboard", "/open_menu"):
            self._closed_keyboard_chats.discard(chat_id)
            self._send_text(
                base_url,
                chat_id,
                f"<b>[{self.pc_tag}]</b> Keyboard menu opened.",
                reply_markup=self._get_keyboard()
            )
        elif cmd in ("/close_menu", "/hide_menu", "/close", "/hide_keyboard"):
            self._closed_keyboard_chats.add(chat_id)
            self._send_text(
                base_url,
                chat_id,
                f"<b>[{self.pc_tag}]</b> Keyboard menu closed. Send /menu or use the Menu button to reopen.",
                reply_markup={"remove_keyboard": True}
            )
        elif cmd in ("/status", "/s"):
            self._cmd_status(base_url, chat_id)
        elif cmd in ("/screen", "/sc", "/ss"):
            self._cmd_screen(base_url, chat_id, full_desktop=True)
        elif cmd in ("/game", "/cs2"):
            self._cmd_screen(base_url, chat_id, full_desktop=False)
        elif cmd in ("/accounts", "/accs"):
            self._cmd_accounts(base_url, chat_id)
        elif cmd in ("/vac",):
            self._cmd_vac(base_url, chat_id)
        elif cmd in ("/banned",):
            self._cmd_banned(base_url, chat_id)
        # Main Farm Watcher UI buttons
        elif cmd in ("/start_farm", "/farm_start", "/autofarm"):
            mode = args[0].lower() if args else "normal"
            ok, msg = self.plugin.action_start_farm(mode)
            self._send_text(base_url, chat_id, f"<b>Autofarm:</b> {msg}")
        elif cmd in ("/stop_farm", "/farm_stop", "/stop"):
            ok, msg = self.plugin.action_stop_farm()
            self._send_text(base_url, chat_id, f"<b>STOP:</b> {msg}")
        elif cmd in ("/kill",):
            ok, msg = self.plugin.action_kill()
            self._send_text(base_url, chat_id, f"<b>KILL:</b> {msg}")
        elif cmd in ("/kill_all",):
            ok, msg = self.plugin.action_kill_all()
            self._send_text(base_url, chat_id, f"<b>KILL ALL:</b> {msg}")
        elif cmd in ("/refresh",):
            ok, msg = self.plugin.action_refresh_accounts()
            self._send_text(base_url, chat_id, f"<b>Refresh Accounts:</b> {msg}")
        # Secondary controls
        elif cmd in ("/skip", "/next"):
            ok, msg = self.plugin.action_skip_current()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/restart",):
            if args and args[0].isdigit():
                ok, msg = self.plugin.action_reboot_pc(delay_minutes=int(args[0]))
                self._send_text(base_url, chat_id, f"<b>[{self.pc_tag}]</b> {msg}")
            else:
                ok, msg = self.plugin.action_restart_current()
                self._send_text(base_url, chat_id, f"<b>[{self.pc_tag}]</b> {msg}")
        elif cmd in ("/pause",):
            ok, msg = self.plugin.action_pause()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/resume",):
            ok, msg = self.plugin.action_resume()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/launch", "/run"):
            if not args:
                self._send_text(base_url, chat_id, "Usage: <code>/launch &lt;login&gt;</code>")
            else:
                ok, msg = self.plugin.action_launch_account(args[0])
                self._send_text(base_url, chat_id, msg)
        elif cmd in ("/stop_acc", "/stop_account"):
            ok, msg = self.plugin.action_stop_account()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/2fa", "/guard"):
            if not args:
                self._send_text(base_url, chat_id, "Usage: <code>/2fa &lt;login&gt;</code>")
            else:
                ok, res = self.plugin.action_get_2fa(args[0])
                if ok:
                    self._send_text(base_url, chat_id, f"<b>2FA Code for {escape(res['login'])}:</b>\n\n<code>{res['code']}</code>")
                else:
                    self._send_text(base_url, chat_id, str(res))
        elif cmd in ("/mark_done", "/done"):
            if not args:
                self._send_text(base_url, chat_id, "Usage: <code>/mark_done &lt;login&gt;</code>")
            else:
                ok, msg = self.plugin.action_mark_done(args[0])
                self._send_text(base_url, chat_id, msg)
        elif cmd in ("/clear_done", "/undone"):
            if not args:
                self._send_text(base_url, chat_id, "Usage: <code>/clear_done &lt;login&gt;</code>")
            else:
                ok, msg = self.plugin.action_clear_done(args[0])
                self._send_text(base_url, chat_id, msg)
        elif cmd in ("/clear_all_done", "/reset_circle"):
            ok, msg = self.plugin.action_clear_all_done()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/mark_all_done",):
            ok, msg = self.plugin.action_mark_all_done()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/check_bans",):
            ok, msg = self.plugin.action_check_bans()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/stop_bans",):
            ok, msg = self.plugin.action_stop_bans()
            self._send_text(base_url, chat_id, msg)
        elif cmd in ("/reboot_pc", "/reboot", "/restart_pc"):
            mins = int(args[0]) if (args and args[0].isdigit()) else 0
            ok, msg = self.plugin.action_reboot_pc(delay_minutes=mins)
            self._send_text(base_url, chat_id, f"<b>[{self.pc_tag}]</b> {msg}")
        elif cmd in ("/shutdown_pc", "/shutdown", "/kapat"):
            mins = int(args[0]) if (args and args[0].isdigit()) else 0
            ok, msg = self.plugin.action_shutdown_pc(delay_minutes=mins)
            self._send_text(base_url, chat_id, f"<b>[{self.pc_tag}]</b> {msg}")
        elif cmd in ("/cancel_shutdown", "/cancel_reboot"):
            ok, msg = self.plugin.action_cancel_shutdown()
            self._send_text(base_url, chat_id, f"<b>[{self.pc_tag}]</b> {msg}")
        elif cmd in ("/cmd", "/exec", "/terminal", "/shell"):
            if not args:
                self._send_text(base_url, chat_id, "Usage: <code>/cmd &lt;command line&gt;</code>")
            else:
                full_cmd = " ".join(args)
                ok, res = self.plugin.action_execute_cmd(full_cmd)
                escaped_out = escape(res)
                msg = f"<b>[{self.pc_tag}] CMD: {escape(full_cmd[:40])}</b>\n\n<pre>{escaped_out}</pre>"
                self._send_text(base_url, chat_id, msg)
        elif cmd == "/reboot_prompt":
            prompt = (
                f"<b>[{self.pc_tag}] PC Reboot Control</b>\n\n"
                "Send command with optional delay in minutes:\n"
                "• <code>/reboot_pc 5</code> — Reboot in 5 minutes\n"
                "• <code>/reboot_pc 1</code> — Reboot in 1 minute\n"
                "• <code>/reboot_pc</code> — Reboot immediately\n"
                "• <code>/cancel_shutdown</code> — Cancel scheduled reboot\n"
                "• <code>/shutdown_pc 5</code> — Shutdown in 5 minutes"
            )
            self._send_text(base_url, chat_id, prompt)
        elif cmd == "/cmd_prompt":
            prompt = (
                f"<b>[{self.pc_tag}] Host Terminal Execution</b>\n\n"
                "Send command to execute on host:\n"
                "• <code>/cmd tasklist</code>\n"
                "• <code>/cmd ipconfig</code>\n"
                "• <code>/cmd dir</code>\n\n"
                "Format: <code>/cmd &lt;command line&gt;</code>"
            )
            self._send_text(base_url, chat_id, prompt)
        elif cmd in ("/ping",):
            latency = int((time.time() - start_time) * 1000)
            self._send_text(base_url, chat_id, f"Pong! Farm Watcher active. Latency: {latency} ms.")
        else:
            self._send_text(base_url, chat_id, "Unknown command. Use buttons below or send /help.")

    def _cmd_help(self, base_url, chat_id):
        msg = (
            f"<b>[{self.pc_tag}] Farm Watcher Remote Control</b>\n\n"
            "Main Control Buttons:\n"
            "• <b>Autofarm</b> - Start autofarm\n"
            "• <b>STOP</b> - Stop autofarm\n"
            "• <b>KILL</b> - Close CS2 and Steam\n"
            "• <b>KILL ALL</b> - Terminate all farm processes\n"
            "• <b>Refresh Accounts</b> - Reload accounts from disk\n"
            "• <b>Screenshot</b> - Capture desktop screen\n"
            "• <b>Status</b> - Current farm status\n"
            "• <b>Accounts</b> - List all accounts\n\n"
            "Additional Commands [prefixes / or ! supported]:\n"
            "• <code>/skip</code> - Skip current account\n"
            "• <code>/restart [minutes]</code> - Restart account or reboot PC\n"
            "• <code>/pause</code> - Pause autofarm\n"
            "• <code>/resume</code> - Resume autofarm\n"
            "• <code>/launch &lt;login&gt;</code> - Launch account\n"
            "• <code>/2fa &lt;login&gt;</code> - Get Steam Guard code\n"
            "• <code>/mark_done &lt;login&gt;</code> - Mark as done\n"
            "• <code>/clear_done &lt;login&gt;</code> - Return to queue\n"
            "• <code>/clear_all_done</code> - Reset circle\n"
            "• <code>/vac</code> - List VAC Live accounts\n"
            "• <code>/banned</code> - List banned accounts\n"
            "• <code>/check_bans</code> - Check all accounts for bans\n"
            "• <code>/ss</code> or <code>/game</code> - Capture desktop or CS2 window\n"
            "• <code>/cmd &lt;command&gt;</code> - Execute system terminal command\n"
            "• <code>/reboot_pc [minutes]</code> - Reboot PC with optional delay\n"
            "• <code>/shutdown_pc [minutes]</code> or <code>/kapat</code> - Shutdown PC\n"
            "• <code>/cancel_shutdown</code> - Cancel scheduled reboot or shutdown\n"
            "• <code>/menu</code> or <code>/close_menu</code> - Open or close keyboard buttons"
        )
        self._send_text(base_url, chat_id, msg)

    def _cmd_status(self, base_url, chat_id):
        info = self.plugin.get_detailed_status()
        status_msg = (
            f"<b>[{self.pc_tag}] Farm Watcher Status</b>\n\n"
            f"Autofarm: <b>{info['autofarm_text']}</b>\n"
            f"Active Account: <code>{info['active_account']}</code>\n\n"
            f"Processes:\n"
            f"• CS2: {'Running' if info['cs2_running'] else 'Stopped'}\n"
            f"• Steam: {'Running' if info['steam_running'] else 'Stopped'}\n"
            f"• In Match: {'Yes' if info['in_match'] else 'No'}\n\n"
            f"Progress: <b>{info['farmed_count']} / {info['total_count']}</b> - {info['progress_pct']}%"
        )
        self._send_text(base_url, chat_id, status_msg)

    def _cmd_screen(self, base_url, chat_id, full_desktop=True):
        self._send_text(base_url, chat_id, "Capturing image...")
        image_bytes = self.plugin.api.capture_desktop() if full_desktop else self.plugin.api.capture_game()
        
        if not image_bytes:
            target = "desktop" if full_desktop else "CS2 window"
            self._send_text(base_url, chat_id, f"Failed to capture {target}.")
            return

        caption = "Desktop Screenshot" if full_desktop else "CS2 Game Screenshot"
        self._send_photo(base_url, chat_id, image_bytes, caption)

    def _cmd_accounts(self, base_url, chat_id):
        accounts_data = self.plugin.get_accounts_list_status()
        if not accounts_data:
            self._send_text(base_url, chat_id, "Account list is empty.")
            return

        lines = ["<b>Accounts List:</b>\n"]
        for acc in accounts_data:
            idx = acc.get("idx", 0)
            login = escape(acc.get("login", "unknown"))
            status = acc.get("status", "pending")
            
            if status == "farmed":
                marker = "[DONE]"
            elif status == "active":
                marker = "[FARM]"
            elif status == "vac":
                marker = "[VAC]"
            elif status == "banned":
                marker = "[BAN]"
            else:
                marker = "[WAIT]"

            lines.append(f"{idx}. {marker} <code>{login}</code>")

        current_chunk = ""
        for line in lines:
            if len(current_chunk) + len(line) + 2 > 3800:
                self._send_text(base_url, chat_id, current_chunk)
                current_chunk = line + "\n"
            else:
                current_chunk += line + "\n"

        if current_chunk:
            self._send_text(base_url, chat_id, current_chunk)

    def _cmd_vac(self, base_url, chat_id):
        vac_list = self.plugin.get_vac_live_accounts()
        if not vac_list:
            self._send_text(base_url, chat_id, "No VAC Live accounts found.")
            return
        text = f"<b>VAC Live Accounts - Total: {len(vac_list)}:</b>\n\n"
        text += "\n".join([f"• <code>{escape(l)}</code>" for l in vac_list])
        self._send_text(base_url, chat_id, text)

    def _cmd_banned(self, base_url, chat_id):
        banned_list = self.plugin.get_profile_banned_accounts()
        if not banned_list:
            self._send_text(base_url, chat_id, "No banned accounts found.")
            return
        text = f"<b>Banned Accounts - Total: {len(banned_list)}:</b>\n\n"
        text += "\n".join([f"• <code>{escape(l)}</code>" for l in banned_list])
        self._send_text(base_url, chat_id, text)

    def _send_text(self, base_url, chat_id, text, reply_markup=None, with_keyboard=True):
        try:
            payload = {
                "chat_id": chat_id,
                "text": text,
                "parse_mode": "HTML",
                "disable_web_page_preview": True
            }
            if reply_markup is not None:
                payload["reply_markup"] = reply_markup
            elif with_keyboard and (chat_id not in self._closed_keyboard_chats):
                payload["reply_markup"] = self._get_keyboard()
            resp = self._session.post(f"{base_url}/sendMessage", json=payload, timeout=10)
            if resp.status_code != 200:
                payload.pop("parse_mode", None)
                self._session.post(f"{base_url}/sendMessage", json=payload, timeout=10)
        except Exception as e:
            self._log(f"Failed to send text to {chat_id}: {e}")

    def _send_photo(self, base_url, chat_id, photo_bytes, caption="", reply_markup=None, with_keyboard=True):
        try:
            data = {
                "chat_id": chat_id,
                "caption": caption[:1024]
            }
            if reply_markup is not None:
                import json
                data["reply_markup"] = json.dumps(reply_markup)
            elif with_keyboard and (chat_id not in self._closed_keyboard_chats):
                import json
                data["reply_markup"] = json.dumps(self._get_keyboard())
            files = {
                "photo": ("screenshot.png", photo_bytes, "image/png")
            }
            self._session.post(f"{base_url}/sendPhoto", data=data, files=files, timeout=20)
        except Exception as e:
            self._log(f"Failed to send photo to {chat_id}: {e}")
