import os
import threading
import tkinter as tk
from tkinter import messagebox
import requests

class RemoteControlSettingsUIAdapter:
    def __init__(self, plugin, parent_frame):
        self.plugin = plugin
        self.parent_frame = parent_frame
        self.vars = {}
        self._status_timer = None
        self._save_timer = None
        self._loading = True

        cfg = self.plugin.get_config()

        self.vars["enabled"] = tk.BooleanVar(value=bool(cfg.get("enabled", True)))
        self.vars["telegram_enabled"] = tk.BooleanVar(value=bool(cfg.get("telegram_enabled", cfg.get("enabled", False))))
        self.vars["telegram_bot_token"] = tk.StringVar(value=str(cfg.get("telegram_bot_token", "")))
        self.vars["telegram_admin_ids"] = tk.StringVar(value=str(cfg.get("telegram_admin_ids", "")))

        self.vars["discord_enabled"] = tk.BooleanVar(value=bool(cfg.get("discord_enabled", False)))
        self.vars["discord_bot_token"] = tk.StringVar(value=str(cfg.get("discord_bot_token", "")))
        self.vars["discord_channel_id"] = tk.StringVar(value=str(cfg.get("discord_channel_id", "")))
        self.vars["discord_admin_ids"] = tk.StringVar(value=str(cfg.get("discord_admin_ids", "")))
        self.vars["pc_tag"] = tk.StringVar(value=str(cfg.get("pc_tag", "PC1")))

        self.vars["proxy_enabled"] = tk.BooleanVar(value=bool(cfg.get("proxy_enabled", False)))
        self.vars["proxy_url"] = tk.StringVar(value=str(cfg.get("proxy_url", "")))

        for var in self.vars.values():
            var.trace_add("write", self._schedule_save)

        self._loading = False

    def _bind_desc(self, widget, key, parent_frame=None):
        if not widget:
            return

        bound = False
        target = widget
        while target:
            if hasattr(target, "_bind_description"):
                try:
                    target._bind_description(widget, key, plugin=self.plugin)
                    bound = True
                    break
                except Exception:
                    pass
            target = getattr(target, "master", None)

        if not bound and parent_frame:
            target = parent_frame
            while target:
                if hasattr(target, "_bind_description"):
                    try:
                        target._bind_description(widget, key, plugin=self.plugin)
                        bound = True
                        break
                    except Exception:
                        pass
                target = getattr(target, "master", None)

    def _schedule_save(self, *_args):
        if self._loading:
            return
        if self._save_timer:
            try:
                self.parent_frame.after_cancel(self._save_timer)
            except Exception:
                pass
        self._save_timer = self.parent_frame.after(600, self._perform_save)

    def _perform_save(self):
        self._save_timer = None
        data = {
            "enabled": bool(self.vars["enabled"].get()),
            "telegram_enabled": bool(self.vars["telegram_enabled"].get()),
            "telegram_bot_token": str(self.vars["telegram_bot_token"].get()).strip(),
            "telegram_admin_ids": str(self.vars["telegram_admin_ids"].get()).strip(),
            "discord_enabled": bool(self.vars["discord_enabled"].get()),
            "discord_bot_token": str(self.vars["discord_bot_token"].get()).strip(),
            "discord_channel_id": str(self.vars["discord_channel_id"].get()).strip(),
            "discord_admin_ids": str(self.vars["discord_admin_ids"].get()).strip(),
            "pc_tag": str(self.vars["pc_tag"].get()).strip() or "PC1",
            "proxy_enabled": bool(self.vars["proxy_enabled"].get()),
            "proxy_url": str(self.vars["proxy_url"].get()).strip()
        }
        self.plugin.save_config(data)
        self.plugin.on_config_updated()
        self._update_toggle_visuals()

    def _start_telegram_test(self):
        token = str(self.vars.get("telegram_bot_token", tk.StringVar()).get()).strip()
        if not token:
            messagebox.showwarning("Telegram", "Please enter Telegram Bot Token first.")
            return

        def _worker():
            try:
                proxy_url = self.plugin.get_proxy_url()
                proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
                r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=10, proxies=proxies)
                if r.status_code == 200:
                    data = r.json().get("result", {})
                    name = data.get("first_name", "")
                    username = data.get("username", "")
                    msg = f"Telegram token is valid.\nBot: {name} @{username}"
                    self.parent_frame.after(0, lambda: messagebox.showinfo("Telegram", msg))
                else:
                    self.parent_frame.after(0, lambda: messagebox.showerror("Telegram", f"Error: {r.status_code}\n{r.text}"))
            except Exception as e:
                self.parent_frame.after(0, lambda: messagebox.showerror("Telegram", f"Connection error: {e}"))

        threading.Thread(target=_worker, daemon=True).start()

    def _start_discord_test(self):
        token = str(self.vars.get("discord_bot_token", tk.StringVar()).get()).strip()
        channel_id = str(self.vars.get("discord_channel_id", tk.StringVar()).get()).strip()
        if not token:
            messagebox.showwarning("Discord", "Please enter Discord Bot Token first.")
            return

        def _worker():
            try:
                proxy_url = self.plugin.get_proxy_url()
                proxies = {"http": proxy_url, "https": proxy_url} if proxy_url else None
                headers = {"Authorization": f"Bot {token}"}
                r = requests.get("https://discord.com/api/v10/users/@me", headers=headers, timeout=10, proxies=proxies)
                if r.status_code == 200:
                    bot_data = r.json()
                    bot_name = bot_data.get("username", "")

                    channel_info = ""
                    if channel_id:
                        r_ch = requests.get(f"https://discord.com/api/v10/channels/{channel_id}", headers=headers, timeout=10, proxies=proxies)
                        if r_ch.status_code == 200:
                            ch_data = r_ch.json()
                            ch_name = ch_data.get("name", channel_id)
                            channel_info = f"\nChannel: #{ch_name}"
                        else:
                            channel_info = f"\nChannel access failed: {r_ch.status_code}"

                    msg = f"Discord token is valid.\nBot: {bot_name}{channel_info}"
                    self.parent_frame.after(0, lambda: messagebox.showinfo("Discord", msg))
                else:
                    self.parent_frame.after(0, lambda: messagebox.showerror("Discord", f"Authorization error: {r.status_code}\n{r.text}"))
            except Exception as e:
                self.parent_frame.after(0, lambda: messagebox.showerror("Discord", f"Connection error: {e}"))

        threading.Thread(target=_worker, daemon=True).start()

    def _toggle_master_enabled(self):
        new_val = not self.vars["enabled"].get()
        self.vars["enabled"].set(new_val)
        self._perform_save()

    def _toggle_telegram_enabled(self):
        new_val = not self.vars["telegram_enabled"].get()
        self.vars["telegram_enabled"].set(new_val)
        self._perform_save()

    def _toggle_discord_enabled(self):
        new_val = not self.vars["discord_enabled"].get()
        self.vars["discord_enabled"].set(new_val)
        self._perform_save()

    def _toggle_proxy_enabled(self):
        new_val = not self.vars["proxy_enabled"].get()
        self.vars["proxy_enabled"].set(new_val)
        self._perform_save()

    def _update_toggle_visuals(self):
        def _apply_btn(btn, is_active):
            if not btn or not btn.winfo_exists():
                return
            if is_active:
                btn.configure(
                    text="ENABLED",
                    bg="#0b5519",
                    fg="#00ff66",
                    activebackground="#147225",
                    activeforeground="#ffffff"
                )
            else:
                btn.configure(
                    text="DISABLED",
                    bg="#3a2525",
                    fg="#ff8888",
                    activebackground="#5a3535",
                    activeforeground="#ffffff"
                )

        if hasattr(self, "btn_master"):
            _apply_btn(self.btn_master, self.vars["enabled"].get())
        if hasattr(self, "btn_tg_toggle"):
            _apply_btn(self.btn_tg_toggle, self.vars["telegram_enabled"].get())
        if hasattr(self, "btn_dc_toggle"):
            _apply_btn(self.btn_dc_toggle, self.vars["discord_enabled"].get())
        if hasattr(self, "btn_proxy_toggle"):
            _apply_btn(self.btn_proxy_toggle, self.vars["proxy_enabled"].get())

    def _update_status(self):
        if not hasattr(self, "parent_frame") or not self.parent_frame.winfo_exists():
            return

        tg_running = False
        if hasattr(self.plugin, "bot") and self.plugin.bot:
            t = getattr(self.plugin.bot, "_thread", None)
            if t and t.is_alive():
                tg_running = True

        if hasattr(self, "lbl_tg_badge") and self.lbl_tg_badge.winfo_exists():
            if tg_running:
                self.lbl_tg_badge.configure(text="[ONLINE]", fg="#00ff66")
            elif self.vars["telegram_enabled"].get():
                self.lbl_tg_badge.configure(text="[STARTING]", fg="#00b0ff")
            else:
                self.lbl_tg_badge.configure(text="[DISABLED]", fg="#888888")

        dc_running = False
        if hasattr(self.plugin, "discord_bot") and self.plugin.discord_bot:
            t = getattr(self.plugin.discord_bot, "_thread", None)
            if t and t.is_alive():
                dc_running = True

        if hasattr(self, "lbl_dc_badge") and self.lbl_dc_badge.winfo_exists():
            if dc_running:
                self.lbl_dc_badge.configure(text="[ONLINE]", fg="#00ff66")
            elif self.vars["discord_enabled"].get():
                self.lbl_dc_badge.configure(text="[STARTING]", fg="#00b0ff")
            else:
                self.lbl_dc_badge.configure(text="[DISABLED]", fg="#888888")

        if hasattr(self, "lbl_route_badge") and self.lbl_route_badge.winfo_exists():
            proxy_url = self.plugin.get_proxy_url()
            if proxy_url:
                short_route = "Tor SOCKS5" if "9050" in proxy_url else proxy_url[:24]
                self.lbl_route_badge.configure(text=f"Proxy: {short_route}", fg="#00ff66")
            else:
                self.lbl_route_badge.configure(text="Direct Connection", fg="#aaaaaa")

        if hasattr(self, "lbl_pc_badge") and self.lbl_pc_badge.winfo_exists():
            self.lbl_pc_badge.configure(text=self.vars["pc_tag"].get() or "PC1")

        try:
            self._status_timer = self.parent_frame.after(1500, self._update_status)
        except Exception:
            pass

    def build_ui(self):
        for child in self.parent_frame.winfo_children():
            try:
                child.destroy()
            except Exception:
                pass

        bg = "#121212"
        card_bg = "#1c1c1c"
        border_col = "#2a2a2a"
        input_bg = "#121212"
        input_border = "#333333"
        fg_white = "#ffffff"
        fg_muted = "#888888"
        fg_label = "#cccccc"
        btn_dark_bg = "#252a36"
        btn_dark_act = "#313848"

        container = tk.Frame(self.parent_frame, bg=bg)
        container.pack(fill="both", expand=True, padx=12, pady=10)
        self._bind_desc(container, "remote_control", self.parent_frame)

        # Top Header Bar: Title, Subtitle, ENABLED Button and Version
        header_card = tk.Frame(container, bg=bg)
        header_card.pack(fill="x", pady=(0, 10))

        title_col = tk.Frame(header_card, bg=bg)
        title_col.pack(side="left", fill="y")

        title_lbl = tk.Label(
            title_col,
            text="Remote Control",
            bg=bg,
            fg=fg_white,
            font=("Segoe UI", 12, "bold")
        )
        title_lbl.pack(anchor="w")
        self._bind_desc(title_lbl, "remote_control", self.parent_frame)

        current_tag = self.vars["pc_tag"].get() or "PC1"
        subtitle_lbl = tk.Label(
            title_col,
            text=f"Telegram and Discord Bot Controller • Host: {current_tag}",
            bg=bg,
            fg=fg_muted,
            font=("Segoe UI", 8)
        )
        subtitle_lbl.pack(anchor="w", pady=(1, 0))
        self._bind_desc(subtitle_lbl, "remote_control", self.parent_frame)

        header_right = tk.Frame(header_card, bg=bg)
        header_right.pack(side="right")

        self.btn_master = tk.Button(
            header_right,
            font=("Segoe UI", 9, "bold"),
            cursor="hand2",
            relief="flat",
            bd=0,
            padx=16,
            pady=4,
            command=self._toggle_master_enabled
        )
        self.btn_master.pack(side="left", padx=(0, 8))
        self._bind_desc(self.btn_master, "enabled", self.parent_frame)

        lbl_ver = tk.Label(
            header_right,
            text=f"v{self.plugin.version}",
            bg="#161920",
            fg="#7a8290",
            font=("Consolas", 8, "bold"),
            padx=8,
            pady=4
        )
        lbl_ver.pack(side="left")

        # Live Status and Monitoring Card
        status_card = tk.Frame(
            container,
            bg=card_bg,
            highlightthickness=1,
            highlightbackground=border_col,
            padx=14,
            pady=10
        )
        status_card.pack(fill="x", pady=(0, 10))
        self._bind_desc(status_card, "proxy_status", self.parent_frame)

        status_top = tk.Frame(status_card, bg=card_bg)
        status_top.pack(fill="x")

        tg_st_col = tk.Frame(status_top, bg=card_bg)
        tg_st_col.pack(side="left", padx=(0, 20))
        tk.Label(tg_st_col, text="Telegram:", bg=card_bg, fg=fg_muted, font=("Segoe UI", 8)).pack(anchor="w")
        self.lbl_tg_badge = tk.Label(tg_st_col, text="[STOPPED]", bg=card_bg, fg=fg_muted, font=("Segoe UI", 9, "bold"))
        self.lbl_tg_badge.pack(anchor="w")

        dc_st_col = tk.Frame(status_top, bg=card_bg)
        dc_st_col.pack(side="left", padx=(0, 20))
        tk.Label(dc_st_col, text="Discord:", bg=card_bg, fg=fg_muted, font=("Segoe UI", 8)).pack(anchor="w")
        self.lbl_dc_badge = tk.Label(dc_st_col, text="[STOPPED]", bg=card_bg, fg=fg_muted, font=("Segoe UI", 9, "bold"))
        self.lbl_dc_badge.pack(anchor="w")

        pc_st_col = tk.Frame(status_top, bg=card_bg)
        pc_st_col.pack(side="left", padx=(0, 20))
        tk.Label(pc_st_col, text="Host Tag:", bg=card_bg, fg=fg_muted, font=("Segoe UI", 8)).pack(anchor="w")
        self.lbl_pc_badge = tk.Label(pc_st_col, text=self.vars["pc_tag"].get() or "PC1", bg=card_bg, fg="#00ff66", font=("Consolas", 9, "bold"))
        self.lbl_pc_badge.pack(anchor="w")

        route_col = tk.Frame(status_top, bg=card_bg)
        route_col.pack(side="left", fill="x", expand=True)
        tk.Label(route_col, text="Proxy Route:", bg=card_bg, fg=fg_muted, font=("Segoe UI", 8)).pack(anchor="w")
        self.lbl_route_badge = tk.Label(route_col, text="Direct Connection", bg=card_bg, fg="#aaaaaa", font=("Segoe UI", 8, "bold"))
        self.lbl_route_badge.pack(anchor="w")

        status_actions = tk.Frame(status_top, bg=card_bg)
        status_actions.pack(side="right")

        btn_test_tg = tk.Button(
            status_actions,
            text="Test Telegram",
            bg=btn_dark_bg,
            fg="#cccccc",
            activebackground=btn_dark_act,
            activeforeground="#ffffff",
            font=("Segoe UI", 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
            command=self._start_telegram_test
        )
        btn_test_tg.pack(side="left", padx=(0, 6))
        self._bind_desc(btn_test_tg, "test_telegram", self.parent_frame)

        btn_test_dc = tk.Button(
            status_actions,
            text="Test Discord",
            bg=btn_dark_bg,
            fg="#cccccc",
            activebackground=btn_dark_act,
            activeforeground="#ffffff",
            font=("Segoe UI", 8, "bold"),
            relief="flat",
            bd=0,
            padx=10,
            pady=4,
            cursor="hand2",
            command=self._start_discord_test
        )
        btn_test_dc.pack(side="left")
        self._bind_desc(btn_test_dc, "test_discord", self.parent_frame)

        def _render_row(parent, label_text, var, key, is_secret=False, hint=None, custom_width=None):
            row = tk.Frame(parent, bg=card_bg)
            row.pack(fill="x", pady=4)

            lbl = tk.Label(row, text=label_text, bg=card_bg, fg=fg_label, font=("Segoe UI", 9), width=13, anchor="w")
            lbl.pack(side="left")
            self._bind_desc(lbl, key, self.parent_frame)

            ent_wrapper = tk.Frame(row, bg=input_border, padx=1, pady=1)
            if custom_width:
                ent_wrapper.pack(side="left")
            else:
                ent_wrapper.pack(side="left", fill="x", expand=True)

            ent = tk.Entry(
                ent_wrapper,
                textvariable=var,
                bg=input_bg,
                fg=fg_white,
                insertbackground=fg_white,
                font=("Consolas", 9),
                relief="flat",
                bd=0
            )
            if custom_width:
                ent.configure(width=custom_width, justify="center")
            ent.pack(fill="x", ipady=3, padx=4)
            self._bind_desc(ent, key, self.parent_frame)

            if is_secret:
                ent.configure(show="●")
                def _toggle_secret():
                    cur = str(ent.cget("show"))
                    ent.configure(show="" if cur == "●" else "●")
                    btn_sec.configure(text="Hide" if cur == "●" else "Show")

                btn_sec = tk.Button(
                    row,
                    text="Show",
                    bg=btn_dark_bg,
                    fg="#cccccc",
                    activebackground=btn_dark_act,
                    activeforeground="#ffffff",
                    font=("Segoe UI", 8),
                    relief="flat",
                    bd=0,
                    padx=8,
                    pady=2,
                    cursor="hand2",
                    command=_toggle_secret
                )
                btn_sec.pack(side="left", padx=(6, 0))
                self._bind_desc(btn_sec, "toggle_secret", self.parent_frame)

            if hint:
                lbl_hint = tk.Label(row, text=hint, bg=card_bg, fg=fg_muted, font=("Segoe UI", 8))
                lbl_hint.pack(side="left", padx=(8, 0))
                self._bind_desc(lbl_hint, key, self.parent_frame)

        # Card: Telegram Setup
        card_tg = tk.Frame(
            container,
            bg=card_bg,
            highlightthickness=1,
            highlightbackground=border_col,
            padx=14,
            pady=10
        )
        card_tg.pack(fill="x", pady=(0, 10))
        self._bind_desc(card_tg, "telegram_enabled", self.parent_frame)

        tg_head = tk.Frame(card_tg, bg=card_bg)
        tg_head.pack(fill="x", pady=(0, 6))

        tk.Label(
            tg_head,
            text="Telegram Bot Setup",
            bg=card_bg,
            fg=fg_white,
            font=("Segoe UI", 10, "bold")
        ).pack(side="left")

        self.btn_tg_toggle = tk.Button(
            tg_head,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
            relief="flat",
            bd=0,
            padx=10,
            pady=2,
            command=self._toggle_telegram_enabled
        )
        self.btn_tg_toggle.pack(side="right")
        self._bind_desc(self.btn_tg_toggle, "telegram_enabled", self.parent_frame)

        _render_row(card_tg, "Bot Token:", self.vars["telegram_bot_token"], "telegram_bot_token", is_secret=True)
        _render_row(card_tg, "Admin IDs:", self.vars["telegram_admin_ids"], "telegram_admin_ids", hint="Comma-separated Telegram user IDs")

        # Card: Discord Setup
        card_dc = tk.Frame(
            container,
            bg=card_bg,
            highlightthickness=1,
            highlightbackground=border_col,
            padx=14,
            pady=10
        )
        card_dc.pack(fill="x", pady=(0, 10))
        self._bind_desc(card_dc, "discord_enabled", self.parent_frame)

        dc_head = tk.Frame(card_dc, bg=card_bg)
        dc_head.pack(fill="x", pady=(0, 6))

        tk.Label(
            dc_head,
            text="Discord Bot Setup",
            bg=card_bg,
            fg=fg_white,
            font=("Segoe UI", 10, "bold")
        ).pack(side="left")

        self.btn_dc_toggle = tk.Button(
            dc_head,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
            relief="flat",
            bd=0,
            padx=10,
            pady=2,
            command=self._toggle_discord_enabled
        )
        self.btn_dc_toggle.pack(side="right")
        self._bind_desc(self.btn_dc_toggle, "discord_enabled", self.parent_frame)

        _render_row(card_dc, "Bot Token:", self.vars["discord_bot_token"], "discord_bot_token", is_secret=True)
        _render_row(card_dc, "Channel ID:", self.vars["discord_channel_id"], "discord_channel_id", hint="Discord channel snowflake ID")
        _render_row(card_dc, "PC Tag:", self.vars["pc_tag"], "pc_tag", custom_width=12, hint="Tag for multi-PC commands: !status pc1, !cmd pc1")
        _render_row(card_dc, "Admin IDs:", self.vars["discord_admin_ids"], "discord_admin_ids", hint="Comma-separated Discord user IDs")

        # Card: Network and Proxy Setup
        card_net = tk.Frame(
            container,
            bg=card_bg,
            highlightthickness=1,
            highlightbackground=border_col,
            padx=14,
            pady=10
        )
        card_net.pack(fill="x")
        self._bind_desc(card_net, "proxy_enabled", self.parent_frame)

        net_head = tk.Frame(card_net, bg=card_bg)
        net_head.pack(fill="x", pady=(0, 6))

        tk.Label(
            net_head,
            text="Network and Proxy Setup",
            bg=card_bg,
            fg=fg_white,
            font=("Segoe UI", 10, "bold")
        ).pack(side="left")

        self.btn_proxy_toggle = tk.Button(
            net_head,
            font=("Segoe UI", 8, "bold"),
            cursor="hand2",
            relief="flat",
            bd=0,
            padx=10,
            pady=2,
            command=self._toggle_proxy_enabled
        )
        self.btn_proxy_toggle.pack(side="right")
        self._bind_desc(self.btn_proxy_toggle, "proxy_enabled", self.parent_frame)

        _render_row(card_net, "Proxy URL:", self.vars["proxy_url"], "proxy_url", hint="socks5h://127.0.0.1:9050 or http://user:pass@host:port")

        self._update_toggle_visuals()
        self._update_status()
